<?php
/**
 * Cumplimiento legal (Perú): datos de la empresa, Libro de Reclamaciones virtual,
 * páginas de Política de privacidad y Términos y condiciones, y pie de página con enlaces legales.
 *
 * - Libro de Reclamaciones: Código de Protección y Defensa del Consumidor (Ley N.° 29571) y su
 *   Reglamento del Libro de Reclamaciones. Respuesta en un plazo máximo de 15 días hábiles.
 * - Datos personales: Ley N.° 29733 y su Reglamento.
 *
 * Los textos son una base de trabajo: deben revisarse con un abogado antes de publicar.
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =========================================================
   Datos de la empresa
   ========================================================= */

/**
 * Campos de la empresa: clave => array( etiqueta, ayuda ).
 *
 * @return array
 */
function curamba_cc_company_fields() {
	return array(
		'razon_social'     => array( 'Razón social', 'Nombre legal que figura en la SUNAT. Ej.: Curamba Travel E.I.R.L.' ),
		'nombre_comercial' => array( 'Nombre comercial', 'Como te conocen los clientes.' ),
		'ruc'              => array( 'RUC', '11 dígitos.' ),
		'direccion'        => array( 'Domicilio fiscal', 'Dirección completa (calle, número, distrito, provincia, región).' ),
		'email'            => array( 'Correo de atención', 'Aquí llegan las copias de los reclamos y las consultas.' ),
		'telefono'         => array( 'Teléfono', 'Si se deja vacío se usa el número de WhatsApp.' ),
		'mincetur'         => array( 'Registro de agencia (MINCETUR / DIRCETUR)', 'Opcional. Número de registro como agencia de viajes y turismo.' ),
		'facebook'         => array( 'Facebook (URL)', 'Opcional.' ),
		'instagram'        => array( 'Instagram (URL)', 'Opcional.' ),
		'tiktok'           => array( 'TikTok (URL)', 'Opcional.' ),
	);
}

/**
 * Datos guardados de la empresa.
 *
 * @return array
 */
function curamba_cc_company_all() {
	$saved = get_option( 'curamba_cc_company', array() );
	$saved = is_array( $saved ) ? $saved : array();
	$out   = array();
	foreach ( array_keys( curamba_cc_company_fields() ) as $k ) {
		$out[ $k ] = isset( $saved[ $k ] ) ? (string) $saved[ $k ] : '';
	}
	if ( '' === $out['nombre_comercial'] ) {
		$out['nombre_comercial'] = get_bloginfo( 'name' );
	}
	if ( '' === $out['telefono'] ) {
		$wa              = curamba_cc_option_wa();
		$out['telefono'] = '+' . substr( $wa, 0, 2 ) . ' ' . trim( chunk_split( substr( $wa, 2 ), 3, ' ' ) );
	}
	if ( '' === $out['email'] ) {
		$out['email'] = (string) get_option( 'admin_email' );
	}
	return $out;
}

/**
 * Un dato de la empresa. Si falta, devuelve un marcador visible para completarlo.
 *
 * @param string $key         Clave.
 * @param bool   $placeholder Devolver marcador si está vacío.
 * @return string
 */
function curamba_cc_company( $key, $placeholder = true ) {
	$all = curamba_cc_company_all();
	$val = isset( $all[ $key ] ) ? trim( $all[ $key ] ) : '';
	if ( '' === $val && $placeholder ) {
		$fields = curamba_cc_company_fields();
		$label  = isset( $fields[ $key ] ) ? $fields[ $key ][0] : $key;
		return '[' . $label . ' pendiente]';
	}
	return $val;
}

/** ¿Faltan datos obligatorios? */
function curamba_cc_company_missing() {
	$missing = array();
	foreach ( array( 'razon_social', 'ruc', 'direccion' ) as $k ) {
		if ( '' === curamba_cc_company( $k, false ) ) {
			$missing[] = curamba_cc_company_fields()[ $k ][0];
		}
	}
	return $missing;
}

add_action(
	'admin_init',
	function () {
		register_setting(
			'curamba_cc',
			'curamba_cc_company',
			array(
				'type'              => 'array',
				'sanitize_callback' => function ( $in ) {
					$in  = is_array( $in ) ? $in : array();
					$out = array();
					foreach ( array_keys( curamba_cc_company_fields() ) as $k ) {
						$v = isset( $in[ $k ] ) ? wp_unslash( $in[ $k ] ) : '';
						if ( in_array( $k, array( 'facebook', 'instagram', 'tiktok' ), true ) ) {
							$out[ $k ] = esc_url_raw( $v );
						} elseif ( 'email' === $k ) {
							$out[ $k ] = sanitize_email( $v );
						} elseif ( 'ruc' === $k ) {
							$out[ $k ] = preg_replace( '/\D+/', '', $v );
						} else {
							$out[ $k ] = sanitize_text_field( $v );
						}
					}
					return $out;
				},
			)
		);
		foreach ( array( 'curamba_cc_footer', 'curamba_cc_hide_theme_footer' ) as $opt ) {
			register_setting(
				'curamba_cc',
				$opt,
				array(
					'type'              => 'string',
					'default'           => 'yes',
					'sanitize_callback' => function ( $v ) {
						return 'yes' === $v ? 'yes' : 'no';
					},
				)
			);
		}
	}
);

/** Secciones nuevas en Ajustes → Curamba. */
add_action(
	'curamba_cc_settings_sections',
	function () {
		$c = get_option( 'curamba_cc_company', array() );
		$c = is_array( $c ) ? $c : array();
		?>
		<h2><?php esc_html_e( 'Datos de la empresa (para el pie de página y las páginas legales)', 'curamba-cinematic' ); ?></h2>
		<table class="form-table" role="presentation">
			<?php foreach ( curamba_cc_company_fields() as $k => $f ) : ?>
				<tr>
					<th scope="row"><label for="cc-co-<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $f[0] ); ?></label></th>
					<td>
						<input type="<?php echo 'email' === $k ? 'email' : ( in_array( $k, array( 'facebook', 'instagram', 'tiktok' ), true ) ? 'url' : 'text' ); ?>" id="cc-co-<?php echo esc_attr( $k ); ?>" name="curamba_cc_company[<?php echo esc_attr( $k ); ?>]" class="regular-text" value="<?php echo esc_attr( isset( $c[ $k ] ) ? $c[ $k ] : '' ); ?>">
						<p class="description"><?php echo esc_html( $f[1] ); ?></p>
					</td>
				</tr>
			<?php endforeach; ?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Pie de página', 'curamba-cinematic' ); ?></th>
				<td>
					<label><input type="checkbox" name="curamba_cc_footer" value="yes" <?php checked( 'yes', get_option( 'curamba_cc_footer', 'yes' ) ); ?>> <?php esc_html_e( 'Mostrar el pie de Curamba (contacto, Libro de Reclamaciones y enlaces legales) en toda la web', 'curamba-cinematic' ); ?></label><br>
					<label><input type="checkbox" name="curamba_cc_hide_theme_footer" value="yes" <?php checked( 'yes', get_option( 'curamba_cc_hide_theme_footer', 'yes' ) ); ?>> <?php esc_html_e( 'Ocultar el pie de ejemplo del tema (enlaces "Blog, About, FAQs…" y "Designed with WordPress")', 'curamba-cinematic' ); ?></label>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Páginas legales', 'curamba-cinematic' ); ?></h2>
		<table class="form-table" role="presentation">
			<?php foreach ( curamba_cc_legal_pages() as $key => $p ) : ?>
				<?php $id = curamba_cc_legal_page_id( $key ); ?>
				<tr>
					<th scope="row"><?php echo esc_html( $p['title'] ); ?></th>
					<td>
						<?php if ( $id ) : ?>
							<a href="<?php echo esc_url( get_permalink( $id ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Ver', 'curamba-cinematic' ); ?></a> ·
							<a href="<?php echo esc_url( get_edit_post_link( $id ) ); ?>"><?php esc_html_e( 'Editar texto', 'curamba-cinematic' ); ?></a>
						<?php else : ?>
							<em><?php esc_html_e( 'Todavía no creada.', 'curamba-cinematic' ); ?></em>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</table>
		<p>
			<a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=curamba_cc_legal_pages' ), 'curamba_cc_legal_pages' ) ); ?>"><?php esc_html_e( 'Crear las páginas legales que falten', 'curamba-cinematic' ); ?></a>
			<span class="description"><?php esc_html_e( 'Crea el Libro de Reclamaciones, la Política de privacidad y los Términos y condiciones con un borrador listo para completar. No modifica las páginas que ya existen.', 'curamba-cinematic' ); ?></span>
		</p>
		<?php
	}
);

/** Aviso en el panel mientras falten datos legales. */
add_action(
	'admin_notices',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$missing = curamba_cc_company_missing();
		if ( ! $missing ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p><strong>Curamba:</strong> %s <a href="%s">%s</a></p></div>',
			esc_html( sprintf( 'Para el Libro de Reclamaciones y las páginas legales faltan: %s.', implode( ', ', $missing ) ) ),
			esc_url( admin_url( 'options-general.php?page=curamba-cc' ) ),
			esc_html__( 'Completar ahora', 'curamba-cinematic' )
		);
	}
);

/** Shortcode [curamba_dato campo="ruc"]: muestra un dato de la empresa dentro de cualquier texto. */
add_shortcode(
	'curamba_dato',
	function ( $atts ) {
		$atts = shortcode_atts( array( 'campo' => '' ), $atts, 'curamba_dato' );
		$key  = sanitize_key( $atts['campo'] );
		if ( 'libro' === $key ) {
			$id = curamba_cc_legal_page_id( 'reclamos' );
			return $id ? '<a href="' . esc_url( get_permalink( $id ) ) . '">Libro de Reclamaciones</a>' : 'Libro de Reclamaciones';
		}
		if ( 'privacidad' === $key ) {
			$id = curamba_cc_legal_page_id( 'privacidad' );
			return $id ? '<a href="' . esc_url( get_permalink( $id ) ) . '">Política de privacidad</a>' : 'Política de privacidad';
		}
		if ( ! array_key_exists( $key, curamba_cc_company_fields() ) ) {
			return '';
		}
		$val = curamba_cc_company( $key );
		if ( 'email' === $key && is_email( $val ) ) {
			return '<a href="mailto:' . esc_attr( $val ) . '">' . esc_html( $val ) . '</a>';
		}
		return esc_html( $val );
	}
);

/* =========================================================
   Páginas legales
   ========================================================= */

/**
 * Definición de las páginas legales.
 *
 * @return array
 */
function curamba_cc_legal_pages() {
	return array(
		'reclamos'   => array(
			'title' => 'Libro de Reclamaciones',
			'slug'  => 'libro-de-reclamaciones',
		),
		'privacidad' => array(
			'title' => 'Política de privacidad',
			'slug'  => 'politica-de-privacidad',
		),
		'terminos'   => array(
			'title' => 'Términos y condiciones',
			'slug'  => 'terminos-y-condiciones',
		),
	);
}

/**
 * ID de una página legal publicada (0 si no existe).
 *
 * @param string $key reclamos|privacidad|terminos.
 * @return int
 */
function curamba_cc_legal_page_id( $key ) {
	$id = (int) get_option( 'curamba_cc_page_' . $key, 0 );
	if ( $id && 'publish' === get_post_status( $id ) ) {
		return $id;
	}
	return 0;
}

/** Bloque de párrafo de Gutenberg. */
function curamba_cc_p( $html ) {
	return "<!-- wp:paragraph -->\n<p>" . $html . "</p>\n<!-- /wp:paragraph -->\n\n";
}
/** Bloque de título de Gutenberg. */
function curamba_cc_h( $text ) {
	return "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . $text . "</h2>\n<!-- /wp:heading -->\n\n";
}
/** Bloque de lista de Gutenberg. */
function curamba_cc_ul( $items ) {
	$li = '';
	foreach ( $items as $i ) {
		$li .= "<!-- wp:list-item -->\n<li>" . $i . "</li>\n<!-- /wp:list-item -->\n";
	}
	return "<!-- wp:list -->\n<ul class=\"wp-block-list\">" . $li . "</ul>\n<!-- /wp:list -->\n\n";
}

/**
 * Texto inicial (borrador) de cada página.
 *
 * @param string $key Página.
 * @return string
 */
function curamba_cc_legal_template( $key ) {
	$empresa = '[curamba_dato campo="razon_social"] (RUC [curamba_dato campo="ruc"])';
	$aviso   = curamba_cc_p( '<em>Última actualización: ' . esc_html( curamba_cc_format_date( wp_date( 'Y-m-d' ) ) ) . '. Los textos entre corchetes deben completarse y el documento debe revisarlo un abogado antes de publicarse.</em>' );

	if ( 'reclamos' === $key ) {
		return curamba_cc_p( 'Conforme a lo establecido en el Código de Protección y Defensa del Consumidor (Ley N.° 29571), ponemos a tu disposición nuestro Libro de Reclamaciones virtual.' )
			. "<!-- wp:shortcode -->\n[curamba_libro_reclamaciones]\n<!-- /wp:shortcode -->\n";
	}

	if ( 'privacidad' === $key ) {
		return $aviso
			. curamba_cc_h( '1. Responsable del tratamiento' )
			. curamba_cc_p( $empresa . ', con domicilio en [curamba_dato campo="direccion"], es responsable del tratamiento de los datos personales que nos proporcionas a través de este sitio web, de WhatsApp y de nuestros canales de atención. Correo de contacto: [curamba_dato campo="email"].' )
			. curamba_cc_h( '2. Datos que recopilamos' )
			. curamba_cc_ul(
				array(
					'Datos de identificación y contacto: nombres, apellidos, documento de identidad, teléfono, correo electrónico y dirección.',
					'Datos de la reserva: experiencia, fecha, número de personas y requerimientos especiales (por ejemplo, alimentación o movilidad) que decidas compartir.',
					'Datos de pago: los pagos con tarjeta los procesa directamente la pasarela de pago; no almacenamos los números de tu tarjeta.',
					'Datos de navegación: dirección IP, tipo de navegador y páginas visitadas, mediante cookies (ver punto 7).',
				)
			)
			. curamba_cc_h( '3. Para qué usamos tus datos' )
			. curamba_cc_ul(
				array(
					'Gestionar tus reservas, pagos, comprobantes y la prestación de las experiencias contratadas.',
					'Responder tus consultas, reclamos y quejas (incluido el Libro de Reclamaciones).',
					'Cumplir obligaciones legales, tributarias y de seguridad turística.',
					'Enviarte promociones e información de nuevas experiencias, <strong>solo si nos das tu consentimiento</strong>. Puedes retirarlo cuando quieras.',
				)
			)
			. curamba_cc_h( '4. Con quién compartimos tus datos' )
			. curamba_cc_p( 'Solo con quienes necesitamos para prestar el servicio: guías y proveedores de la experiencia (transporte, alimentación, alojamiento), la pasarela de pago [nombre de la pasarela], el proveedor de hosting de este sitio [nombre del hosting], WhatsApp (Meta) cuando nos escribes por ese medio y, si están activas, herramientas de medición como Google Analytics y Meta Pixel. Algunos de estos proveedores pueden estar fuera del Perú; en ese caso, la transferencia se realiza con las garantías que exige la ley. No vendemos tus datos.' )
			. curamba_cc_h( '5. Cuánto tiempo los conservamos' )
			. curamba_cc_p( 'Mientras dure la relación comercial y, después, durante los plazos que exigen las normas tributarias y de protección al consumidor (los reclamos se conservan como mínimo dos años). Los datos para publicidad se conservan hasta que retires tu consentimiento.' )
			. curamba_cc_h( '6. Tus derechos' )
			. curamba_cc_p( 'Puedes ejercer tus derechos de información, acceso, rectificación, cancelación, oposición y revocación del consentimiento escribiendo a [curamba_dato campo="email"] con una copia de tu documento de identidad. Te responderemos en los plazos previstos por la Ley N.° 29733, Ley de Protección de Datos Personales, y su Reglamento. Si no estás conforme con la respuesta, puedes acudir a la Autoridad Nacional de Protección de Datos Personales del Ministerio de Justicia y Derechos Humanos.' )
			. curamba_cc_p( 'Banco de datos inscrito en el Registro Nacional de Protección de Datos Personales con el código [código de inscripción, si corresponde].' )
			. curamba_cc_h( '7. Cookies' )
			. curamba_cc_p( 'Usamos cookies necesarias para que funcionen el carrito y las reservas y, si están activas, cookies de medición y publicidad (Google Analytics, Meta Pixel) para saber cómo se usa el sitio. Puedes borrarlas o bloquearlas desde la configuración de tu navegador.' )
			. curamba_cc_h( '8. Seguridad' )
			. curamba_cc_p( 'El sitio usa conexión cifrada (HTTPS) y aplicamos medidas técnicas y organizativas razonables para proteger tus datos frente a accesos no autorizados, pérdida o alteración.' )
			. curamba_cc_h( '9. Cambios' )
			. curamba_cc_p( 'Podemos actualizar esta política. La versión vigente es siempre la publicada en esta página, con su fecha de actualización.' );
	}

	// Términos y condiciones.
	return $aviso
		. curamba_cc_h( '1. Quiénes somos' )
		. curamba_cc_p( 'Este sitio web es operado por ' . $empresa . ', con domicilio en [curamba_dato campo="direccion"]. Registro de agencia de viajes y turismo: [curamba_dato campo="mincetur"]. Contacto: [curamba_dato campo="email"] · [curamba_dato campo="telefono"].' )
		. curamba_cc_p( 'Al reservar una experiencia aceptas estos términos y nuestra [curamba_dato campo="privacidad"].' )
		. curamba_cc_h( '2. Reservas' )
		. curamba_cc_ul(
			array(
				'La reserva queda confirmada cuando recibimos el pago [total / adelanto del X %] y te enviamos la confirmación por correo o WhatsApp.',
				'Cada experiencia tiene fechas y cupos limitados. La cantidad indicada en la reserva corresponde al número de personas.',
				'Los pedidos pagados por transferencia o depósito apartan los cupos por un plazo limitado; si no recibimos el comprobante en ese plazo, la reserva se cancela automáticamente.',
				'Debes indicarnos al reservar cualquier condición de salud, alergia o necesidad especial de los participantes.',
			)
		)
		. curamba_cc_h( '3. Precios y pagos' )
		. curamba_cc_p( 'Los precios están expresados en soles (S/) e [incluyen / no incluyen] el IGV. Cada experiencia detalla qué incluye y qué no. Medios de pago aceptados: [Yape, Plin, transferencia, tarjeta…]. Emitimos [boleta / factura] por cada compra.' )
		. curamba_cc_h( '4. Cambios y cancelaciones por parte del cliente' )
		. curamba_cc_ul(
			array(
				'Con más de [X] días de anticipación: reembolso del [X] % o cambio de fecha sin costo.',
				'Entre [X] y [X] días antes: reembolso del [X] % o cambio de fecha según disponibilidad.',
				'Con menos de [X] horas o si no te presentas: [sin reembolso].',
				'Los reembolsos se realizan por el mismo medio de pago en un plazo de [X] días hábiles.',
			)
		)
		. curamba_cc_h( '5. Cambios y cancelaciones por parte de la agencia' )
		. curamba_cc_p( 'Por seguridad, podemos modificar el itinerario, el horario o reprogramar la salida por clima adverso, bloqueos de vías, disposiciones de las autoridades u otras causas de fuerza mayor. Si cancelamos una salida, podrás elegir entre otra fecha o el reembolso total de lo pagado. Si no se alcanza el número mínimo de participantes ([X] personas), te avisaremos con al menos [X] horas de anticipación.' )
		. curamba_cc_h( '6. Responsabilidades del participante' )
		. curamba_cc_ul(
			array(
				'Llegar puntual al punto de encuentro con su documento de identidad.',
				'Seguir las indicaciones del guía y respetar el patrimonio arqueológico, el medio ambiente y las comunidades locales.',
				'Los menores de edad deben participar acompañados por su padre, madre o un adulto responsable.',
				'Elegir experiencias acordes a su condición física según el nivel de dificultad indicado.',
			)
		)
		. curamba_cc_h( '7. Reclamos' )
		. curamba_cc_p( 'Si algo no salió como esperabas, escríbenos a [curamba_dato campo="email"] o regístralo en nuestro [curamba_dato campo="libro"]. Responderemos en un plazo máximo de 15 días hábiles.' )
		. curamba_cc_h( '8. Ley aplicable' )
		. curamba_cc_p( 'Estos términos se rigen por las leyes del Perú, en particular por el Código de Protección y Defensa del Consumidor (Ley N.° 29571).' );
}

/**
 * Crea las páginas legales que falten y las enlaza con WordPress y WooCommerce.
 *
 * @return int Número de páginas creadas.
 */
function curamba_cc_create_legal_pages() {
	$created = 0;
	foreach ( curamba_cc_legal_pages() as $key => $p ) {
		if ( curamba_cc_legal_page_id( $key ) ) {
			continue;
		}
		$id = wp_insert_post(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'post_title'     => $p['title'],
				'post_name'      => $p['slug'],
				'post_content'   => curamba_cc_legal_template( $key ),
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			continue;
		}
		update_option( 'curamba_cc_page_' . $key, (int) $id );
		++$created;
	}
	if ( curamba_cc_legal_page_id( 'privacidad' ) ) {
		update_option( 'wp_page_for_privacy_policy', curamba_cc_legal_page_id( 'privacidad' ) );
	}
	if ( curamba_cc_legal_page_id( 'terminos' ) ) {
		update_option( 'woocommerce_terms_page_id', curamba_cc_legal_page_id( 'terminos' ) );
	}
	return $created;
}

add_action(
	'admin_post_curamba_cc_legal_pages',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sin permiso.', 'curamba-cinematic' ) );
		}
		check_admin_referer( 'curamba_cc_legal_pages' );
		$n = curamba_cc_create_legal_pages();
		wp_safe_redirect( add_query_arg( 'cc_legal', $n, admin_url( 'options-general.php?page=curamba-cc' ) ) );
		exit;
	}
);

add_action(
	'admin_notices',
	function () {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['cc_legal'] ) && current_user_can( 'manage_options' ) ) {
			$n = absint( $_GET['cc_legal'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			printf( '<div class="notice notice-success is-dismissible"><p>%s</p></div>', esc_html( $n ? sprintf( 'Se crearon %d páginas legales. Revisa y completa los textos entre corchetes.', $n ) : 'Las páginas legales ya existían: no se modificó nada.' ) );
		}
	}
);

/* =========================================================
   Libro de Reclamaciones virtual
   ========================================================= */

add_action(
	'init',
	function () {
		register_post_type(
			'cc_reclamo',
			array(
				'labels'          => array(
					'name'          => 'Libro de Reclamaciones',
					'singular_name' => 'Reclamo',
					'menu_name'     => 'Reclamaciones',
					'edit_item'     => 'Hoja de reclamación',
					'not_found'     => 'No hay reclamos registrados.',
					'search_items'  => 'Buscar reclamos',
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => true,
				'show_in_rest'    => false,
				'menu_icon'       => 'dashicons-book-alt',
				'menu_position'   => 58,
				'supports'        => array( 'title' ),
				'capability_type' => 'post',
				'capabilities'    => array(
					'create_posts'       => 'do_not_allow', // Solo se crean desde el formulario público.
					'edit_post'          => 'manage_options',
					'read_post'          => 'manage_options',
					'delete_post'        => 'do_not_allow', // Deben conservarse (mínimo 2 años).
					'edit_posts'         => 'manage_options',
					'edit_others_posts'  => 'manage_options',
					'publish_posts'      => 'manage_options',
					'read_private_posts' => 'manage_options',
					'delete_posts'       => 'do_not_allow',
				),
				'map_meta_cap'    => false,
			)
		);
	}
);

/**
 * Suma días hábiles (lunes a viernes) a una fecha. No descuenta feriados.
 *
 * @param string $date AAAA-MM-DD.
 * @param int    $days Días hábiles.
 * @return string
 */
function curamba_cc_add_business_days( $date, $days ) {
	$t = strtotime( $date . ' 12:00:00 UTC' );
	while ( $days > 0 ) {
		$t += DAY_IN_SECONDS;
		if ( (int) gmdate( 'N', $t ) < 6 ) {
			--$days;
		}
	}
	return gmdate( 'Y-m-d', $t );
}

/**
 * Número correlativo del año: 00001-2026.
 *
 * @return string
 */
function curamba_cc_next_claim_number() {
	global $wpdb;
	$year = wp_date( 'Y' );
	$opt  = 'curamba_cc_reclamo_seq_' . $year;
	add_option( $opt, 0, '', 'no' );
	// Incremento atómico en la base de datos (dos reclamos simultáneos nunca reciben el mismo número).
	$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = option_value + 1 WHERE option_name = %s", $opt ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	wp_cache_delete( $opt, 'options' );
	wp_cache_delete( 'notoptions', 'options' );
	$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $opt ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	return str_pad( (string) max( 1, $n ), 5, '0', STR_PAD_LEFT ) . '-' . $year;
}

/**
 * Campos de la hoja de reclamación.
 *
 * @return array clave => etiqueta
 */
function curamba_cc_claim_labels() {
	return array(
		'numero'      => 'N.° de hoja',
		'fecha'       => 'Fecha',
		'nombre'      => 'Nombres y apellidos',
		'doc_tipo'    => 'Tipo de documento',
		'doc_num'     => 'N.° de documento',
		'domicilio'   => 'Domicilio',
		'telefono'    => 'Teléfono',
		'email'       => 'Correo electrónico',
		'menor'       => 'Menor de edad',
		'apoderado'   => 'Padre, madre o apoderado',
		'bien'        => 'Bien contratado',
		'monto'       => 'Monto reclamado (S/)',
		'descripcion' => 'Descripción del producto o servicio',
		'tipo'        => 'Tipo',
		'detalle'     => 'Detalle',
		'pedido'      => 'Pedido del consumidor',
	);
}

/** ¿La página actual muestra el formulario? (para no guardarla en caché). */
function curamba_cc_is_claim_page() {
	if ( ! is_singular() ) {
		return false;
	}
	$post = get_post();
	return $post && has_shortcode( (string) $post->post_content, 'curamba_libro_reclamaciones' );
}

add_action(
	'template_redirect',
	function () {
		if ( ! curamba_cc_is_claim_page() ) {
			return;
		}
		nocache_headers();
		do_action( 'litespeed_control_set_nocache', 'curamba libro de reclamaciones' ); // LiteSpeed Cache.
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // Otros plugins de caché.
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) && isset( $_POST['cc_claim'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			curamba_cc_handle_claim();
		}
	},
	5
);

/**
 * Procesa el envío del formulario (patrón POST → redirección → GET).
 */
function curamba_cc_handle_claim() {
	$back = get_permalink();
	// phpcs:disable WordPress.Security.NonceVerification.Missing
	$post = wp_unslash( $_POST );
	// phpcs:enable

	$errors = array();
	if ( ! isset( $post['cc_claim_nonce'] ) || ! wp_verify_nonce( $post['cc_claim_nonce'], 'cc_claim' ) ) {
		$errors[] = 'La página estuvo abierta demasiado tiempo. Vuelve a enviar el formulario.';
	}
	// Trampas para robots: campo oculto que una persona nunca llena y envío demasiado rápido.
	if ( ! empty( $post['cc_web'] ) || ( isset( $post['cc_t'] ) && ( time() - (int) $post['cc_t'] ) < 4 ) ) {
		wp_safe_redirect( $back );
		exit;
	}
	$rate_key = 'cc_claim_rate_' . md5( curamba_cc_client_ip() );
	if ( (int) get_transient( $rate_key ) >= 5 ) {
		$errors[] = 'Recibimos varios reclamos desde tu conexión en poco tiempo. Inténtalo en una hora o escríbenos al correo de atención.';
	}

	$d = array(
		'nombre'      => sanitize_text_field( isset( $post['nombre'] ) ? $post['nombre'] : '' ),
		'doc_tipo'    => sanitize_text_field( isset( $post['doc_tipo'] ) ? $post['doc_tipo'] : '' ),
		'doc_num'     => sanitize_text_field( isset( $post['doc_num'] ) ? $post['doc_num'] : '' ),
		'domicilio'   => sanitize_text_field( isset( $post['domicilio'] ) ? $post['domicilio'] : '' ),
		'telefono'    => sanitize_text_field( isset( $post['telefono'] ) ? $post['telefono'] : '' ),
		'email'       => sanitize_email( isset( $post['email'] ) ? $post['email'] : '' ),
		'menor'       => ! empty( $post['menor'] ) ? 'Sí' : 'No',
		'apoderado'   => sanitize_text_field( isset( $post['apoderado'] ) ? $post['apoderado'] : '' ),
		'bien'        => ( isset( $post['bien'] ) && 'producto' === $post['bien'] ) ? 'Producto' : 'Servicio',
		'monto'       => '' !== trim( (string) ( isset( $post['monto'] ) ? $post['monto'] : '' ) ) ? number_format( max( 0, (float) str_replace( ',', '.', $post['monto'] ) ), 2, '.', '' ) : '',
		'descripcion' => sanitize_textarea_field( isset( $post['descripcion'] ) ? $post['descripcion'] : '' ),
		'tipo'        => ( isset( $post['tipo'] ) && 'queja' === $post['tipo'] ) ? 'Queja' : 'Reclamo',
		'detalle'     => sanitize_textarea_field( isset( $post['detalle'] ) ? $post['detalle'] : '' ),
		'pedido'      => sanitize_textarea_field( isset( $post['pedido'] ) ? $post['pedido'] : '' ),
	);
	if ( ! in_array( $d['doc_tipo'], array( 'DNI', 'Carné de extranjería', 'Pasaporte', 'RUC' ), true ) ) {
		$d['doc_tipo'] = 'DNI';
	}

	$required = array( 'nombre', 'doc_num', 'domicilio', 'telefono', 'email', 'descripcion', 'detalle', 'pedido' );
	foreach ( $required as $k ) {
		if ( '' === $d[ $k ] ) {
			$errors[] = 'Completa el campo: ' . curamba_cc_claim_labels()[ $k ] . '.';
		}
	}
	if ( '' !== $d['email'] && ! is_email( $d['email'] ) ) {
		$errors[] = 'El correo electrónico no es válido.';
	}
	if ( 'Sí' === $d['menor'] && '' === $d['apoderado'] ) {
		$errors[] = 'Si eres menor de edad, indica el nombre de tu padre, madre o apoderado.';
	}
	if ( empty( $post['acepto'] ) ) {
		$errors[] = 'Debes aceptar el tratamiento de tus datos para poder registrar el reclamo.';
	}
	foreach ( array( 'descripcion', 'detalle', 'pedido' ) as $k ) {
		$d[ $k ] = mb_substr( $d[ $k ], 0, 3000 );
	}

	if ( $errors ) {
		$token = wp_generate_password( 20, false );
		set_transient( 'cc_claim_err_' . $token, array( 'errors' => $errors, 'data' => $d ), 15 * MINUTE_IN_SECONDS );
		wp_safe_redirect( add_query_arg( 'cc_e', $token, $back ) . '#cc-claim' );
		exit;
	}

	$d['numero'] = curamba_cc_next_claim_number();
	$d['fecha']  = wp_date( 'Y-m-d H:i' );
	$deadline    = curamba_cc_add_business_days( wp_date( 'Y-m-d' ), 15 );

	$id = wp_insert_post(
		array(
			'post_type'   => 'cc_reclamo',
			'post_status' => 'private',
			'post_title'  => 'N.° ' . $d['numero'] . ' · ' . $d['tipo'] . ' · ' . $d['nombre'],
		),
		true
	);
	if ( is_wp_error( $id ) ) {
		$token = wp_generate_password( 20, false );
		set_transient( 'cc_claim_err_' . $token, array( 'errors' => array( 'No se pudo registrar el reclamo. Inténtalo de nuevo o escríbenos al correo de atención.' ), 'data' => $d ), 15 * MINUTE_IN_SECONDS );
		wp_safe_redirect( add_query_arg( 'cc_e', $token, $back ) . '#cc-claim' );
		exit;
	}
	foreach ( $d as $k => $v ) {
		update_post_meta( $id, '_cc_' . $k, $v );
	}
	update_post_meta( $id, '_cc_limite', $deadline );
	update_post_meta( $id, '_cc_estado', 'pendiente' );
	update_post_meta( $id, '_cc_ip', curamba_cc_client_ip() );
	set_transient( $rate_key, (int) get_transient( $rate_key ) + 1, HOUR_IN_SECONDS );

	curamba_cc_send_claim_emails( $d, $deadline );

	$token = wp_generate_password( 20, false );
	set_transient( 'cc_claim_ok_' . $token, (int) $id, DAY_IN_SECONDS );
	wp_safe_redirect( add_query_arg( 'cc_ok', $token, $back ) . '#cc-claim' );
	exit;
}

/**
 * Tabla HTML con los datos de la hoja (para la confirmación y los correos).
 *
 * @param array $d Datos.
 * @return string
 */
function curamba_cc_claim_table( $d ) {
	$rows = '<tr><th colspan="2" style="text-align:left;padding:8px;background:#f2f7f4">Proveedor</th></tr>'
		. '<tr><td style="padding:6px 8px;color:#555">Razón social</td><td style="padding:6px 8px">' . esc_html( curamba_cc_company( 'razon_social' ) ) . '</td></tr>'
		. '<tr><td style="padding:6px 8px;color:#555">RUC</td><td style="padding:6px 8px">' . esc_html( curamba_cc_company( 'ruc' ) ) . '</td></tr>'
		. '<tr><td style="padding:6px 8px;color:#555">Domicilio</td><td style="padding:6px 8px">' . esc_html( curamba_cc_company( 'direccion' ) ) . '</td></tr>'
		. '<tr><th colspan="2" style="text-align:left;padding:8px;background:#f2f7f4">Hoja de reclamación</th></tr>';
	foreach ( curamba_cc_claim_labels() as $k => $label ) {
		if ( ! isset( $d[ $k ] ) || '' === (string) $d[ $k ] || ( 'apoderado' === $k && 'Sí' !== ( isset( $d['menor'] ) ? $d['menor'] : '' ) ) ) {
			continue;
		}
		$rows .= '<tr><td style="padding:6px 8px;color:#555;vertical-align:top;width:38%">' . esc_html( $label ) . '</td><td style="padding:6px 8px">' . nl2br( esc_html( (string) $d[ $k ] ) ) . '</td></tr>';
	}
	return '<table style="width:100%;border-collapse:collapse;border:1px solid #dfe9e3;font-size:14px">' . $rows . '</table>';
}

/**
 * Correos: copia al consumidor (obligatoria) y aviso a la agencia.
 *
 * @param array  $d        Datos.
 * @param string $deadline Fecha límite de respuesta.
 */
function curamba_cc_send_claim_emails( $d, $deadline ) {
	$name    = curamba_cc_company( 'nombre_comercial', false );
	$headers = array( 'Content-Type: text/html; charset=UTF-8' );
	$biz     = curamba_cc_company( 'email', false );
	$notes   = '<p style="font-size:13px;color:#555">' . curamba_cc_claim_legal_notes() . '</p>';

	$to_client = '<div style="font-family:Arial,sans-serif;max-width:640px">'
		. '<h2 style="color:#0b6b44">Registramos tu ' . esc_html( strtolower( $d['tipo'] ) ) . ' N.° ' . esc_html( $d['numero'] ) . '</h2>'
		. '<p>Hola ' . esc_html( $d['nombre'] ) . ', esta es la copia de tu hoja de reclamación. Te responderemos a este correo a más tardar el <strong>' . esc_html( curamba_cc_format_date( $deadline ) ) . '</strong>.</p>'
		. curamba_cc_claim_table( $d ) . $notes . '</div>';
	wp_mail( $d['email'], sprintf( '[%s] Copia de tu hoja de reclamación N.° %s', $name, $d['numero'] ), $to_client, array_merge( $headers, $biz ? array( 'Reply-To: ' . $biz ) : array() ) );

	if ( $biz ) {
		$to_biz = '<div style="font-family:Arial,sans-serif;max-width:640px">'
			. '<h2 style="color:#a01a4f">Nuevo ' . esc_html( strtolower( $d['tipo'] ) ) . ' en el Libro de Reclamaciones</h2>'
			. '<p><strong>Plazo para responder: ' . esc_html( curamba_cc_format_date( $deadline ) ) . '</strong> (15 días hábiles, revisa si hay feriados). Responde desde el panel: <em>Reclamaciones</em>.</p>'
			. curamba_cc_claim_table( $d ) . '</div>';
		wp_mail( $biz, sprintf( '[%s] Nuevo %s N.° %s', $name, strtolower( $d['tipo'] ), $d['numero'] ), $to_biz, array_merge( $headers, array( 'Reply-To: ' . $d['email'] ) ) );
	}
}

/** Notas legales que acompañan la hoja. */
function curamba_cc_claim_legal_notes() {
	return '<strong>Reclamo:</strong> disconformidad relacionada con los productos o servicios. '
		. '<strong>Queja:</strong> disconformidad no relacionada con los productos o servicios, o malestar o descontento respecto a la atención al público.<br>'
		. 'La formulación del reclamo no impide acudir a otras vías de solución de controversias ni es requisito previo para interponer una denuncia ante el INDECOPI.<br>'
		. 'El proveedor debe dar respuesta al reclamo o queja en un plazo no mayor a quince (15) días hábiles improrrogables.';
}

/** Formulario público: [curamba_libro_reclamaciones]. */
add_shortcode(
	'curamba_libro_reclamaciones',
	function () {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$ok  = isset( $_GET['cc_ok'] ) ? sanitize_key( wp_unslash( $_GET['cc_ok'] ) ) : '';
		$err = isset( $_GET['cc_e'] ) ? sanitize_key( wp_unslash( $_GET['cc_e'] ) ) : '';
		// phpcs:enable
		ob_start();
		echo '<div class="cc-claim" id="cc-claim">';

		if ( $ok ) {
			$id = (int) get_transient( 'cc_claim_ok_' . $ok );
			if ( $id && 'cc_reclamo' === get_post_type( $id ) ) {
				$d = array();
				foreach ( array_keys( curamba_cc_claim_labels() ) as $k ) {
					$d[ $k ] = (string) get_post_meta( $id, '_cc_' . $k, true );
				}
				echo '<div class="cc-claim__ok" role="status">';
				echo '<h2>' . esc_html( sprintf( 'Tu %s fue registrado con el N.° %s', strtolower( $d['tipo'] ), $d['numero'] ) ) . '</h2>';
				echo '<p>' . esc_html( sprintf( 'Enviamos una copia a %s. Te responderemos a más tardar el %s. Guarda o imprime esta hoja.', $d['email'], curamba_cc_format_date( (string) get_post_meta( $id, '_cc_limite', true ) ) ) ) . '</p>';
				echo curamba_cc_claim_table( $d ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado dentro.
				echo '<p class="cc-claim__actions"><button type="button" class="cc-claim__btn" onclick="window.print()">Imprimir</button></p>';
				echo '</div></div>';
				return ob_get_clean();
			}
		}

		$prev   = array();
		$errors = array();
		if ( $err ) {
			$t = get_transient( 'cc_claim_err_' . $err );
			if ( is_array( $t ) ) {
				$errors = $t['errors'];
				$prev   = $t['data'];
			}
		}
		$v = function ( $k ) use ( $prev ) {
			return isset( $prev[ $k ] ) ? (string) $prev[ $k ] : '';
		};
		$privacy = curamba_cc_legal_page_id( 'privacidad' );
		?>
		<div class="cc-claim__head">
			<div>
				<p class="cc-claim__date"><?php echo esc_html( 'Fecha: ' . curamba_cc_format_date( wp_date( 'Y-m-d' ) ) ); ?></p>
				<p><strong><?php echo esc_html( curamba_cc_company( 'razon_social' ) ); ?></strong> · <?php echo esc_html( 'RUC ' . curamba_cc_company( 'ruc' ) ); ?><br><?php echo esc_html( curamba_cc_company( 'direccion' ) ); ?></p>
			</div>
		</div>
		<?php if ( $errors ) : ?>
			<div class="cc-claim__errors" role="alert"><strong>Revisa lo siguiente:</strong><ul>
				<?php foreach ( $errors as $e ) : ?>
					<li><?php echo esc_html( $e ); ?></li>
				<?php endforeach; ?>
			</ul></div>
		<?php endif; ?>
		<form class="cc-claim__form" method="post" action="<?php echo esc_url( get_permalink() ); ?>#cc-claim" novalidate>
			<input type="hidden" name="cc_claim" value="1">
			<?php wp_nonce_field( 'cc_claim', 'cc_claim_nonce' ); ?>
			<input type="hidden" name="cc_t" value="<?php echo esc_attr( (string) time() ); ?>">
			<div class="cc-claim__hp" aria-hidden="true"><label>No llenar <input type="text" name="cc_web" tabindex="-1" autocomplete="off"></label></div>

			<fieldset>
				<legend>1. Identificación del consumidor</legend>
				<div class="cc-claim__grid">
					<p class="cc-claim__full"><label for="cc-nombre">Nombres y apellidos *</label><input id="cc-nombre" name="nombre" type="text" required autocomplete="name" value="<?php echo esc_attr( $v( 'nombre' ) ); ?>"></p>
					<p><label for="cc-doc-tipo">Tipo de documento *</label><select id="cc-doc-tipo" name="doc_tipo">
						<?php foreach ( array( 'DNI', 'Carné de extranjería', 'Pasaporte', 'RUC' ) as $o ) : ?>
							<option <?php selected( $v( 'doc_tipo' ), $o ); ?>><?php echo esc_html( $o ); ?></option>
						<?php endforeach; ?>
					</select></p>
					<p><label for="cc-doc-num">N.° de documento *</label><input id="cc-doc-num" name="doc_num" type="text" required value="<?php echo esc_attr( $v( 'doc_num' ) ); ?>"></p>
					<p class="cc-claim__full"><label for="cc-domicilio">Domicilio *</label><input id="cc-domicilio" name="domicilio" type="text" required autocomplete="street-address" value="<?php echo esc_attr( $v( 'domicilio' ) ); ?>"></p>
					<p><label for="cc-telefono">Teléfono *</label><input id="cc-telefono" name="telefono" type="tel" required autocomplete="tel" value="<?php echo esc_attr( $v( 'telefono' ) ); ?>"></p>
					<p><label for="cc-email">Correo electrónico *</label><input id="cc-email" name="email" type="email" required autocomplete="email" value="<?php echo esc_attr( $v( 'email' ) ); ?>"></p>
					<p class="cc-claim__full"><label class="cc-claim__check"><input type="checkbox" name="menor" value="1" <?php checked( 'Sí', $v( 'menor' ) ); ?>> Soy menor de edad</label></p>
					<p class="cc-claim__full"><label for="cc-apoderado">Nombre del padre, madre o apoderado (solo si eres menor de edad)</label><input id="cc-apoderado" name="apoderado" type="text" value="<?php echo esc_attr( $v( 'apoderado' ) ); ?>"></p>
				</div>
			</fieldset>

			<fieldset>
				<legend>2. Identificación del bien contratado</legend>
				<div class="cc-claim__grid">
					<p><span class="cc-claim__label">Tipo *</span>
						<label class="cc-claim__check"><input type="radio" name="bien" value="servicio" <?php checked( 'Producto' !== $v( 'bien' ) ); ?>> Servicio</label>
						<label class="cc-claim__check"><input type="radio" name="bien" value="producto" <?php checked( 'Producto', $v( 'bien' ) ); ?>> Producto</label>
					</p>
					<p><label for="cc-monto">Monto reclamado (S/)</label><input id="cc-monto" name="monto" type="number" min="0" step="0.01" inputmode="decimal" value="<?php echo esc_attr( $v( 'monto' ) ); ?>"></p>
					<p class="cc-claim__full"><label for="cc-descripcion">Descripción *</label><textarea id="cc-descripcion" name="descripcion" rows="2" required placeholder="Experiencia contratada, fecha y n.° de pedido si lo tienes"><?php echo esc_textarea( $v( 'descripcion' ) ); ?></textarea></p>
				</div>
			</fieldset>

			<fieldset>
				<legend>3. Detalle de la reclamación y pedido del consumidor</legend>
				<p class="cc-claim__types">
					<label class="cc-claim__check"><input type="radio" name="tipo" value="reclamo" <?php checked( 'Queja' !== $v( 'tipo' ) ); ?>> <strong>Reclamo</strong>: disconformidad relacionada con los productos o servicios.</label>
					<label class="cc-claim__check"><input type="radio" name="tipo" value="queja" <?php checked( 'Queja', $v( 'tipo' ) ); ?>> <strong>Queja</strong>: disconformidad no relacionada con los productos o servicios, o malestar o descontento respecto a la atención al público.</label>
				</p>
				<p><label for="cc-detalle">Detalle *</label><textarea id="cc-detalle" name="detalle" rows="5" required maxlength="3000"><?php echo esc_textarea( $v( 'detalle' ) ); ?></textarea></p>
				<p><label for="cc-pedido">Pedido *</label><textarea id="cc-pedido" name="pedido" rows="3" required maxlength="3000" placeholder="¿Qué solución esperas?"><?php echo esc_textarea( $v( 'pedido' ) ); ?></textarea></p>
			</fieldset>

			<p><label class="cc-claim__check"><input type="checkbox" name="acepto" value="1" required> Declaro que los datos son verdaderos y acepto que <?php echo esc_html( curamba_cc_company( 'nombre_comercial', false ) ); ?> los use para atender este reclamo, conforme a su <?php echo $privacy ? '<a href="' . esc_url( get_permalink( $privacy ) ) . '" target="_blank" rel="noopener">Política de privacidad</a>' : 'Política de privacidad'; ?>. *</label></p>
			<p><button type="submit" class="cc-claim__btn">Enviar hoja de reclamación</button></p>
			<p class="cc-claim__notes"><?php echo wp_kses( curamba_cc_claim_legal_notes(), array( 'strong' => array(), 'br' => array() ) ); ?></p>
		</form>
		<?php
		echo '</div>';
		return ob_get_clean();
	}
);

/* ---------- Panel: ver y responder reclamos ---------- */

add_filter(
	'manage_cc_reclamo_posts_columns',
	function () {
		return array(
			'title'     => 'Hoja',
			'cc_fecha'  => 'Fecha',
			'cc_limite' => 'Responder hasta',
			'cc_estado' => 'Estado',
		);
	}
);

add_action(
	'manage_cc_reclamo_posts_custom_column',
	function ( $col, $id ) {
		if ( 'cc_fecha' === $col ) {
			echo esc_html( (string) get_post_meta( $id, '_cc_fecha', true ) );
		} elseif ( 'cc_limite' === $col ) {
			$lim  = (string) get_post_meta( $id, '_cc_limite', true );
			$done = 'respondido' === get_post_meta( $id, '_cc_estado', true );
			$late = ! $done && $lim && $lim < wp_date( 'Y-m-d' );
			printf( '<span style="%s">%s</span>', $late ? 'color:#b32d2e;font-weight:700' : '', esc_html( $lim ? curamba_cc_format_date( $lim, true ) . ' ' . substr( $lim, 0, 4 ) : '' ) );
		} elseif ( 'cc_estado' === $col ) {
			echo 'respondido' === get_post_meta( $id, '_cc_estado', true ) ? '<span style="color:#0a7a3e">● Respondido</span>' : '<span style="color:#996800">● Pendiente</span>';
		}
	},
	10,
	2
);

add_action(
	'add_meta_boxes_cc_reclamo',
	function () {
		add_meta_box(
			'cc_reclamo_hoja',
			'Hoja de reclamación',
			function ( $post ) {
				$d = array();
				foreach ( array_keys( curamba_cc_claim_labels() ) as $k ) {
					$d[ $k ] = (string) get_post_meta( $post->ID, '_cc_' . $k, true );
				}
				echo curamba_cc_claim_table( $d ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado dentro.
				echo '<p><strong>Responder hasta:</strong> ' . esc_html( curamba_cc_format_date( (string) get_post_meta( $post->ID, '_cc_limite', true ) ) ) . ' (15 días hábiles; si hay feriados en medio, el plazo real es un poco mayor).</p>';
			},
			'cc_reclamo',
			'normal',
			'high'
		);
		add_meta_box(
			'cc_reclamo_respuesta',
			'Respuesta del proveedor (observaciones y acciones adoptadas)',
			function ( $post ) {
				wp_nonce_field( 'cc_reclamo_resp', 'cc_reclamo_resp_nonce' );
				$resp = (string) get_post_meta( $post->ID, '_cc_respuesta', true );
				$sent = (string) get_post_meta( $post->ID, '_cc_respuesta_enviada', true );
				echo '<textarea name="cc_respuesta" rows="7" style="width:100%">' . esc_textarea( $resp ) . '</textarea>';
				echo '<p><label><input type="checkbox" name="cc_enviar" value="1"> Enviar esta respuesta al correo del consumidor y marcar el reclamo como respondido</label></p>';
				if ( $sent ) {
					echo '<p style="color:#0a7a3e">✔ Respuesta enviada el ' . esc_html( $sent ) . '.</p>';
				}
			},
			'cc_reclamo',
			'normal',
			'default'
		);
		remove_meta_box( 'submitdiv', 'cc_reclamo', 'side' );
		add_meta_box(
			'cc_reclamo_guardar',
			'Guardar',
			function () {
				submit_button( 'Guardar', 'primary', 'save', false );
			},
			'cc_reclamo',
			'side',
			'high'
		);
	}
);

add_action(
	'save_post_cc_reclamo',
	function ( $id ) {
		if ( ! isset( $_POST['cc_reclamo_resp_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['cc_reclamo_resp_nonce'] ) ), 'cc_reclamo_resp' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$resp = isset( $_POST['cc_respuesta'] ) ? sanitize_textarea_field( wp_unslash( $_POST['cc_respuesta'] ) ) : '';
		update_post_meta( $id, '_cc_respuesta', $resp );
		if ( ! empty( $_POST['cc_enviar'] ) && '' !== $resp ) {
			$email  = (string) get_post_meta( $id, '_cc_email', true );
			$numero = (string) get_post_meta( $id, '_cc_numero', true );
			$name   = curamba_cc_company( 'nombre_comercial', false );
			$biz    = curamba_cc_company( 'email', false );
			$body   = '<div style="font-family:Arial,sans-serif;max-width:640px"><h2 style="color:#0b6b44">Respuesta a tu hoja de reclamación N.° ' . esc_html( $numero ) . '</h2><p>' . nl2br( esc_html( $resp ) ) . '</p><p>' . esc_html( curamba_cc_company( 'razon_social' ) . ' · RUC ' . curamba_cc_company( 'ruc' ) ) . '</p></div>';
			if ( is_email( $email ) && wp_mail( $email, sprintf( '[%s] Respuesta a tu hoja de reclamación N.° %s', $name, $numero ), $body, array_merge( array( 'Content-Type: text/html; charset=UTF-8' ), $biz ? array( 'Reply-To: ' . $biz ) : array() ) ) ) {
				update_post_meta( $id, '_cc_respuesta_enviada', wp_date( 'Y-m-d H:i' ) );
			}
			update_post_meta( $id, '_cc_estado', 'respondido' );
		}
	}
);

/* =========================================================
   Pie de página
   ========================================================= */

/** HTML del pie. */
function curamba_cc_footer_html() {
	$c       = curamba_cc_company_all();
	$libro   = curamba_cc_legal_page_id( 'reclamos' );
	$priv    = curamba_cc_legal_page_id( 'privacidad' );
	$terms   = curamba_cc_legal_page_id( 'terminos' );
	$wa      = curamba_cc_wa_url( curamba_cc_option_wa(), __( 'Hola, quiero información para visitar Curamba.', 'curamba-cinematic' ) );
	$socials = array_filter(
		array(
			'Facebook'  => $c['facebook'],
			'Instagram' => $c['instagram'],
			'TikTok'    => $c['tiktok'],
		)
	);
	ob_start();
	?>
	<footer class="cc-foot" role="contentinfo">
		<div class="cc-foot__in">
			<div class="cc-foot__brand">
				<strong class="cc-foot__name"><?php echo esc_html( $c['nombre_comercial'] ); ?></strong>
				<p><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
				<?php if ( $socials ) : ?>
					<p class="cc-foot__social">
						<?php foreach ( $socials as $label => $url ) : ?>
							<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $label ); ?></a>
						<?php endforeach; ?>
					</p>
				<?php endif; ?>
			</div>
			<div>
				<h2 class="cc-foot__h"><?php esc_html_e( 'Contacto', 'curamba-cinematic' ); ?></h2>
				<ul>
					<li><a href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener" data-cc-track="whatsapp_click" data-cc-label="pie">WhatsApp <?php echo esc_html( $c['telefono'] ); ?></a></li>
					<?php if ( is_email( $c['email'] ) ) : ?>
						<li><a href="mailto:<?php echo esc_attr( $c['email'] ); ?>"><?php echo esc_html( $c['email'] ); ?></a></li>
					<?php endif; ?>
					<?php if ( '' !== $c['direccion'] ) : ?>
						<li><?php echo esc_html( $c['direccion'] ); ?></li>
					<?php endif; ?>
				</ul>
			</div>
			<div>
				<h2 class="cc-foot__h"><?php esc_html_e( 'Información legal', 'curamba-cinematic' ); ?></h2>
				<ul>
					<?php if ( $terms ) : ?>
						<li><a href="<?php echo esc_url( get_permalink( $terms ) ); ?>"><?php esc_html_e( 'Términos y condiciones', 'curamba-cinematic' ); ?></a></li>
					<?php endif; ?>
					<?php if ( $priv ) : ?>
						<li><a href="<?php echo esc_url( get_permalink( $priv ) ); ?>"><?php esc_html_e( 'Política de privacidad', 'curamba-cinematic' ); ?></a></li>
					<?php endif; ?>
				</ul>
				<?php if ( $libro ) : ?>
					<a class="cc-foot__libro" href="<?php echo esc_url( get_permalink( $libro ) ); ?>">
						<svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true" focusable="false"><path fill="currentColor" d="M4 3h11a3 3 0 0 1 3 3v14a1 1 0 0 1-1 1H6a2 2 0 0 1-2-2V3Zm2 2v14h10V6a1 1 0 0 0-1-1H6Zm2 3h6v2H8V8Zm0 4h6v2H8v-2Zm12-6h1v15h-2V6h1Z"/></svg>
						<span><strong><?php esc_html_e( 'Libro de Reclamaciones', 'curamba-cinematic' ); ?></strong><small><?php esc_html_e( 'Registra tu reclamo o queja', 'curamba-cinematic' ); ?></small></span>
					</a>
				<?php endif; ?>
			</div>
		</div>
		<p class="cc-foot__legal">
			© <?php echo esc_html( wp_date( 'Y' ) . ' ' . curamba_cc_company( 'razon_social' ) . ' · RUC ' . curamba_cc_company( 'ruc' ) ); ?>
			<?php if ( '' !== $c['mincetur'] ) : ?>
				· <?php echo esc_html( 'Registro de agencia: ' . $c['mincetur'] ); ?>
			<?php endif; ?>
		</p>
	</footer>
	<?php
	return ob_get_clean();
}

add_shortcode( 'curamba_footer', 'curamba_cc_footer_html' );

add_action(
	'wp_footer',
	function () {
		if ( 'yes' !== get_option( 'curamba_cc_footer', 'yes' ) || is_admin() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['elementor-preview'] ) ) {
			return;
		}
		echo curamba_cc_footer_html(); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado dentro.
	},
	1
);

/** Oculta el pie de ejemplo de los temas de bloques (Twenty Twenty-Five, etc.). */
add_action(
	'wp_head',
	function () {
		if ( 'yes' === get_option( 'curamba_cc_footer', 'yes' ) && 'yes' === get_option( 'curamba_cc_hide_theme_footer', 'yes' ) && function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {
			echo "<style id=\"cc-hide-theme-footer\">.wp-site-blocks > footer.wp-block-template-part{display:none}</style>\n";
		}
	}
);
