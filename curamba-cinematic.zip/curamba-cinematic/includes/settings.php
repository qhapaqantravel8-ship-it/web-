<?php
/**
 * Ajustes → Curamba: WhatsApp de la agencia, administrador único y botones globales.
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'admin_init',
	function () {
		register_setting(
			'curamba_cc',
			'curamba_cc_whatsapp',
			array(
				'type'              => 'string',
				'default'           => '51933920638',
				'sanitize_callback' => function ( $v ) {
					$d = preg_replace( '/\D+/', '', (string) $v );
					if ( 9 === strlen( $d ) && '9' === $d[0] ) {
						$d = '51' . $d;
					}
					return $d ? $d : '51933920638';
				},
			)
		);
		register_setting(
			'curamba_cc',
			'curamba_cc_owner_login',
			array(
				'type'              => 'string',
				'default'           => 'CURAMBA2026-2',
				'sanitize_callback' => function ( $v ) {
					$v = sanitize_user( (string) $v, true );
					return '' !== $v ? $v : 'CURAMBA2026-2';
				},
			)
		);
		register_setting(
			'curamba_cc',
			'curamba_cc_hold_hours',
			array(
				'type'              => 'integer',
				'default'           => 48,
				'sanitize_callback' => function ( $v ) {
					return min( 720, max( 0, absint( $v ) ) );
				},
			)
		);
		foreach ( array( 'curamba_cc_lock', 'curamba_cc_wa_global', 'curamba_cc_wa_product' ) as $opt ) {
			register_setting(
				'curamba_cc',
				$opt,
				array(
					'type'              => 'string',
					'default'           => 'yes',
					'sanitize_callback' => function ( $v ) {
						return 'yes' === $v ? 'yes' : 'no';
					},
				)
			);
		}
	}
);

add_action(
	'admin_menu',
	function () {
		add_options_page( 'Curamba', 'Curamba', 'manage_options', 'curamba-cc', 'curamba_cc_settings_page' );
	}
);

/**
 * Pantalla de ajustes.
 */
function curamba_cc_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$owner  = curamba_cc_owner();
	$active = curamba_cc_lock_active();
	?>
	<div class="wrap">
		<h1>Curamba</h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'curamba_cc' ); ?>
			<h2><?php esc_html_e( 'WhatsApp', 'curamba-cinematic' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="curamba_cc_whatsapp"><?php esc_html_e( 'Número de WhatsApp', 'curamba-cinematic' ); ?></label></th>
					<td>
						<input type="text" id="curamba_cc_whatsapp" name="curamba_cc_whatsapp" class="regular-text" value="<?php echo esc_attr( curamba_cc_option_wa() ); ?>">
						<p class="description"><?php esc_html_e( 'Con código de país. Perú = 51. Ej.: 51933920638. Se usa en toda la web (el widget puede tener uno propio).', 'curamba-cinematic' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Botón flotante en toda la web', 'curamba-cinematic' ); ?></th>
					<td><label><input type="checkbox" name="curamba_cc_wa_global" value="yes" <?php checked( 'yes', get_option( 'curamba_cc_wa_global', 'yes' ) ); ?>> <?php esc_html_e( 'Mostrar botón de WhatsApp en todas las páginas', 'curamba-cinematic' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Botón en cada experiencia', 'curamba-cinematic' ); ?></th>
					<td><label><input type="checkbox" name="curamba_cc_wa_product" value="yes" <?php checked( 'yes', get_option( 'curamba_cc_wa_product', 'yes' ) ); ?>> <?php esc_html_e( 'Mostrar "Consultar por WhatsApp" en la página de cada producto', 'curamba-cinematic' ); ?></label></td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Reservas', 'curamba-cinematic' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="curamba_cc_hold_hours"><?php esc_html_e( 'Plazo para pagar una transferencia', 'curamba-cinematic' ); ?></label></th>
					<td>
						<input type="number" min="0" max="720" step="1" id="curamba_cc_hold_hours" name="curamba_cc_hold_hours" class="small-text" value="<?php echo esc_attr( get_option( 'curamba_cc_hold_hours', 48 ) ); ?>"> <?php esc_html_e( 'horas', 'curamba-cinematic' ); ?>
						<p class="description"><?php esc_html_e( 'Los pedidos por transferencia o depósito apartan los cupos al instante. Si siguen "En espera" pasado este plazo, se cancelan solos y los cupos vuelven a estar disponibles. 0 = no cancelar nunca (lo haces a mano).', 'curamba-cinematic' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Acceso exclusivo del administrador', 'curamba-cinematic' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Estado', 'curamba-cinematic' ); ?></th>
					<td>
						<?php if ( $active ) : ?>
							<strong style="color:#0a7a3e">● <?php esc_html_e( 'Activo: solo este usuario puede editar el sitio.', 'curamba-cinematic' ); ?></strong>
						<?php elseif ( ! $owner ) : ?>
							<strong style="color:#b32d2e">● <?php esc_html_e( 'Inactivo: el usuario todavía no existe o no es Administrador.', 'curamba-cinematic' ); ?></strong>
						<?php else : ?>
							<strong style="color:#996800">● <?php esc_html_e( 'Desactivado.', 'curamba-cinematic' ); ?></strong>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="curamba_cc_owner_login"><?php esc_html_e( 'Usuario administrador', 'curamba-cinematic' ); ?></label></th>
					<td>
						<input type="text" id="curamba_cc_owner_login" name="curamba_cc_owner_login" class="regular-text" value="<?php echo esc_attr( curamba_cc_owner_login() ); ?>" autocomplete="off">
						<p class="description"><?php esc_html_e( 'Nombre de usuario de WordPress con rol Administrador. La contraseña se cambia en Usuarios → Perfil (no se guarda en este plugin).', 'curamba-cinematic' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Bloqueo', 'curamba-cinematic' ); ?></th>
					<td><label><input type="checkbox" name="curamba_cc_lock" value="yes" <?php checked( 'yes', get_option( 'curamba_cc_lock', 'yes' ) ); ?>> <?php esc_html_e( 'Solo el usuario administrador puede entrar al panel y editar', 'curamba-cinematic' ); ?></label></td>
				</tr>
			</table>
			<?php do_action( 'curamba_cc_settings_sections' ); ?>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/* ---------- Estilos y botón flotante globales ---------- */

add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'curamba-cc-global', CURAMBA_CC_URL . 'assets/css/curamba-global.css', array(), CURAMBA_CC_VERSION );
	}
);

add_action(
	'wp_footer',
	function () {
		// El widget ya trae su propio botón flotante.
		if ( ! empty( $GLOBALS['curamba_cc_rendered'] ) || 'yes' !== get_option( 'curamba_cc_wa_global', 'yes' ) ) {
			return;
		}
		$msg = __( 'Hola, quiero información para visitar Curamba.', 'curamba-cinematic' );
		if ( function_exists( 'is_product' ) && is_product() ) {
			$msg = sprintf( /* translators: %s producto */ __( 'Hola, quiero reservar la experiencia: %s', 'curamba-cinematic' ), get_the_title() );
		}
		printf(
			'<a class="cc-g-wa" href="%1$s" target="_blank" rel="noopener" data-cc-track="whatsapp_click" data-cc-label="flotante_global">%2$s<span>%3$s</span></a>',
			esc_url( curamba_cc_wa_url( curamba_cc_option_wa(), $msg ) ),
			curamba_cc_wa_icon(), // phpcs:ignore WordPress.Security.EscapeOutput
			esc_html__( 'WhatsApp', 'curamba-cinematic' )
		);
	}
);

/** Medición de clics en WhatsApp/Reservar fuera del widget. */
add_action(
	'wp_footer',
	function () {
		if ( ! empty( $GLOBALS['curamba_cc_rendered'] ) ) {
			return; // El script del widget ya lo hace.
		}
		?>
		<script>
		document.addEventListener('click', function (e) {
			var a = e.target.closest && e.target.closest('[data-cc-track]');
			if (!a) return;
			var n = a.getAttribute('data-cc-track'), l = a.getAttribute('data-cc-label') || '';
			window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: 'curamba_' + n, curamba_label: l });
			if (typeof window.gtag === 'function') window.gtag('event', n, { event_category: 'curamba', event_label: l });
			if (typeof window.fbq === 'function') window.fbq('track', n === 'whatsapp_click' ? 'Contact' : 'InitiateCheckout');
		});
		</script>
		<?php
	},
	99
);
