<?php
/**
 * Medición y opiniones:
 * - Google Analytics 4: se pega el código G-XXXX en Ajustes → Curamba y se carga en toda la web
 *   (no cuenta las visitas del administrador).
 * - Opiniones de visitantes: botón "¿Qué te pareció la web?" con estrellas y comentarios.
 *   Las respuestas se guardan en la base de datos de este sitio (no se envían a servicios externos)
 *   y se ven en el panel, menú "Opiniones".
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =========================================================
   Ajustes
   ========================================================= */

/** Código de medición de GA4 válido o ''. */
function curamba_cc_ga_id() {
	$id = strtoupper( trim( (string) get_option( 'curamba_cc_ga_id', '' ) ) );
	return preg_match( '/^G-[A-Z0-9]{4,20}$/', $id ) ? $id : '';
}

add_action(
	'admin_init',
	function () {
		register_setting(
			'curamba_cc',
			'curamba_cc_ga_id',
			array(
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function ( $v ) {
					$v = strtoupper( trim( (string) $v ) );
					if ( '' !== $v && ! preg_match( '/^G-[A-Z0-9]{4,20}$/', $v ) ) {
						add_settings_error( 'curamba_cc_ga_id', 'cc_ga', 'El código de Google Analytics debe tener la forma G-XXXXXXXXXX. No se guardó.' );
						return (string) get_option( 'curamba_cc_ga_id', '' );
					}
					return $v;
				},
			)
		);
		register_setting(
			'curamba_cc',
			'curamba_cc_feedback',
			array(
				'type'              => 'string',
				'default'           => 'yes',
				'sanitize_callback' => function ( $v ) {
					return 'yes' === $v ? 'yes' : 'no';
				},
			)
		);
	}
);

add_action(
	'curamba_cc_settings_sections',
	function () {
		?>
		<h2>Medición y opiniones</h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="curamba_cc_ga_id">ID de Google Analytics 4</label></th>
				<td>
					<input type="text" id="curamba_cc_ga_id" name="curamba_cc_ga_id" class="regular-text" placeholder="G-XXXXXXXXXX" value="<?php echo esc_attr( get_option( 'curamba_cc_ga_id', '' ) ); ?>">
					<p class="description">En Google Analytics: <em>Administrar → Flujos de datos → tu web → ID de medición</em>. Se carga en toda la web y no cuenta tus visitas como administrador. Déjalo vacío para no medir. Para las pruebas usa una propiedad aparte ("Curamba – pruebas") y cámbiala por la definitiva al lanzar.</p>
					<?php if ( curamba_cc_ga_id() ) : ?>
						<p style="color:#0a7a3e">● Activo: <?php echo esc_html( curamba_cc_ga_id() ); ?>. Compruébalo en Google Analytics → Informes → <em>Tiempo real</em>, abriendo la web desde otro navegador o desde el celular.</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row">Opiniones de visitantes</th>
				<td>
					<label><input type="checkbox" name="curamba_cc_feedback" value="yes" <?php checked( 'yes', get_option( 'curamba_cc_feedback', 'yes' ) ); ?>> Mostrar el botón "¿Qué te pareció la web?"</label>
					<p class="description">Las respuestas quedan en el menú <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=cc_opinion' ) ); ?>">Opiniones</a>. Útil durante las pruebas; puedes apagarlo antes del lanzamiento.</p>
				</td>
			</tr>
		</table>
		<?php
	}
);

/* =========================================================
   Google Analytics 4
   ========================================================= */

add_action(
	'wp_head',
	function () {
		$id = curamba_cc_ga_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! $id || is_admin() || current_user_can( 'manage_options' ) || isset( $_GET['elementor-preview'] ) ) {
			return;
		}
		// phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- etiqueta oficial de Google.
		echo '<script async src="https://www.googletagmanager.com/gtag/js?id=' . esc_attr( $id ) . '"></script>' . "\n";
		echo '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("config",' . wp_json_encode( $id ) . ');</script>' . "\n";
	},
	1
);

/* =========================================================
   Opiniones
   ========================================================= */

add_action(
	'init',
	function () {
		register_post_type(
			'cc_opinion',
			array(
				'labels'          => array(
					'name'          => 'Opiniones',
					'singular_name' => 'Opinión',
					'menu_name'     => 'Opiniones',
					'edit_item'     => 'Opinión',
					'not_found'     => 'Todavía no hay opiniones.',
					'search_items'  => 'Buscar opiniones',
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => true,
				'show_in_rest'    => false,
				'menu_icon'       => 'dashicons-star-filled',
				'menu_position'   => 59,
				'supports'        => array( 'title' ),
				'capability_type' => 'post',
				'capabilities'    => array(
					'create_posts'        => 'do_not_allow',
					'edit_post'           => 'manage_options',
					'read_post'           => 'manage_options',
					'delete_post'         => 'manage_options',
					'edit_posts'          => 'manage_options',
					'edit_others_posts'   => 'manage_options',
					'publish_posts'       => 'manage_options',
					'read_private_posts'  => 'manage_options',
					'delete_posts'        => 'manage_options',
					'delete_others_posts' => 'manage_options',
					'delete_private_posts' => 'manage_options',
				),
				'map_meta_cap'    => false,
			)
		);
	}
);

/** Endpoint público para guardar una opinión: POST /wp-json/curamba/v1/opinion */
add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'curamba/v1',
			'/opinion',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return 'yes' === get_option( 'curamba_cc_feedback', 'yes' );
				},
				'callback'            => 'curamba_cc_save_opinion',
			)
		);
	}
);

/**
 * Guarda una opinión.
 *
 * @param WP_REST_Request $req Petición.
 * @return WP_REST_Response
 */
function curamba_cc_save_opinion( WP_REST_Request $req ) {
	// Trampas para robots: campo oculto y envío instantáneo.
	if ( '' !== (string) $req->get_param( 'web' ) || (int) $req->get_param( 'ms' ) < 2500 ) {
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}
	$rate_key = 'cc_op_rate_' . md5( curamba_cc_client_ip() );
	if ( (int) get_transient( $rate_key ) >= 10 ) {
		return new WP_REST_Response( array( 'ok' => false, 'msg' => 'Recibimos muchas opiniones desde tu conexión. Gracias, inténtalo más tarde.' ), 429 );
	}
	$stars = (int) $req->get_param( 'estrellas' );
	$like  = mb_substr( sanitize_textarea_field( (string) $req->get_param( 'gusto' ) ), 0, 1500 );
	$fix   = mb_substr( sanitize_textarea_field( (string) $req->get_param( 'mejora' ) ), 0, 1500 );
	$name  = mb_substr( sanitize_text_field( (string) $req->get_param( 'nombre' ) ), 0, 80 );
	if ( $stars < 1 || $stars > 5 ) {
		return new WP_REST_Response( array( 'ok' => false, 'msg' => 'Elige de 1 a 5 estrellas.' ), 400 );
	}
	$page   = esc_url_raw( (string) $req->get_param( 'pagina' ) );
	$path   = $page ? (string) wp_parse_url( $page, PHP_URL_PATH ) . ( wp_parse_url( $page, PHP_URL_QUERY ) ? '?' . wp_parse_url( $page, PHP_URL_QUERY ) : '' ) : '';
	$width  = (int) $req->get_param( 'ancho' );
	$device = $width && $width < 768 ? 'Celular' : ( $width && $width < 1100 ? 'Tablet' : 'Computadora' );

	$id = wp_insert_post(
		array(
			'post_type'   => 'cc_opinion',
			'post_status' => 'private',
			'post_title'  => str_repeat( '★', $stars ) . str_repeat( '☆', 5 - $stars ) . ( $name ? ' · ' . $name : '' ),
		),
		true
	);
	if ( is_wp_error( $id ) ) {
		return new WP_REST_Response( array( 'ok' => false, 'msg' => 'No se pudo guardar. Inténtalo de nuevo.' ), 500 );
	}
	update_post_meta( $id, '_cc_estrellas', $stars );
	update_post_meta( $id, '_cc_gusto', $like );
	update_post_meta( $id, '_cc_mejora', $fix );
	update_post_meta( $id, '_cc_nombre', $name );
	update_post_meta( $id, '_cc_pagina', mb_substr( $path, 0, 300 ) );
	update_post_meta( $id, '_cc_dispositivo', $device . ( $width ? ' (' . $width . ' px)' : '' ) );
	set_transient( $rate_key, (int) get_transient( $rate_key ) + 1, HOUR_IN_SECONDS );
	return new WP_REST_Response( array( 'ok' => true ), 200 );
}

/* ---------- Panel ---------- */

add_filter(
	'manage_cc_opinion_posts_columns',
	function () {
		return array(
			'cb'        => '<input type="checkbox">',
			'title'     => 'Calificación',
			'cc_gusto'  => 'Qué le gustó',
			'cc_mejora' => 'Qué mejoraría',
			'cc_donde'  => 'Página · dispositivo',
			'date'      => 'Fecha',
		);
	}
);

add_action(
	'manage_cc_opinion_posts_custom_column',
	function ( $col, $id ) {
		if ( 'cc_gusto' === $col || 'cc_mejora' === $col ) {
			echo nl2br( esc_html( (string) get_post_meta( $id, '_' . $col, true ) ) );
		} elseif ( 'cc_donde' === $col ) {
			echo esc_html( (string) get_post_meta( $id, '_cc_pagina', true ) ) . '<br><small>' . esc_html( (string) get_post_meta( $id, '_cc_dispositivo', true ) ) . '</small>';
		}
	},
	10,
	2
);

/** Resumen: promedio y total, arriba de la lista. */
add_action(
	'admin_notices',
	function () {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'edit-cc_opinion' !== $screen->id ) {
			return;
		}
		$ids = get_posts(
			array(
				'post_type'   => 'cc_opinion',
				'post_status' => 'private',
				'numberposts' => -1,
				'fields'      => 'ids',
			)
		);
		if ( ! $ids ) {
			return;
		}
		$sum = 0;
		foreach ( $ids as $id ) {
			$sum += (int) get_post_meta( $id, '_cc_estrellas', true );
		}
		printf( '<div class="notice notice-info"><p><strong>%s</strong> de 5 estrellas en promedio · %d opiniones</p></div>', esc_html( number_format_i18n( $sum / count( $ids ), 1 ) ), count( $ids ) );
	}
);

add_action(
	'add_meta_boxes_cc_opinion',
	function () {
		add_meta_box(
			'cc_opinion_detalle',
			'Detalle',
			function ( $post ) {
				$rows = array(
					'Estrellas'     => str_repeat( '★', (int) get_post_meta( $post->ID, '_cc_estrellas', true ) ),
					'Nombre'        => get_post_meta( $post->ID, '_cc_nombre', true ),
					'Qué le gustó'  => get_post_meta( $post->ID, '_cc_gusto', true ),
					'Qué mejoraría' => get_post_meta( $post->ID, '_cc_mejora', true ),
					'Página'        => get_post_meta( $post->ID, '_cc_pagina', true ),
					'Dispositivo'   => get_post_meta( $post->ID, '_cc_dispositivo', true ),
					'Fecha'         => get_the_date( 'Y-m-d H:i', $post ),
				);
				echo '<table class="widefat striped">';
				foreach ( $rows as $k => $v ) {
					echo '<tr><th style="width:160px">' . esc_html( $k ) . '</th><td>' . nl2br( esc_html( (string) $v ) ) . '</td></tr>';
				}
				echo '</table>';
			},
			'cc_opinion',
			'normal',
			'high'
		);
	}
);

/* ---------- Botón y formulario en la web ---------- */

/** ¿Se muestra el botón en esta página? */
function curamba_cc_feedback_visible() {
	if ( 'yes' !== get_option( 'curamba_cc_feedback', 'yes' ) || is_admin() ) {
		return false;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( isset( $_GET['elementor-preview'] ) ) {
		return false;
	}
	return ! ( function_exists( 'is_checkout' ) && is_checkout() );
}

add_action(
	'wp_footer',
	function () {
		if ( ! curamba_cc_feedback_visible() ) {
			return;
		}
		?>
		<div class="cc-fb" data-cc-fb>
			<button type="button" class="cc-fb__open" data-cc-fb-open aria-haspopup="dialog">★ ¿Qué te pareció la web?</button>
			<div class="cc-fb__back" data-cc-fb-panel hidden>
				<form class="cc-fb__box" role="dialog" aria-modal="true" aria-labelledby="cc-fb-title" data-cc-fb-form>
					<button type="button" class="cc-fb__x" data-cc-fb-close aria-label="Cerrar">×</button>
					<h2 id="cc-fb-title">¿Qué te pareció la web?</h2>
					<p class="cc-fb__sub">Tu opinión nos ayuda a mejorarla antes del lanzamiento.</p>
					<fieldset class="cc-fb__stars">
						<legend>Tu calificación *</legend>
						<?php for ( $i = 5; $i >= 1; $i-- ) : ?>
							<input type="radio" id="cc-fb-s<?php echo (int) $i; ?>" name="estrellas" value="<?php echo (int) $i; ?>"><label for="cc-fb-s<?php echo (int) $i; ?>" title="<?php echo (int) $i; ?> de 5"><span class="cc-sr"><?php echo (int) $i; ?> de 5</span>★</label>
						<?php endfor; ?>
					</fieldset>
					<label for="cc-fb-gusto">¿Qué te gustó?</label>
					<textarea id="cc-fb-gusto" name="gusto" rows="3" maxlength="1500"></textarea>
					<label for="cc-fb-mejora">¿Qué mejorarías o qué no funcionó?</label>
					<textarea id="cc-fb-mejora" name="mejora" rows="3" maxlength="1500"></textarea>
					<label for="cc-fb-nombre">Tu nombre (opcional)</label>
					<input id="cc-fb-nombre" name="nombre" type="text" maxlength="80" autocomplete="given-name">
					<div class="cc-fb__hp" aria-hidden="true"><input type="text" name="web" tabindex="-1" autocomplete="off"></div>
					<p class="cc-fb__msg" data-cc-fb-msg role="status" aria-live="polite"></p>
					<button type="submit" class="cc-fb__send">Enviar opinión</button>
				</form>
			</div>
		</div>
		<script>
		(function () {
			var root = document.querySelector('[data-cc-fb]'); if (!root) return;
			var panel = root.querySelector('[data-cc-fb-panel]'), form = root.querySelector('[data-cc-fb-form]'),
				msg = root.querySelector('[data-cc-fb-msg]'), openBtn = root.querySelector('[data-cc-fb-open]'), t0 = 0,
				blank = form.innerHTML, sent = false;
			function open() {
				if (sent) { form.innerHTML = blank; msg = form.querySelector('[data-cc-fb-msg]'); form.querySelector('[data-cc-fb-close]').addEventListener('click', close); sent = false; }
				panel.hidden = false; t0 = Date.now(); var s = form.querySelector('input[name=estrellas]'); s && s.focus(); document.addEventListener('keydown', esc);
			}
			function close() { panel.hidden = true; document.removeEventListener('keydown', esc); openBtn.focus(); }
			function esc(e) { if (e.key === 'Escape') close(); }
			openBtn.addEventListener('click', open);
			root.querySelector('[data-cc-fb-close]').addEventListener('click', close);
			panel.addEventListener('click', function (e) { if (e.target === panel) close(); });
			form.addEventListener('submit', function (e) {
				e.preventDefault();
				var fd = new FormData(form);
				if (!fd.get('estrellas')) { msg.textContent = 'Elige de 1 a 5 estrellas.'; return; }
				var data = { estrellas: fd.get('estrellas'), gusto: fd.get('gusto'), mejora: fd.get('mejora'), nombre: fd.get('nombre'), web: fd.get('web'),
					pagina: location.href, ancho: window.innerWidth, ms: Date.now() - t0 };
				var btn = form.querySelector('.cc-fb__send'); btn.disabled = true; msg.textContent = 'Enviando…';
				fetch(<?php echo wp_json_encode( esc_url_raw( rest_url( 'curamba/v1/opinion' ) ) ); ?>, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
					.then(function (r) { return r.json(); })
					.then(function (j) {
						if (j && j.ok) {
							sent = true;
							form.innerHTML = '<h2>¡Gracias! 💛</h2><p class="cc-fb__sub">Recibimos tu opinión.</p><button type="button" class="cc-fb__send" data-cc-fb-done>Cerrar</button>';
							form.querySelector('[data-cc-fb-done]').addEventListener('click', close);
							if (typeof window.gtag === 'function') window.gtag('event', 'opinion_enviada', { value: Number(data.estrellas) });
						} else { msg.textContent = (j && j.msg) || 'No se pudo enviar. Inténtalo de nuevo.'; btn.disabled = false; }
					})
					.catch(function () { msg.textContent = 'No se pudo enviar. Revisa tu conexión.'; btn.disabled = false; });
			});
		})();
		</script>
		<?php
	},
	30
);
