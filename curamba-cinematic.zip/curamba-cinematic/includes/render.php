<?php
/**
 * Marcado HTML de la portada cinematográfica (compartido por el widget y el shortcode).
 *
 * Orden de capas (de atrás hacia adelante):
 * 1 cielo · 2 paisaje lejano · 3 elementos intermedios · 4 atractivo principal · 5 título ·
 * 6 primer plano · 7 paneles de texto · 8 botones y navegación · 9 cabecera (Theme Builder, fuera del widget).
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Productos para el carrusel.
 *
 * @param array $s Ajustes.
 * @return WC_Product[]
 */
function curamba_cc_carousel_products( $s ) {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	$orderby = curamba_cc_get( $s, 's4_orderby' );
	$args    = array(
		'status'     => 'publish',
		'limit'      => min( 20, (int) curamba_cc_get( $s, 's4_count' ) > 0 ? (int) curamba_cc_get( $s, 's4_count' ) : 8 ),
		'visibility' => 'catalog',
		'orderby'    => in_array( $orderby, array( 'menu_order', 'date', 'price', 'title', 'popularity', 'rand' ), true ) ? $orderby : 'menu_order',
		'order'      => 'date' === $orderby || 'popularity' === $orderby ? 'DESC' : 'ASC',
	);
	if ( 'popularity' === $orderby ) {
		$args['orderby']  = 'meta_value_num';
		$args['meta_key'] = 'total_sales'; // phpcs:ignore WordPress.DB.SlowDBQuery
	}
	if ( 'price' === $orderby ) {
		$args['orderby']  = 'meta_value_num';
		$args['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery
	}
	$cats = array_filter( (array) curamba_cc_get( $s, 's4_categories' ) );
	if ( $cats ) {
		$args['category'] = array_map( 'sanitize_title', $cats );
	}
	return wc_get_products( $args );
}

/**
 * Tarjeta de experiencia del carrusel.
 *
 * @param array $d Datos de curamba_cc_product_data().
 * @param array $s Ajustes.
 * @return string
 */
function curamba_cc_card_html( $d, $s ) {
	ob_start();
	?>
	<article class="cc-card" data-cc-card>
		<a class="cc-card__media" href="<?php echo esc_url( $d['url'] ); ?>" tabindex="-1" aria-hidden="true">
			<?php
			if ( $d['imageId'] ) {
				echo wp_get_attachment_image( $d['imageId'], 'woocommerce_thumbnail', false, array( 'loading' => 'lazy', 'alt' => '', 'sizes' => '(max-width: 640px) 82vw, 420px' ) );
			} else {
				echo '<img src="' . esc_url( $d['image'] ) . '" alt="" loading="lazy">';
			}
			?>
		</a>
		<div class="cc-card__body">
			<?php if ( $d['category'] ) : ?>
				<span class="cc-card__cat"><?php echo esc_html( $d['category'] ); ?></span>
			<?php endif; ?>
			<h3 class="cc-card__title"><a href="<?php echo esc_url( $d['url'] ); ?>"><?php echo esc_html( $d['name'] ); ?></a></h3>
			<?php if ( $d['excerpt'] ) : ?>
				<p class="cc-card__text"><?php echo esc_html( $d['excerpt'] ); ?></p>
			<?php endif; ?>
			<ul class="cc-card__meta">
				<?php if ( $d['duration'] ) : ?>
					<li><span class="cc-sr"><?php esc_html_e( 'Duración:', 'curamba-cinematic' ); ?></span><?php echo esc_html( $d['duration'] ); ?></li>
				<?php endif; ?>
				<li class="<?php echo $d['inStock'] ? '' : 'is-out'; ?>"><span class="cc-sr"><?php esc_html_e( 'Disponibilidad:', 'curamba-cinematic' ); ?></span><?php echo esc_html( $d['availability'] ); ?></li>
			</ul>
			<div class="cc-card__foot">
				<span class="cc-card__price"><?php echo wp_kses_post( $d['priceHtml'] ); ?></span>
				<span class="cc-card__actions">
					<a class="cc-btn cc-btn--ghost cc-btn--sm" href="<?php echo esc_url( $d['url'] ); ?>"><?php echo esc_html( curamba_cc_get( $s, 's4_details_text' ) ); ?><span class="cc-sr"> — <?php echo esc_html( $d['name'] ); ?></span></a>
					<a class="cc-btn cc-btn--solid cc-btn--sm" href="<?php echo esc_url( $d['bookUrl'] ); ?>"
						data-cc-track="<?php echo $d['bookIsWa'] ? 'whatsapp_click' : 'reservar_click'; ?>"
						data-cc-label="<?php echo esc_attr( $d['name'] ); ?>"
						<?php echo $d['bookIsWa'] ? 'target="_blank" rel="noopener"' : ''; ?>><?php echo esc_html( curamba_cc_get( $s, 's4_book_text' ) ); ?><span class="cc-sr"> — <?php echo esc_html( $d['name'] ); ?></span></a>
				</span>
			</div>
		</div>
	</article>
	<?php
	return ob_get_clean();
}

/**
 * Renderiza el componente completo.
 *
 * @param array $s Ajustes del widget.
 * @return string
 */
function curamba_cc_render( $s ) {
	$GLOBALS['curamba_cc_rendered'] = true; // Evita duplicar el botón flotante global.
	$uid       = 'cc-' . wp_generate_password( 6, false, false );
	$wa_number = curamba_cc_get( $s, 'wa_number' );
	$wa_url    = curamba_cc_wa_url( $wa_number, curamba_cc_get( $s, 'wa_message' ) );
	$length    = curamba_cc_get( $s, 'motion_length' );
	$intensity = curamba_cc_get( $s, 'motion_intensity' );
	$flight    = curamba_cc_get( $s, 'motion_flight' );

	$config = array(
		'length'     => max( 2400, min( 9000, (int) ( is_array( $length ) ? $length['size'] : $length ) ) ),
		'intensity'  => max( 0, min( 150, (int) ( is_array( $intensity ) ? $intensity['size'] : $intensity ) ) ) / 100,
		'pointer'    => 'yes' === curamba_cc_get( $s, 'motion_pointer' ),
		'step'       => 'yes' === curamba_cc_get( $s, 'motion_step' ),
		'flight'     => max( 600, min( 4000, (int) ( is_array( $flight ) ? $flight['size'] : $flight ) ) ),
		'mobile'     => 'cinematic' === curamba_cc_get( $s, 'motion_mobile' ) ? 'cinematic' : 'static',
		'wa'         => preg_replace( '/\D+/', '', (string) $wa_number ),
		'waProduct'  => (string) curamba_cc_get( $s, 'wa_product_msg' ),
		'bookAction' => (string) curamba_cc_get( $s, 's4_book_action' ),
		'cats'       => implode( ',', array_map( 'sanitize_title', array_filter( (array) curamba_cc_get( $s, 's4_categories' ) ) ) ),
		'initial'    => max( 0, min( 24, (int) curamba_cc_get( $s, 's5_initial' ) ) ),
		'texts'      => array(
			'details' => (string) curamba_cc_get( $s, 's4_details_text' ),
			'book'    => (string) curamba_cc_get( $s, 's4_book_text' ),
		),
	);

	$products = curamba_cc_carousel_products( $s );
	$cards    = array();
	foreach ( $products as $product ) {
		$cards[] = curamba_cc_card_html( curamba_cc_product_data( $product, $s ), $s );
	}

	$cat_options = curamba_cc_category_options();
	if ( $config['cats'] ) {
		$cat_options = array_intersect_key( $cat_options, array_flip( explode( ',', $config['cats'] ) ) );
	}

	$all_link = curamba_cc_get( $s, 's5_all_link' );
	$all_url  = ( is_array( $all_link ) && ! empty( $all_link['url'] ) ) ? $all_link['url'] : curamba_cc_shop_url();

	ob_start();
	?>
	<div class="cc" id="<?php echo esc_attr( $uid ); ?>" data-cc-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
		<section class="cc-scroll" aria-label="<?php echo esc_attr( wp_strip_all_tags( curamba_cc_get( $s, 'hero_title' ) ) ); ?>">
			<div class="cc-stage">
				<div class="cc-skyl" aria-hidden="true"><span></span><span></span><span></span><span></span></div>
				<div class="cc-atmos" aria-hidden="true"><span class="cc-sun"></span><span class="cc-glow"></span></div>
				<div class="cc-world" data-cc-world>

					<!-- Capítulo 1 · Presentación. Cada capa vive a una profundidad distinta (--z) para un efecto 3D real. -->
					<div class="cc-ch cc-ch1" data-cc-ch="0" data-cc-scene="1" id="<?php echo esc_attr( $uid ); ?>-inicio">
						<?php
						$photo_mode = 'layers' !== curamba_cc_get( $s, 'hero_mode' );
						// En modo foto, las capas ilustradas solo aparecen si el administrador sube una imagen propia.
						$layer = function ( $key, $placeholder, $class, $z ) use ( $s, $photo_mode ) {
							$media = curamba_cc_get( $s, $key );
							$has   = is_array( $media ) && ( ! empty( $media['id'] ) || ! empty( $media['url'] ) );
							if ( $photo_mode && ! $has ) {
								return '';
							}
							return curamba_cc_layer_img( $media, $placeholder, $class, 'eager', 'full', $z );
						};
						echo curamba_cc_layer_img( curamba_cc_get( $s, 'img_sky' ), $photo_mode ? 'foto-campo' : 'cielo', 'cc-leaf cc-sky' . ( $photo_mode ? ' cc-sky--photo' : '' ), 'eager', 'full', -1400 ); // phpcs:ignore WordPress.Security.EscapeOutput
						echo $layer( 'img_far', 'paisaje-lejano', 'cc-leaf cc-far', -800 ); // phpcs:ignore WordPress.Security.EscapeOutput
						echo $layer( 'img_mid', 'intermedio', 'cc-leaf cc-mid', -480 ); // phpcs:ignore WordPress.Security.EscapeOutput
						echo $layer( 'img_main', 'atractivo', 'cc-leaf cc-main', -260 ); // phpcs:ignore WordPress.Security.EscapeOutput
						?>
						<h1 class="cc-leaf cc-hero-title" <?php echo curamba_cc_depth( 0 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( curamba_cc_get( $s, 'hero_title' ) ); ?></h1>
						<?php
						if ( $photo_mode ) {
							// Primer plano recortado de la misma foto: da profundidad real al inclinar/avanzar la cámara.
							$fg = curamba_cc_get( $s, 'img_fg_photo' );
							$sky_custom = curamba_cc_get( $s, 'img_sky' );
							$sky_is_custom = is_array( $sky_custom ) && ( ! empty( $sky_custom['id'] ) || ! empty( $sky_custom['url'] ) );
							$fg_is_custom  = is_array( $fg ) && ( ! empty( $fg['id'] ) || ! empty( $fg['url'] ) );
							if ( $fg_is_custom || ! $sky_is_custom ) {
								echo curamba_cc_layer_img( $fg, 'foto-campo-frente', 'cc-leaf cc-photo-fg', 'eager', 'full', 0 ); // phpcs:ignore WordPress.Security.EscapeOutput
							}
						}
						echo $layer( 'img_fg_left', 'primer-plano-izq', 'cc-leaf cc-fg cc-fg--left', 160 ); // phpcs:ignore WordPress.Security.EscapeOutput
						echo $layer( 'img_fg_right', 'primer-plano-der', 'cc-leaf cc-fg cc-fg--right', 160 ); // phpcs:ignore WordPress.Security.EscapeOutput
						?>
						<div class="cc-leaf cc-intro" <?php echo curamba_cc_depth( 0 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
							<p class="cc-intro__text"><?php echo esc_html( curamba_cc_get( $s, 'hero_text' ) ); ?></p>
							<?php $tags = (array) curamba_cc_get( $s, 'hero_tags' ); ?>
							<?php if ( $tags ) : ?>
								<ul class="cc-tags">
									<?php foreach ( $tags as $tag ) : ?>
										<?php if ( ! empty( $tag['tag'] ) ) : ?>
											<li><?php echo esc_html( $tag['tag'] ); ?></li>
										<?php endif; ?>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
							<div class="cc-actions">
								<a class="cc-btn cc-btn--gold" <?php echo curamba_cc_link_attrs( curamba_cc_get( $s, 'hero_btn_link' ), '#curamba-experiencias' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> data-cc-goto><?php echo esc_html( curamba_cc_get( $s, 'hero_btn_text' ) ); ?><span aria-hidden="true">→</span></a>
								<a class="cc-btn cc-btn--wa" href="<?php echo esc_url( $wa_url ); ?>" target="_blank" rel="noopener" data-cc-track="whatsapp_click" data-cc-label="hero"><?php echo curamba_cc_wa_icon(); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( curamba_cc_get( $s, 'hero_wa_text' ) ); ?></a>
							</div>
							<span class="cc-scroll-hint" aria-hidden="true"></span>
						</div>
					</div>

					<?php echo curamba_cc_clouds( array( -1150, -1600, -2100 ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

					<!-- Capítulo 2 · Historia y territorio -->
					<div class="cc-ch cc-ch2" data-cc-ch="1" data-cc-scene="2" id="<?php echo esc_attr( $uid ); ?>-historia">
						<?php echo curamba_cc_layer_img( curamba_cc_get( $s, 'img_bg2' ), 'foto-mirador', 'cc-leaf cc-ch-bg cc-ch2-bg', 'lazy', 'full', -900 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<div class="cc-leaf cc-ch2-grid" <?php echo curamba_cc_depth( 0 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
							<figure class="cc-frame">
								<?php echo curamba_cc_layer_img( curamba_cc_get( $s, 'img_close' ), 'foto-plataforma', 'cc-frame__img', 'lazy', 'large' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								<?php $caption = curamba_cc_get( $s, 's2_caption' ); ?>
								<?php if ( $caption ) : ?>
									<figcaption><?php echo esc_html( $caption ); ?></figcaption>
								<?php endif; ?>
							</figure>
							<div class="cc-panel">
								<h2 class="cc-panel__title"><?php echo esc_html( curamba_cc_get( $s, 's2_title' ) ); ?></h2>
								<p class="cc-panel__text"><?php echo nl2br( esc_html( curamba_cc_get( $s, 's2_text' ) ) ); ?></p>
								<?php $facts = (array) curamba_cc_get( $s, 's2_facts' ); ?>
								<?php if ( $facts ) : ?>
									<dl class="cc-facts">
										<?php foreach ( $facts as $fact ) : ?>
											<div>
												<dt><?php echo esc_html( isset( $fact['value'] ) ? $fact['value'] : '' ); ?></dt>
												<dd><?php echo esc_html( isset( $fact['label'] ) ? $fact['label'] : '' ); ?></dd>
											</div>
										<?php endforeach; ?>
									</dl>
								<?php endif; ?>
								<a class="cc-btn cc-btn--gold" <?php echo curamba_cc_link_attrs( curamba_cc_get( $s, 's2_btn_link' ), '#curamba-experiencias' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> data-cc-goto><?php echo esc_html( curamba_cc_get( $s, 's2_btn_text' ) ); ?><span aria-hidden="true">↗</span></a>
							</div>
						</div>
					</div>

					<?php echo curamba_cc_clouds( array( -3750, -4200, -4700 ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

					<!-- Capítulo 3 · Naturaleza y experiencias -->
					<div class="cc-ch cc-ch3" data-cc-ch="2" data-cc-scene="3" id="<?php echo esc_attr( $uid ); ?>-naturaleza">
						<?php echo curamba_cc_layer_img( curamba_cc_get( $s, 'img_bg3' ), 'foto-muro-valle', 'cc-leaf cc-ch-bg', 'lazy', 'full', -900 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<div class="cc-leaf cc-ch3-inner" <?php echo curamba_cc_depth( 0 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
							<h2 class="cc-panel__title cc-ch3-title"><?php echo esc_html( curamba_cc_get( $s, 's3_title' ) ); ?></h2>
							<?php $links = (array) curamba_cc_get( $s, 's3_links' ); ?>
							<?php if ( $links ) : ?>
								<ul class="cc-tiles">
									<?php
									$n = 0;
									foreach ( $links as $item ) :
										if ( empty( $item['label'] ) ) {
											continue;
										}
										$href = '';
										if ( ! empty( $item['link']['url'] ) ) {
											$href = $item['link']['url'];
										} elseif ( ! empty( $item['category'] ) && taxonomy_exists( 'product_cat' ) ) {
											$term_link = get_term_link( sanitize_title( $item['category'] ), 'product_cat' );
											$href      = is_wp_error( $term_link ) ? '' : $term_link;
										}
										if ( '' === $href ) {
											$href = curamba_cc_shop_url();
										}
										$has_img = ! empty( $item['image']['id'] ) || ! empty( $item['image']['url'] );
										?>
										<li class="cc-tile-wrap" style="--i:<?php echo (int) $n++; ?>">
											<a class="cc-tile<?php echo $has_img ? ' has-img' : ''; ?>" href="<?php echo esc_url( $href ); ?>" data-cc-tilt>
												<?php if ( $has_img ) : ?>
													<?php echo curamba_cc_layer_img( $item['image'], '', 'cc-tile__img', 'lazy', 'medium_large' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
												<?php endif; ?>
												<span class="cc-tile__icon"><?php echo curamba_cc_icon( isset( $item['icon'] ) ? $item['icon'] : '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
												<span class="cc-tile__label"><?php echo esc_html( $item['label'] ); ?></span>
												<span class="cc-tile__go" aria-hidden="true">→</span>
											</a>
										</li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
						</div>
					</div>

					<?php echo curamba_cc_clouds( array( -6350, -6800, -7300 ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

					<!-- Capítulo 4 · Carrusel de experiencias (productos WooCommerce) -->
					<div class="cc-ch cc-ch4" data-cc-ch="3" data-cc-scene="4" id="curamba-experiencias">
						<?php echo curamba_cc_layer_img( curamba_cc_get( $s, 'img_bg4' ), 'foto-valle', 'cc-leaf cc-ch-bg', 'lazy', 'full', -900 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<div class="cc-leaf cc-ch4-inner" <?php echo curamba_cc_depth( 0 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
							<div class="cc-s4__head">
								<h2 class="cc-kicker"><?php echo esc_html( curamba_cc_get( $s, 's4_kicker' ) ); ?></h2>
								<p class="cc-slider__status" aria-live="polite" data-cc-status></p>
							</div>
							<?php if ( $cards ) : ?>
								<div class="cc-slider" data-cc-slider role="region" aria-roledescription="carrusel" aria-label="<?php echo esc_attr( curamba_cc_get( $s, 's4_kicker' ) ); ?>" tabindex="0">
									<div class="cc-track" data-cc-rail>
										<?php echo implode( '', $cards ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
									</div>
								</div>
								<div class="cc-controls">
									<button type="button" class="cc-nav" data-cc-prev aria-label="<?php esc_attr_e( 'Experiencia anterior', 'curamba-cinematic' ); ?>">←</button>
									<div class="cc-dots" data-cc-dots></div>
									<button type="button" class="cc-nav" data-cc-next aria-label="<?php esc_attr_e( 'Experiencia siguiente', 'curamba-cinematic' ); ?>">→</button>
								</div>
							<?php else : ?>
								<p class="cc-empty">
									<?php
									echo esc_html(
										function_exists( 'wc_get_products' )
											? __( 'Aún no hay experiencias publicadas en las categorías elegidas. Crea productos en WooCommerce y aparecerán aquí automáticamente.', 'curamba-cinematic' )
											: __( 'Activa WooCommerce para mostrar las experiencias.', 'curamba-cinematic' )
									);
									?>
								</p>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- Escena 5: panel final de reserva -->
		<section class="cc-booking" id="<?php echo esc_attr( $uid ); ?>-reserva" aria-labelledby="<?php echo esc_attr( $uid ); ?>-reserva-title">
			<div class="cc-booking__inner">
				<h2 class="cc-booking__title" id="<?php echo esc_attr( $uid ); ?>-reserva-title"><?php echo esc_html( curamba_cc_get( $s, 's5_title' ) ); ?></h2>
				<p class="cc-booking__text"><?php echo esc_html( curamba_cc_get( $s, 's5_text' ) ); ?></p>

				<form class="cc-search" role="search" data-cc-search action="<?php echo esc_url( curamba_cc_shop_url() ); ?>" method="get">
					<div class="cc-field cc-field--q">
						<label for="<?php echo esc_attr( $uid ); ?>-q"><?php esc_html_e( 'Buscar', 'curamba-cinematic' ); ?></label>
						<input type="search" id="<?php echo esc_attr( $uid ); ?>-q" name="q" autocomplete="off" placeholder="<?php echo esc_attr( curamba_cc_get( $s, 's5_search_ph' ) ); ?>">
						<input type="hidden" name="post_type" value="product">
					</div>
					<?php if ( 'yes' === curamba_cc_get( $s, 's5_show_date' ) ) : ?>
						<div class="cc-field">
							<label for="<?php echo esc_attr( $uid ); ?>-fecha"><?php esc_html_e( 'Fecha', 'curamba-cinematic' ); ?></label>
							<input type="date" id="<?php echo esc_attr( $uid ); ?>-fecha" name="fecha" min="<?php echo esc_attr( wp_date( 'Y-m-d' ) ); ?>">
						</div>
					<?php endif; ?>
					<?php if ( 'yes' === curamba_cc_get( $s, 's5_show_category' ) && $cat_options ) : ?>
						<div class="cc-field">
							<label for="<?php echo esc_attr( $uid ); ?>-cat"><?php esc_html_e( 'Categoría', 'curamba-cinematic' ); ?></label>
							<select id="<?php echo esc_attr( $uid ); ?>-cat" name="cat">
								<option value=""><?php esc_html_e( 'Todas', 'curamba-cinematic' ); ?></option>
								<?php foreach ( $cat_options as $slug => $name ) : ?>
									<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $name ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					<?php endif; ?>
					<?php if ( 'yes' === curamba_cc_get( $s, 's5_show_price' ) ) : ?>
						<div class="cc-field cc-field--price">
							<span class="cc-field__label" id="<?php echo esc_attr( $uid ); ?>-price-l"><?php esc_html_e( 'Precio', 'curamba-cinematic' ); ?></span>
							<div class="cc-field__pair" role="group" aria-labelledby="<?php echo esc_attr( $uid ); ?>-price-l">
								<input type="number" name="min" min="0" step="1" inputmode="numeric" placeholder="<?php esc_attr_e( 'Mín.', 'curamba-cinematic' ); ?>" aria-label="<?php esc_attr_e( 'Precio mínimo', 'curamba-cinematic' ); ?>">
								<input type="number" name="max" min="0" step="1" inputmode="numeric" placeholder="<?php esc_attr_e( 'Máx.', 'curamba-cinematic' ); ?>" aria-label="<?php esc_attr_e( 'Precio máximo', 'curamba-cinematic' ); ?>">
							</div>
						</div>
					<?php endif; ?>
					<?php if ( 'yes' === curamba_cc_get( $s, 's5_show_duration' ) ) : ?>
						<div class="cc-field">
							<label for="<?php echo esc_attr( $uid ); ?>-dur"><?php esc_html_e( 'Duración', 'curamba-cinematic' ); ?></label>
							<select id="<?php echo esc_attr( $uid ); ?>-dur" name="duracion">
								<option value=""><?php esc_html_e( 'Cualquiera', 'curamba-cinematic' ); ?></option>
								<?php foreach ( curamba_cc_duration_ranges() as $key => $range ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $range[0] ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					<?php endif; ?>
					<?php if ( 'yes' === curamba_cc_get( $s, 's5_show_difficulty' ) ) : ?>
						<div class="cc-field">
							<label for="<?php echo esc_attr( $uid ); ?>-dif"><?php esc_html_e( 'Dificultad', 'curamba-cinematic' ); ?></label>
							<select id="<?php echo esc_attr( $uid ); ?>-dif" name="dificultad">
								<option value=""><?php esc_html_e( 'Cualquiera', 'curamba-cinematic' ); ?></option>
								<?php foreach ( curamba_cc_difficulties() as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					<?php endif; ?>
					<noscript><button type="submit" class="cc-btn cc-btn--solid"><?php esc_html_e( 'Buscar', 'curamba-cinematic' ); ?></button></noscript>
				</form>

				<p class="cc-results__status" aria-live="polite" data-cc-results-status></p>
				<ul class="cc-results" data-cc-results></ul>

				<div class="cc-actions cc-actions--center">
					<a class="cc-btn cc-btn--solid" href="<?php echo esc_url( $all_url ); ?>"><?php echo esc_html( curamba_cc_get( $s, 's5_all_text' ) ); ?></a>
					<a class="cc-btn cc-btn--wa" href="<?php echo esc_url( $wa_url ); ?>" target="_blank" rel="noopener" data-cc-track="whatsapp_click" data-cc-label="panel_reserva"><?php echo curamba_cc_wa_icon(); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( curamba_cc_get( $s, 's5_wa_text' ) ); ?></a>
				</div>
			</div>
		</section>

		<?php if ( 'yes' === curamba_cc_get( $s, 'wa_float' ) ) : ?>
			<a class="cc-wa-float" href="<?php echo esc_url( $wa_url ); ?>" target="_blank" rel="noopener" data-cc-track="whatsapp_click" data-cc-label="flotante">
				<?php echo curamba_cc_wa_icon(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<span><?php echo esc_html( curamba_cc_get( $s, 'wa_float_text' ) ); ?></span>
			</a>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Icono de WhatsApp (SVG en línea, decorativo).
 *
 * @return string
 */
function curamba_cc_wa_icon() {
	return '<svg class="cc-wa-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2Zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2l-.4-.3Z"/></svg>';
}
