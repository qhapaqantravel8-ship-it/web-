<?php
/**
 * Asistente de chat de Curamba (gratis, sin inteligencia artificial).
 *
 * - Burbuja de chat en toda la web.
 * - Preguntas frecuentes editables en Ajustes → Asistente Curamba.
 * - Precios y búsqueda en vivo desde los productos de WooCommerce (endpoint /curamba/v1/experiencias).
 * - Si no sabe la respuesta, pasa la conversación al WhatsApp de la agencia con el mensaje ya escrito.
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ajustes por defecto del asistente.
 *
 * @return array
 */
function curamba_cc_chat_defaults() {
	return array(
		'enabled'  => 'yes',
		'name'     => 'Asistente Curamba',
		'greeting' => "¡Hola! 👋 Soy el asistente de Curamba.\nTe ayudo con precios, reservas y todo lo que necesitas para tu visita. ¿Qué te gustaría saber?",
		'faqs'     => array(
			array(
				'q' => '¿Cómo reservo?',
				'k' => 'reservar, reserva, reservo, comprar, pagar ahora, cupo, cupos, separar',
				'a' => "Es muy fácil:\n1. Elige tu experiencia y toca «Reservar».\n2. Selecciona una fecha con cupos disponibles.\n3. Completa tus datos y confirma.\nSi prefieres, escríbenos por WhatsApp y te separamos el cupo.",
			),
			array(
				'q' => '¿Cómo llegar a Curamba?',
				'k' => 'llegar, llego, ubicación, ubicacion, dónde, donde, queda, transporte, bus, carro, mapa, distancia',
				'a' => "Curamba está en Andahuaylas, Apurímac (Perú).\n[Escribe aquí cómo llegar: punto de encuentro, tiempo de viaje y transporte desde Andahuaylas.]",
			),
			array(
				'q' => '¿Qué debo llevar?',
				'k' => 'llevar, ropa, mochila, equipo, frío, frio, abrigo, recomendaciones, zapatillas',
				'a' => "Te recomendamos ropa abrigadora en capas, zapatillas cómodas para caminar, protector solar, gorra, agua y tu documento de identidad.\n[Agrega aquí lo que incluye cada experiencia.]",
			),
			array(
				'q' => '¿Qué horarios tienen?',
				'k' => 'horario, horarios, hora, horas, salida, salen, abierto, atención, atencion, días, dias',
				'a' => "[Escribe aquí el horario de salida de las experiencias y el horario de atención de la agencia.]\nLas próximas fechas y cupos de cada experiencia aparecen en su página.",
			),
			array(
				'q' => '¿Qué formas de pago aceptan?',
				'k' => 'pago, pagos, pagar, yape, plin, tarjeta, transferencia, depósito, deposito, efectivo',
				'a' => '[Escribe aquí tus formas de pago, por ejemplo: Yape, Plin, transferencia bancaria o tarjeta.]',
			),
			array(
				'q' => '¿Es apto para niños o adultos mayores?',
				'k' => 'niños, ninos, niño, familia, adulto mayor, adultos mayores, edad, dificultad, difícil, dificil, fácil, facil',
				'a' => "Cada experiencia indica su nivel de dificultad: fácil, moderada o exigente. Las de nivel fácil son las más recomendadas para familias.\n[Agrega aquí tus recomendaciones de edad.]",
			),
		),
	);
}

/**
 * Ajustes guardados (con valores por defecto).
 *
 * @return array
 */
function curamba_cc_chat_settings() {
	$saved = get_option( 'curamba_cc_chat' );
	$def   = curamba_cc_chat_defaults();
	if ( ! is_array( $saved ) ) {
		return $def;
	}
	return array_merge( $def, $saved );
}

/* ---------- Ajustes en el panel ---------- */

add_action(
	'admin_init',
	function () {
		register_setting(
			'curamba_cc_chat',
			'curamba_cc_chat',
			array(
				'type'              => 'array',
				'sanitize_callback' => 'curamba_cc_chat_sanitize',
			)
		);
	}
);

/**
 * Limpia lo que se guarda desde el formulario.
 *
 * @param mixed $in Datos enviados.
 * @return array
 */
function curamba_cc_chat_sanitize( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$out = array(
		'enabled'  => ( isset( $in['enabled'] ) && 'yes' === $in['enabled'] ) ? 'yes' : 'no',
		'name'     => isset( $in['name'] ) ? sanitize_text_field( $in['name'] ) : '',
		'greeting' => isset( $in['greeting'] ) ? sanitize_textarea_field( $in['greeting'] ) : '',
		'faqs'     => array(),
	);
	if ( '' === $out['name'] ) {
		$out['name'] = 'Asistente Curamba';
	}
	if ( ! empty( $in['faqs'] ) && is_array( $in['faqs'] ) ) {
		foreach ( $in['faqs'] as $row ) {
			$q = isset( $row['q'] ) ? sanitize_text_field( $row['q'] ) : '';
			$a = isset( $row['a'] ) ? sanitize_textarea_field( $row['a'] ) : '';
			if ( '' === $q || '' === $a ) {
				continue; // Fila vacía = pregunta eliminada.
			}
			$out['faqs'][] = array(
				'q' => $q,
				'k' => isset( $row['k'] ) ? sanitize_text_field( $row['k'] ) : '',
				'a' => $a,
			);
		}
	}
	return $out;
}

add_action(
	'admin_menu',
	function () {
		add_options_page( 'Asistente Curamba', 'Asistente Curamba', 'manage_options', 'curamba-cc-chat', 'curamba_cc_chat_page' );
	}
);

/**
 * Pantalla de ajustes del asistente.
 */
function curamba_cc_chat_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s    = curamba_cc_chat_settings();
	$rows = $s['faqs'];
	for ( $i = 0; $i < 3; $i++ ) {
		$rows[] = array( 'q' => '', 'k' => '', 'a' => '' ); // Filas libres para agregar preguntas.
	}
	?>
	<div class="wrap">
		<h1>Asistente Curamba</h1>
		<p>El asistente aparece como una burbuja de chat en toda la web. Los <strong>precios y experiencias</strong> los toma solo de tus productos de WooCommerce. Si un cliente pregunta algo que no está aquí, el asistente le ofrece seguir por <strong>WhatsApp</strong> con su pregunta ya escrita.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'curamba_cc_chat' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Mostrar el asistente</th>
					<td><label><input type="checkbox" name="curamba_cc_chat[enabled]" value="yes" <?php checked( 'yes', $s['enabled'] ); ?>> Activado en toda la web</label></td>
				</tr>
				<tr>
					<th scope="row"><label for="cc-chat-name">Nombre</label></th>
					<td><input type="text" id="cc-chat-name" name="curamba_cc_chat[name]" class="regular-text" value="<?php echo esc_attr( $s['name'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="cc-chat-greeting">Saludo</label></th>
					<td><textarea id="cc-chat-greeting" name="curamba_cc_chat[greeting]" rows="3" class="large-text"><?php echo esc_textarea( $s['greeting'] ); ?></textarea></td>
				</tr>
			</table>

			<h2>Preguntas frecuentes</h2>
			<p class="description">Cada pregunta aparece como un botón. Las <strong>palabras clave</strong> (separadas por comas) sirven para responder cuando el cliente escribe con sus propias palabras. Para borrar una pregunta, deja vacío su texto. Las filas en blanco del final sirven para agregar nuevas.</p>
			<table class="widefat striped" style="max-width:1100px;margin-top:12px">
				<thead><tr><th style="width:24%">Pregunta (botón)</th><th style="width:24%">Palabras clave</th><th>Respuesta</th></tr></thead>
				<tbody>
				<?php foreach ( $rows as $i => $r ) : ?>
					<tr>
						<td><input type="text" name="curamba_cc_chat[faqs][<?php echo (int) $i; ?>][q]" value="<?php echo esc_attr( $r['q'] ); ?>" class="widefat" placeholder="Nueva pregunta…"></td>
						<td><input type="text" name="curamba_cc_chat[faqs][<?php echo (int) $i; ?>][k]" value="<?php echo esc_attr( $r['k'] ); ?>" class="widefat" placeholder="palabra, otra palabra"></td>
						<td><textarea name="curamba_cc_chat[faqs][<?php echo (int) $i; ?>][a]" rows="3" class="widefat" placeholder="Respuesta…"><?php echo esc_textarea( $r['a'] ); ?></textarea></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/* ---------- Burbuja en la web ---------- */

/**
 * ¿Se muestra el asistente en esta página?
 *
 * @return bool
 */
function curamba_cc_chat_visible() {
	if ( is_admin() || wp_doing_ajax() ) {
		return false;
	}
	if ( isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return false; // No estorbar dentro del editor de Elementor.
	}
	if ( function_exists( 'is_checkout' ) && is_checkout() ) {
		return false; // No distraer durante el pago.
	}
	$s = curamba_cc_chat_settings();
	return 'yes' === $s['enabled'];
}

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! curamba_cc_chat_visible() ) {
			return;
		}
		$s = curamba_cc_chat_settings();
		wp_enqueue_style( 'curamba-cc-chat', CURAMBA_CC_URL . 'assets/css/curamba-chat.css', array(), CURAMBA_CC_VERSION );
		wp_enqueue_script( 'curamba-cc-chat', CURAMBA_CC_URL . 'assets/js/curamba-chat.js', array(), CURAMBA_CC_VERSION, true );
		if ( function_exists( 'wp_script_add_data' ) ) {
			wp_script_add_data( 'curamba-cc-chat', 'strategy', 'defer' );
		}
		wp_localize_script(
			'curamba-cc-chat',
			'curambaChat',
			array(
				'restUrl'  => esc_url_raw( rest_url( 'curamba/v1/experiencias' ) ),
				'wa'       => curamba_cc_option_wa(),
				'name'     => $s['name'],
				'greeting' => $s['greeting'],
				'faqs'     => array_values( $s['faqs'] ),
				'shopUrl'  => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
			)
		);
	}
);

add_action(
	'wp_footer',
	function () {
		if ( ! curamba_cc_chat_visible() ) {
			return;
		}
		$s = curamba_cc_chat_settings();
		?>
		<div class="cca" data-cca hidden>
			<button type="button" class="cca-launch" data-cca-launch aria-expanded="false" aria-controls="cca-panel" aria-label="<?php esc_attr_e( 'Abrir el chat de ayuda', 'curamba-cinematic' ); ?>">
				<svg class="cca-ico cca-ico--chat" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5 4v-4H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" fill="currentColor"/><circle cx="8" cy="11" r="1.4" fill="#0b6b44"/><circle cx="12" cy="11" r="1.4" fill="#0b6b44"/><circle cx="16" cy="11" r="1.4" fill="#0b6b44"/></svg>
				<svg class="cca-ico cca-ico--x" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg>
			</button>
			<p class="cca-hint" data-cca-hint><?php esc_html_e( '¿Te ayudo a elegir tu experiencia?', 'curamba-cinematic' ); ?></p>
			<section class="cca-panel" id="cca-panel" data-cca-panel role="dialog" aria-label="<?php echo esc_attr( $s['name'] ); ?>" hidden>
				<header class="cca-head">
					<span class="cca-avatar" aria-hidden="true">C</span>
					<div><strong><?php echo esc_html( $s['name'] ); ?></strong><small><?php esc_html_e( 'Responde al instante', 'curamba-cinematic' ); ?></small></div>
					<button type="button" class="cca-close" data-cca-close aria-label="<?php esc_attr_e( 'Cerrar el chat', 'curamba-cinematic' ); ?>">×</button>
				</header>
				<div class="cca-log" data-cca-log aria-live="polite"></div>
				<form class="cca-form" data-cca-form>
					<label class="screen-reader-text cca-sr" for="cca-input"><?php esc_html_e( 'Escribe tu pregunta', 'curamba-cinematic' ); ?></label>
					<input id="cca-input" type="text" data-cca-input autocomplete="off" maxlength="200" placeholder="<?php esc_attr_e( 'Escribe tu pregunta…', 'curamba-cinematic' ); ?>">
					<button type="submit" aria-label="<?php esc_attr_e( 'Enviar', 'curamba-cinematic' ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 11l18-8-8 18-2-8-8-2z" fill="currentColor"/></svg></button>
				</form>
			</section>
		</div>
		<?php
	},
	20
);
