<?php
/**
 * Reservas por fecha y cupos (sin plugins adicionales).
 *
 * En cada producto (Datos de la experiencia):
 *   - "Fechas de salida": una por línea. Formato  AAAA-MM-DD  o  AAAA-MM-DD|cupos  (ej. 2026-12-05|12).
 *   - "Cupos por fecha": cupos para las fechas que no indican número (0 = sin límite).
 * El cliente elige la fecha en la página del producto; la cantidad es el número de personas.
 * Los cupos se descuentan cuando el pedido pasa a "En espera", "Procesando" o "Completado"
 * y se devuelven si se cancela, reembolsa o falla.
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fechas futuras de un producto con su capacidad.
 *
 * @param WC_Product|int $product Producto.
 * @return array fecha => capacidad (0 = ilimitada)
 */
function curamba_cc_dates( $product ) {
	$product = is_numeric( $product ) ? wc_get_product( $product ) : $product;
	if ( ! $product ) {
		return array();
	}
	$default = max( 0, (int) $product->get_meta( '_cc_cupo' ) );
	$today   = wp_date( 'Y-m-d' );
	$out     = array();
	foreach ( preg_split( '/[\r\n,;]+/', (string) $product->get_meta( '_cc_fechas' ) ) as $line ) {
		$line = trim( $line );
		if ( ! preg_match( '/^(\d{4}-\d{2}-\d{2})(?:\s*\|\s*(\d+))?$/', $line, $m ) ) {
			continue;
		}
		if ( $m[1] < $today ) {
			continue;
		}
		$out[ $m[1] ] = isset( $m[2] ) && '' !== $m[2] ? (int) $m[2] : $default;
	}
	ksort( $out );
	return $out;
}

/**
 * Personas ya reservadas por fecha.
 *
 * @param int $product_id ID.
 * @return array fecha => personas
 */
function curamba_cc_booked( $product_id ) {
	$b = get_post_meta( $product_id, '_cc_reservas', true );
	return is_array( $b ) ? $b : array();
}

/**
 * Cupos libres (null = sin límite).
 *
 * @param int    $product_id ID.
 * @param string $date       Fecha.
 * @return int|null
 */
function curamba_cc_remaining( $product_id, $date ) {
	$dates = curamba_cc_dates( $product_id );
	if ( ! isset( $dates[ $date ] ) ) {
		return 0;
	}
	if ( 0 === $dates[ $date ] ) {
		return null;
	}
	$booked = curamba_cc_booked( $product_id );
	return max( 0, $dates[ $date ] - ( isset( $booked[ $date ] ) ? (int) $booked[ $date ] : 0 ) );
}

/**
 * Texto de disponibilidad para tarjetas: próxima salida y cupos.
 *
 * @param WC_Product $product Producto.
 * @return string
 */
function curamba_cc_next_departure_text( $product ) {
	foreach ( curamba_cc_dates( $product ) as $date => $cap ) {
		$left = curamba_cc_remaining( $product->get_id(), $date );
		if ( null === $left || $left > 0 ) {
			$label = curamba_cc_format_date( $date, true );
			/* translators: 1: fecha, 2: cupos */
			return null === $left ? sprintf( __( 'Próxima salida: %s', 'curamba-cinematic' ), $label ) : sprintf( _n( 'Próxima salida: %1$s · %2$d cupo', 'Próxima salida: %1$s · %2$d cupos', $left, 'curamba-cinematic' ), $label, $left );
		}
	}
	return '';
}

/* ---------- Página del producto: selector de fecha ---------- */

add_action(
	'woocommerce_before_add_to_cart_button',
	function () {
		global $product;
		if ( ! $product ) {
			return;
		}
		$dates = curamba_cc_dates( $product );
		echo '<div class="cc-book">';
		if ( $dates ) {
			echo '<label class="cc-book__label" for="cc_fecha">' . esc_html__( 'Fecha de la experiencia', 'curamba-cinematic' ) . ' <abbr class="required" title="obligatorio">*</abbr></label>';
			echo '<select name="cc_fecha" id="cc_fecha" class="cc-book__field" required>';
			echo '<option value="">' . esc_html__( 'Elige una fecha…', 'curamba-cinematic' ) . '</option>';
			foreach ( $dates as $date => $cap ) {
				$left  = curamba_cc_remaining( $product->get_id(), $date );
				$label = curamba_cc_format_date( $date );
				if ( null !== $left ) {
					/* translators: %d cupos */
					$label .= ' — ' . ( $left > 0 ? sprintf( _n( 'queda %d cupo', 'quedan %d cupos', $left, 'curamba-cinematic' ), $left ) : __( 'agotado', 'curamba-cinematic' ) );
				}
				printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $date ), disabled( 0 === $left, true, false ), esc_html( $label ) );
			}
			echo '</select>';
		} else {
			echo '<label class="cc-book__label" for="cc_fecha">' . esc_html__( 'Fecha deseada (opcional)', 'curamba-cinematic' ) . '</label>';
			echo '<input type="date" name="cc_fecha" id="cc_fecha" class="cc-book__field" min="' . esc_attr( wp_date( 'Y-m-d' ) ) . '">';
		}
		echo '<p class="cc-book__hint">' . esc_html__( 'La cantidad corresponde al número de personas.', 'curamba-cinematic' ) . '</p>';
		echo '</div>';
	}
);

/**
 * Fecha enviada en el formulario (validada).
 *
 * @return string
 */
function curamba_cc_posted_date() {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
	$d = isset( $_REQUEST['cc_fecha'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['cc_fecha'] ) ) : '';
	return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ? $d : '';
}

/**
 * Personas de una fecha que ya están en el carrito.
 *
 * @param int    $product_id ID.
 * @param string $date       Fecha.
 * @return int
 */
function curamba_cc_qty_in_cart( $product_id, $date ) {
	$n = 0;
	if ( WC()->cart ) {
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( (int) $item['product_id'] === (int) $product_id && isset( $item['cc_fecha'] ) && $item['cc_fecha'] === $date ) {
				$n += (int) $item['quantity'];
			}
		}
	}
	return $n;
}

add_filter(
	'woocommerce_add_to_cart_validation',
	function ( $passed, $product_id, $qty ) {
		$dates = curamba_cc_dates( $product_id );
		if ( ! $dates ) {
			return $passed; // Fecha flexible.
		}
		$date = curamba_cc_posted_date();
		if ( '' === $date || ! isset( $dates[ $date ] ) ) {
			wc_add_notice( __( 'Elige una fecha disponible para la experiencia.', 'curamba-cinematic' ), 'error' );
			return false;
		}
		$left    = curamba_cc_remaining( $product_id, $date );
		$in_cart = curamba_cc_qty_in_cart( $product_id, $date );
		if ( null !== $left && ( $qty + $in_cart ) > $left ) {
			if ( $in_cart > 0 && $left > $in_cart ) {
				/* translators: 1: personas en el carrito, 2: cupos que aún se pueden agregar */
				wc_add_notice( sprintf( __( 'Ya tienes %1$d en tu carrito para esa fecha: solo puedes agregar %2$d más.', 'curamba-cinematic' ), $in_cart, $left - $in_cart ), 'error' );
			} elseif ( $in_cart > 0 ) {
				/* translators: %d personas en el carrito */
				wc_add_notice( sprintf( __( 'Ya tienes en tu carrito los %d cupos que quedan para esa fecha.', 'curamba-cinematic' ), $in_cart ), 'error' );
			} else {
				/* translators: %d cupos */
				wc_add_notice( sprintf( _n( 'Para esa fecha solo queda %d cupo.', 'Para esa fecha solo quedan %d cupos.', $left, 'curamba-cinematic' ), $left ), 'error' );
			}
			return false;
		}
		return $passed;
	},
	10,
	3
);

add_filter(
	'woocommerce_add_cart_item_data',
	function ( $data ) {
		$date = curamba_cc_posted_date();
		if ( '' !== $date ) {
			$data['cc_fecha'] = $date;
		}
		return $data;
	}
);

add_filter(
	'woocommerce_get_item_data',
	function ( $data, $item ) {
		if ( ! empty( $item['cc_fecha'] ) ) {
			$data[] = array(
				'name'  => __( 'Fecha', 'curamba-cinematic' ),
				'value' => curamba_cc_format_date( $item['cc_fecha'] ),
			);
		}
		return $data;
	},
	10,
	2
);

add_action(
	'woocommerce_checkout_create_order_line_item',
	function ( $item, $key, $values ) {
		if ( ! empty( $values['cc_fecha'] ) ) {
			$item->add_meta_data( __( 'Fecha de la experiencia', 'curamba-cinematic' ), curamba_cc_format_date( $values['cc_fecha'] ) );
			$item->add_meta_data( '_cc_fecha', $values['cc_fecha'] );
		}
	},
	10,
	3
);

/** Revalida cupos en el carrito y el checkout (por si otro cliente reservó antes). */
add_action(
	'woocommerce_check_cart_items',
	function () {
		$need = array();
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( empty( $item['cc_fecha'] ) ) {
				continue;
			}
			$k          = $item['product_id'] . '|' . $item['cc_fecha'];
			$need[ $k ] = ( isset( $need[ $k ] ) ? $need[ $k ] : 0 ) + (int) $item['quantity'];
		}
		foreach ( $need as $k => $qty ) {
			list( $pid, $date ) = explode( '|', $k );
			$dates = curamba_cc_dates( (int) $pid );
			if ( ! $dates ) {
				continue;
			}
			$left = curamba_cc_remaining( (int) $pid, $date );
			if ( ! isset( $dates[ $date ] ) || ( null !== $left && $qty > $left ) ) {
				/* translators: 1: experiencia, 2: fecha */
				wc_add_notice( sprintf( __( 'No hay cupos suficientes para "%1$s" el %2$s. Ajusta la cantidad o elige otra fecha.', 'curamba-cinematic' ), get_the_title( (int) $pid ), curamba_cc_format_date( $date ) ), 'error' );
			}
		}
	}
);

/**
 * Suma o resta las personas de un pedido a los cupos de cada fecha.
 *
 * @param WC_Order $order Pedido.
 * @param int      $sign  1 = reservar, -1 = liberar.
 */
function curamba_cc_apply_order( $order, $sign ) {
	foreach ( $order->get_items() as $item ) {
		$date = $item->get_meta( '_cc_fecha' );
		if ( ! $date ) {
			continue;
		}
		$pid             = $item->get_product_id();
		$booked          = curamba_cc_booked( $pid );
		$booked[ $date ] = max( 0, ( isset( $booked[ $date ] ) ? (int) $booked[ $date ] : 0 ) + $sign * (int) $item->get_quantity() );
		update_post_meta( $pid, '_cc_reservas', $booked );
	}
}

add_action(
	'woocommerce_order_status_changed',
	function ( $order_id, $from, $to, $order ) {
		$counted = 'yes' === $order->get_meta( '_cc_cupos_contados' );
		if ( in_array( $to, array( 'on-hold', 'processing', 'completed' ), true ) && ! $counted ) {
			curamba_cc_apply_order( $order, 1 );
			$order->update_meta_data( '_cc_cupos_contados', 'yes' );
			$order->save();
		} elseif ( in_array( $to, array( 'cancelled', 'refunded', 'failed' ), true ) && $counted ) {
			curamba_cc_apply_order( $order, -1 );
			$order->update_meta_data( '_cc_cupos_contados', 'no' );
			$order->save();
		}
	},
	10,
	4
);

/* ---------- Pagos por transferencia sin confirmar: liberar cupos ---------- */

/**
 * Horas que se guarda el cupo de un pedido por transferencia/depósito sin pagar (0 = nunca se libera solo).
 *
 * @return int
 */
function curamba_cc_hold_hours() {
	return max( 0, (int) get_option( 'curamba_cc_hold_hours', 48 ) );
}

/** Métodos de pago "manuales": el pedido queda En espera hasta que la agencia confirma el pago. */
function curamba_cc_manual_gateways() {
	return (array) apply_filters( 'curamba_cc_manual_gateways', array( 'bacs', 'cheque' ) );
}

add_action(
	'init',
	function () {
		if ( ! wp_next_scheduled( 'curamba_cc_release_unpaid' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'curamba_cc_release_unpaid' );
		}
	}
);

/**
 * Cancela los pedidos por transferencia que siguen "En espera" pasado el plazo.
 * Al cancelarse, el gancho de cambio de estado devuelve los cupos a la fecha.
 */
add_action(
	'curamba_cc_release_unpaid',
	function () {
		$hours = curamba_cc_hold_hours();
		if ( ! $hours || ! function_exists( 'wc_get_orders' ) ) {
			return;
		}
		$orders = wc_get_orders(
			array(
				'status'         => array( 'on-hold' ),
				'payment_method' => curamba_cc_manual_gateways(),
				'date_created'   => '<' . ( time() - $hours * HOUR_IN_SECONDS ),
				'limit'          => 50,
			)
		);
		foreach ( $orders as $order ) {
			if ( 'yes' !== $order->get_meta( '_cc_cupos_contados' ) ) {
				continue; // Solo pedidos que apartan cupos de una fecha.
			}
			/* translators: %d horas */
			$order->update_status( 'cancelled', sprintf( __( 'Curamba: cancelado automáticamente porque no se confirmó el pago en %d horas. Los cupos se liberaron.', 'curamba-cinematic' ), $hours ) );
		}
	}
);

/** Aviso al cliente en la página de "Pedido recibido" (transferencia). */
add_action(
	'woocommerce_thankyou',
	function ( $order_id ) {
		$order = wc_get_order( $order_id );
		$hours = curamba_cc_hold_hours();
		if ( ! $order || ! $hours || ! in_array( $order->get_payment_method(), curamba_cc_manual_gateways(), true ) || 'yes' !== $order->get_meta( '_cc_cupos_contados' ) ) {
			return;
		}
		printf(
			'<p class="cc-hold-note" style="padding:14px 18px;border-radius:12px;background:#fff6e0;border:1px solid #ffd27a;font-weight:600">%s</p>',
			/* translators: %d horas */
			esc_html( sprintf( __( 'Tus cupos quedan reservados por %d horas. Envíanos el comprobante de pago por WhatsApp para confirmarlos; si no recibimos el pago en ese plazo, la reserva se libera.', 'curamba-cinematic' ), $hours ) )
		);
	},
	5
);

/* ---------- WhatsApp en la página del producto ---------- */

add_action(
	'woocommerce_after_add_to_cart_form',
	function () {
		global $product;
		if ( ! $product || 'yes' !== get_option( 'curamba_cc_wa_product', 'yes' ) ) {
			return;
		}
		/* translators: %s producto */
		$msg = sprintf( __( 'Hola, quiero reservar la experiencia: %s', 'curamba-cinematic' ), $product->get_name() );
		printf(
			'<a class="cc-wa-product" href="%1$s" target="_blank" rel="noopener" data-cc-track="whatsapp_click" data-cc-label="%2$s">%3$s%4$s</a>',
			esc_url( curamba_cc_wa_url( curamba_cc_option_wa(), $msg ) ),
			esc_attr( $product->get_name() ),
			curamba_cc_wa_icon(), // phpcs:ignore WordPress.Security.EscapeOutput
			esc_html__( 'Consultar por WhatsApp', 'curamba-cinematic' )
		);
	}
);

/* ---------- Panel del producto: resumen de reservas ---------- */

add_action(
	'woocommerce_product_options_general_product_data',
	function () {
		global $post;
		$dates = curamba_cc_dates( $post->ID );
		if ( ! $dates ) {
			return;
		}
		$booked = curamba_cc_booked( $post->ID );
		echo '<div class="options_group"><p class="form-field"><strong>' . esc_html__( 'Reservas por fecha', 'curamba-cinematic' ) . '</strong><br>';
		foreach ( $dates as $date => $cap ) {
			$b = isset( $booked[ $date ] ) ? (int) $booked[ $date ] : 0;
			echo esc_html( $date . ': ' . $b . ' / ' . ( $cap ? $cap : '∞' ) ) . '<br>';
		}
		echo '</p></div>';
	},
	20
);
