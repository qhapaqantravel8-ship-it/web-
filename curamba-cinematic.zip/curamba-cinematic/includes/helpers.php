<?php
/**
 * Utilidades compartidas.
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * URL de una capa de ejemplo incluida en el plugin (se usa hasta que se suban fotos propias).
 *
 * @param string $name Nombre del archivo sin extensión.
 * @return string
 */
function curamba_cc_placeholder( $name ) {
	// Imágenes reales incluidas (solo de Curamba y de uso libre).
	$photos = array(
		'curamba-grabado'      => 'assets/photos/historia-curamba.jpg',
		// Fotos de prueba entregadas por la agencia (reemplazables desde Elementor).
		'foto-campo'           => 'assets/photos/prueba/curamba-campo.webp',
		'foto-campo-frente'    => 'assets/photos/prueba/curamba-campo-primer-plano.webp',
		'foto-plataforma'      => 'assets/photos/prueba/curamba-plataforma.webp',
		'foto-muro-valle'      => 'assets/photos/prueba/curamba-muro-valle.webp',
		'foto-valle'           => 'assets/photos/prueba/curamba-valle.webp',
		'foto-mirador'         => 'assets/photos/prueba/curamba-mirador.webp',
		'mini-plataforma'      => 'assets/photos/prueba/curamba-plataforma-900.webp',
		'mini-valle'           => 'assets/photos/prueba/curamba-valle-900.webp',
		'mini-muro-valle'      => 'assets/photos/prueba/curamba-muro-valle-900.webp',
		'mini-mirador'         => 'assets/photos/prueba/curamba-mirador-900.webp',
		'mini-campo'           => 'assets/photos/prueba/curamba-campo-900.webp',
	);
	if ( isset( $photos[ $name ] ) ) {
		return CURAMBA_CC_URL . $photos[ $name ];
	}
	return CURAMBA_CC_URL . 'assets/placeholders/' . $name . '.svg';
}

/**
 * Iconos de los accesos de la escena 3 (SVG en línea, decorativos).
 *
 * @param string $name Clave del icono.
 * @return string
 */
function curamba_cc_icon( $name ) {
	$paths = array(
		'caminata'    => '<path d="M13.5 5.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM9.8 22l1.6-7 2.1 2V22h2v-6.5l-2.1-2 .6-3A7.3 7.3 0 0 0 19 13v-2a5 5 0 0 1-4.3-2.4l-1-1.6a2 2 0 0 0-2.5-.8L6 8.3V13h2V9.6l1.8-.7L8 22h1.8Z"/>',
		'cultura'     => '<path d="M12 2 2 7v2h20V7L12 2Zm-7 9v7H3v2h18v-2h-2v-7h-2v7h-3v-7h-2v7H7v-7H5Z"/>',
		'gastronomia' => '<path d="M7 2v8a3 3 0 0 0 2 2.8V22h2v-9.2A3 3 0 0 0 13 10V2h-1.5v6h-1V2h-1v6h-1V2H7Zm9 0c-1.7 0-3 2.2-3 5v6h2v9h2V2h-1Z"/>',
		'comunidad'   => '<path d="M8 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm8 0a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM2 19c0-3 2.7-5 6-5s6 2 6 5v1H2v-1Zm13.7 1v-1c0-1.7-.6-3.2-1.7-4.3.6-.2 1.3-.2 2-.2 3.3 0 6 2 6 5v.5h-6.3Z"/>',
		'foto'        => '<path d="M9 3 7.2 5H4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-3.2L15 3H9Zm3 4.5a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"/>',
		'privado'     => '<path d="M12 2 4 5v6c0 5 3.4 9.7 8 11 4.6-1.3 8-6 8-11V5l-8-3Zm-1.2 14.2L7 12.4l1.4-1.4 2.4 2.4 4.8-4.8L17 10l-6.2 6.2Z"/>',
		'estrella'    => '<path d="m12 2 2.9 6.6 7.1.6-5.4 4.7 1.6 7L12 17.3 5.8 21l1.6-7L2 9.2l7.1-.6L12 2Z"/>',
	);
	$p = isset( $paths[ $name ] ) ? $paths[ $name ] : $paths['estrella'];
	return '<svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true" focusable="false" fill="currentColor">' . $p . '</svg>';
}

/**
 * Opciones de iconos para el control de Elementor.
 *
 * @return array
 */
function curamba_cc_icon_options() {
	return array(
		'caminata'    => __( 'Caminata', 'curamba-cinematic' ),
		'cultura'     => __( 'Cultura', 'curamba-cinematic' ),
		'gastronomia' => __( 'Gastronomía', 'curamba-cinematic' ),
		'comunidad'   => __( 'Comunidad', 'curamba-cinematic' ),
		'foto'        => __( 'Fotografía', 'curamba-cinematic' ),
		'privado'     => __( 'Privado', 'curamba-cinematic' ),
		'estrella'    => __( 'Estrella', 'curamba-cinematic' ),
	);
}

/**
 * Valores por defecto. Todos son editables desde el widget de Elementor.
 * Los datos destacados quedan como marcadores: el propietario debe reemplazarlos con información verificada.
 *
 * @return array
 */
function curamba_cc_default_settings() {
	return array(
		// Escena 1.
		'hero_title'        => 'CURAMBA',
		'hero_text'         => 'Descubre un destino donde la historia, la naturaleza y las experiencias vivenciales se encuentran.',
		'hero_tags'         => array(
			array( 'tag' => 'Cultura local' ),
			array( 'tag' => 'Naturaleza' ),
			array( 'tag' => 'Experiencias vivenciales' ),
		),
		'hero_btn_text'     => 'Explorar experiencias',
		'hero_btn_link'     => array( 'url' => '#curamba-experiencias' ),
		'hero_wa_text'      => 'Reservar por WhatsApp',

		// Capas.
		'hero_mode'         => 'photo',
		'img_fg_photo'      => array( 'url' => '' ),
		'img_sky'           => array( 'url' => '' ),
		'img_far'           => array( 'url' => '' ),
		'img_mid'           => array( 'url' => '' ),
		'img_main'          => array( 'url' => '' ),
		'img_fg_left'       => array( 'url' => '' ),
		'img_fg_right'      => array( 'url' => '' ),
		'img_close'         => array( 'url' => '' ),
		'img_bg2'           => array( 'url' => '' ),
		'img_bg3'           => array( 'url' => '' ),
		'img_bg4'           => array( 'url' => '' ),
		's2_caption'        => 'Curamba · Andahuaylas, Apurímac',

		// Escena 2.
		's2_title'          => 'Curamba se vive con todos los sentidos',
		's2_text'           => '[Describe aquí la historia, la cultura, los paisajes y la población local de Curamba con información verificada por la agencia.]',
		's2_btn_text'       => 'Conoce la experiencia',
		's2_btn_link'       => array( 'url' => '#curamba-experiencias' ),
		's2_facts'          => array(
			array(
				'value' => '[DATO DESTACADO]',
				'label' => 'Reemplazar por un dato verificado',
			),
			array(
				'value' => '[INFORMACIÓN DEL DESTINO]',
				'label' => 'Reemplazar por información verificada',
			),
		),

		// Escena 3.
		's3_title'          => 'Rutas guiadas, encuentros auténticos y momentos que permanecen.',
		's3_links'          => array(
			array( 'label' => 'Caminatas', 'icon' => 'caminata', 'category' => '', 'link' => array( 'url' => '' ), 'image' => array( 'url' => curamba_cc_placeholder( 'mini-valle' ) ) ),
			array( 'label' => 'Turismo cultural', 'icon' => 'cultura', 'category' => '', 'link' => array( 'url' => '' ), 'image' => array( 'url' => curamba_cc_placeholder( 'mini-plataforma' ) ) ),
			array( 'label' => 'Gastronomía', 'icon' => 'gastronomia', 'category' => '', 'link' => array( 'url' => '' ), 'image' => array( 'url' => '' ) ),
			array( 'label' => 'Experiencias comunitarias', 'icon' => 'comunidad', 'category' => '', 'link' => array( 'url' => '' ), 'image' => array( 'url' => '' ) ),
			array( 'label' => 'Fotografía y naturaleza', 'icon' => 'foto', 'category' => '', 'link' => array( 'url' => '' ), 'image' => array( 'url' => curamba_cc_placeholder( 'mini-muro-valle' ) ) ),
			array( 'label' => 'Tours privados', 'icon' => 'privado', 'category' => '', 'link' => array( 'url' => '' ), 'image' => array( 'url' => curamba_cc_placeholder( 'mini-mirador' ) ) ),
		),

		// Escena 4.
		's4_kicker'         => 'Experiencias',
		's4_categories'     => array(),
		's4_count'          => 8,
		's4_orderby'        => 'menu_order',
		's4_details_text'   => 'Ver detalles',
		's4_book_text'      => 'Reservar',
		's4_book_action'    => 'product',

		// Escena 5.
		's5_title'          => 'Elige tu próxima experiencia',
		's5_text'           => 'Busca por nombre, fecha o tipo de actividad y reserva en pocos pasos.',
		's5_search_ph'      => 'Buscar experiencias…',
		's5_all_text'       => 'Ver todas las experiencias',
		's5_all_link'       => array( 'url' => '' ),
		's5_wa_text'        => 'Consultar por WhatsApp',
		's5_show_date'      => 'yes',
		's5_show_category'  => 'yes',
		's5_show_price'     => 'yes',
		's5_show_duration'  => 'yes',
		's5_show_difficulty'=> 'yes',
		's5_initial'        => 6,

		// WhatsApp.
		'wa_number'         => curamba_cc_option_wa(),
		'wa_message'        => 'Hola, quiero información para visitar Curamba.',
		'wa_product_msg'    => 'Hola, quiero reservar la experiencia: {experiencia}',
		'wa_float'          => 'yes',
		'wa_float_text'     => 'WhatsApp',

		// Movimiento.
		'motion_length'     => array( 'size' => 4200 ),
		'motion_intensity'  => array( 'size' => 100 ),
		'motion_step'       => 'yes',
		'motion_flight'     => array( 'size' => 1500 ),
		'motion_pointer'    => 'yes',
		'motion_mobile'     => 'static',
	);
}

/**
 * Lee un valor de los ajustes con valor por defecto.
 *
 * @param array  $s   Ajustes.
 * @param string $key Clave.
 * @return mixed
 */
function curamba_cc_get( $s, $key ) {
	$defaults = curamba_cc_default_settings();
	// Se respeta un valor vacío guardado (p. ej. un interruptor apagado); solo se usa el valor por defecto si la clave no existe.
	if ( is_array( $s ) && array_key_exists( $key, $s ) && null !== $s[ $key ] ) {
		return $s[ $key ];
	}
	return isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
}

/**
 * Devuelve la etiqueta <img> de una capa: imagen de la Biblioteca de Medios (con srcset) o la capa de ejemplo.
 *
 * @param array  $media       Valor de un control MEDIA de Elementor (id, url).
 * @param string $placeholder Nombre de la capa de ejemplo.
 * @param string $class       Clases CSS.
 * @param string $loading     eager|lazy.
 * @param string $size        Tamaño de imagen de WordPress.
 * @param int    $z           Profundidad 3D en px (null = sin profundidad).
 * @return string
 */
function curamba_cc_layer_img( $media, $placeholder, $class, $loading = 'eager', $size = 'full', $z = null ) {
	$attrs = array(
		'class'         => $class,
		'alt'           => '',
		'aria-hidden'   => 'true',
		'decoding'      => 'async',
		'loading'       => $loading,
		'draggable'     => 'false',
		'data-no-lazy'  => '1',
		'sizes'         => '100vw',
	);
	if ( 'eager' === $loading ) {
		$attrs['fetchpriority'] = 'high';
	}
	if ( null !== $z ) {
		$attrs['style']  = curamba_cc_depth_style( $z );
		$attrs['data-z'] = (string) (int) $z;
	}

	$id =( is_array( $media ) && ! empty( $media['id'] ) ) ? absint( $media['id'] ) : 0;
	if ( $id && wp_attachment_is_image( $id ) ) {
		return wp_get_attachment_image( $id, $size, false, $attrs );
	}

	$url = ( is_array( $media ) && ! empty( $media['url'] ) ) ? $media['url'] : curamba_cc_placeholder( $placeholder );
	unset( $attrs['sizes'] );
	// Fotos de ejemplo: versión de 1600 px para teléfonos (menos memoria de la GPU → vuelo fluido).
	$small = preg_replace( '/\.webp$/', '-1600.webp', $url );
	$rel   = str_replace( CURAMBA_CC_URL, '', $small );
	if ( $small !== $url && 0 === strpos( $small, CURAMBA_CC_URL ) && file_exists( CURAMBA_CC_DIR . $rel ) ) {
		$big = @getimagesize( CURAMBA_CC_DIR . str_replace( CURAMBA_CC_URL, '', $url ) );
		if ( $big ) {
			$attrs['srcset'] = esc_url( $small ) . ' 1600w, ' . esc_url( $url ) . ' ' . (int) $big[0] . 'w';
			$attrs['sizes']  = '130vw';
		}
	}
	$html = '<img src="' . esc_url( $url ) . '"';
	foreach ( $attrs as $k => $v ) {
		$html .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
	}
	return $html . '>';
}

/**
 * Número de WhatsApp de la agencia (Ajustes → Curamba). Por defecto: Perú (+51) 933 920 638.
 *
 * @return string Solo dígitos, con código de país.
 */
function curamba_cc_option_wa() {
	$n = preg_replace( '/\D+/', '', (string) get_option( 'curamba_cc_whatsapp', '51933920638' ) );
	if ( 9 === strlen( $n ) && '9' === $n[0] ) {
		$n = '51' . $n; // Celular peruano sin código de país.
	}
	return $n ? $n : '51933920638';
}

/**
 * Fecha legible en español (la usan las reservas y el Libro de Reclamaciones).
 *
 * @param string $date  AAAA-MM-DD.
 * @param bool   $short Formato corto ("10 ene").
 * @return string
 */
function curamba_cc_format_date( $date, $short = false ) {
	if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $date, $m ) ) {
		return (string) $date;
	}
	// Siempre en español, aunque WordPress no tenga instalado el idioma.
	$months = array( 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre' );
	$days   = array( 'domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado' );
	$mon    = $months[ (int) $m[2] - 1 ];
	if ( $short ) {
		return (int) $m[3] . ' ' . substr( $mon, 0, 3 );
	}
	$dow = $days[ (int) gmdate( 'w', gmmktime( 12, 0, 0, (int) $m[2], (int) $m[3], (int) $m[1] ) ) ];
	return $dow . ' ' . (int) $m[3] . ' de ' . $mon . ' de ' . $m[1];
}

/**
 * Perspectiva del escenario 3D (px). Debe coincidir con CSS y JS.
 */
define( 'CURAMBA_CC_PERSPECTIVE', 1000 );

/**
 * Estilo de profundidad: translateZ + escala compensada para que la capa llene la pantalla a cualquier profundidad.
 *
 * @param int $z Profundidad en px (negativo = más lejos).
 * @return string
 */
function curamba_cc_depth_style( $z ) {
	$p = CURAMBA_CC_PERSPECTIVE;
	$s = ( $p - (int) $z ) / $p;
	return '--z:' . (int) $z . 'px;--s:' . round( $s, 4 ) . ';';
}

/**
 * Atributos de profundidad para un elemento HTML.
 *
 * @param int $z Profundidad en px.
 * @return string
 */
function curamba_cc_depth( $z ) {
	return 'style="' . esc_attr( curamba_cc_depth_style( $z ) ) . '" data-z="' . (int) $z . '"';
}

/**
 * Banco de nubes entre capítulos (solo CSS, sin imágenes).
 *
 * @param int[] $depths Profundidades.
 * @return string
 */
function curamba_cc_clouds( $depths ) {
	$html = '';
	$i    = 0;
	foreach ( $depths as $z ) {
		$x     = array( -14, 16, -4 )[ $i % 3 ];
		$y     = array( 8, -6, 2 )[ $i % 3 ];
		// Escala fija: la nube se ve pequeña a lo lejos y enorme al atravesarla (perspectiva real).
		// <img> (no fondo CSS): el navegador la compone directo en la GPU sin volver a dibujarla en cada cuadro.
		$html .= '<img class="cc-cloud cc-cloud--' . ( $i % 3 ) . '" src="' . esc_url( CURAMBA_CC_URL . 'assets/img/nube-' . ( $i % 3 ) . '.webp' ) . '" alt="" aria-hidden="true" draggable="false" decoding="async" data-no-lazy="1" data-cc-cloud data-z="' . (int) $z . '" style="' . esc_attr( '--z:' . (int) $z . 'px;--s:1.5;--x:' . $x . 'vw;--y:' . $y . 'vh;' ) . '">';
		++$i;
	}
	return $html;
}

/**
 * Enlace de WhatsApp (wa.me) con mensaje.
 *
 * @param string $number  Número con código de país.
 * @param string $message Mensaje.
 * @return string
 */
function curamba_cc_wa_url( $number, $message ) {
	$digits = preg_replace( '/\D+/', '', (string) $number );
	if ( '' === $digits ) {
		$digits = curamba_cc_option_wa();
	} elseif ( 9 === strlen( $digits ) && '9' === $digits[0] ) {
		$digits = '51' . $digits;
	}
	$url    = $digits ? 'https://wa.me/' . $digits : 'https://wa.me/';
	if ( '' !== trim( (string) $message ) ) {
		$url .= '?text=' . rawurlencode( $message );
	}
	return $url;
}

/**
 * Atributos de un control URL de Elementor.
 *
 * @param array  $link     Valor del control URL.
 * @param string $fallback URL por defecto.
 * @return string
 */
function curamba_cc_link_attrs( $link, $fallback = '#' ) {
	$url = ( is_array( $link ) && ! empty( $link['url'] ) ) ? $link['url'] : $fallback;
	$out = ' href="' . esc_url( $url ) . '"';
	if ( is_array( $link ) && ! empty( $link['is_external'] ) ) {
		$out .= ' target="_blank"';
	}
	$rel = array();
	if ( is_array( $link ) && ! empty( $link['nofollow'] ) ) {
		$rel[] = 'nofollow';
	}
	if ( is_array( $link ) && ! empty( $link['is_external'] ) ) {
		$rel[] = 'noopener';
	}
	if ( $rel ) {
		$out .= ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"';
	}
	return $out;
}

/**
 * URL de la tienda de WooCommerce o del archivo de productos.
 *
 * @return string
 */
function curamba_cc_shop_url() {
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		return wc_get_page_permalink( 'shop' );
	}
	return home_url( '/' );
}

/**
 * Opciones de categorías de producto para los controles.
 *
 * @return array slug => nombre
 */
function curamba_cc_category_options() {
	$options = array();
	if ( ! taxonomy_exists( 'product_cat' ) ) {
		return $options;
	}
	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
		)
	);
	if ( is_wp_error( $terms ) ) {
		return $options;
	}
	foreach ( $terms as $term ) {
		$options[ $term->slug ] = $term->name;
	}
	return $options;
}

/**
 * Niveles de dificultad disponibles.
 *
 * @return array
 */
function curamba_cc_difficulties() {
	return array(
		'facil'    => __( 'Fácil', 'curamba-cinematic' ),
		'moderada' => __( 'Moderada', 'curamba-cinematic' ),
		'exigente' => __( 'Exigente', 'curamba-cinematic' ),
	);
}

/**
 * Rangos de duración para el filtro.
 *
 * @return array clave => array( etiqueta, min horas, max horas )
 */
function curamba_cc_duration_ranges() {
	return array(
		'corta'    => array( __( 'Hasta 4 horas', 'curamba-cinematic' ), 0, 4 ),
		'medio'    => array( __( 'Medio día a día completo (4–10 h)', 'curamba-cinematic' ), 4.01, 10 ),
		'multidia' => array( __( 'Más de un día', 'curamba-cinematic' ), 10.01, 10000 ),
	);
}

/**
 * Datos normalizados de una experiencia (producto WooCommerce) para tarjetas y buscador.
 *
 * @param WC_Product $product  Producto.
 * @param array      $settings Ajustes del widget (WhatsApp, acción de reservar).
 * @param string     $size     Tamaño de imagen.
 * @return array
 */
function curamba_cc_product_data( $product, $settings, $size = 'woocommerce_thumbnail' ) {
	$id     = $product->get_id();
	$terms  = get_the_terms( $id, 'product_cat' );
	$cat    = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
	$diffs  = curamba_cc_difficulties();
	$diff   = (string) $product->get_meta( '_cc_dificultad' );
	$hours  = (float) $product->get_meta( '_cc_duracion_horas' );
	$dlabel = (string) $product->get_meta( '_cc_duracion_texto' );
	if ( '' === $dlabel && $hours > 0 ) {
		/* translators: %s: horas */
		$dlabel = sprintf( __( '%s h', 'curamba-cinematic' ), wc_format_localized_decimal( $hours ) );
	}

	$availability = (string) $product->get_meta( '_cc_disponibilidad' );
	if ( '' === $availability && function_exists( 'curamba_cc_next_departure_text' ) ) {
		$availability = curamba_cc_next_departure_text( $product );
	}
	if ( '' === $availability ) {
		if ( ! $product->is_in_stock() ) {
			$availability = __( 'Sin cupos por ahora', 'curamba-cinematic' );
		} elseif ( $product->managing_stock() && null !== $product->get_stock_quantity() ) {
			/* translators: %d: cupos */
			$availability = sprintf( _n( 'Queda %d cupo', 'Quedan %d cupos', (int) $product->get_stock_quantity(), 'curamba-cinematic' ), (int) $product->get_stock_quantity() );
		} else {
			$availability = __( 'Disponible', 'curamba-cinematic' );
		}
	}

	$excerpt = $product->get_short_description();
	if ( '' === $excerpt ) {
		$excerpt = $product->get_description();
	}
	$excerpt = wp_trim_words( wp_strip_all_tags( $excerpt ), 22, '…' );

	$permalink = get_permalink( $id );
	$action    = curamba_cc_get( $settings, 's4_book_action' );
	$wa_msg    = str_replace( '{experiencia}', $product->get_name(), (string) curamba_cc_get( $settings, 'wa_product_msg' ) );
	if ( 'whatsapp' === $action ) {
		$book_url = curamba_cc_wa_url( curamba_cc_get( $settings, 'wa_number' ), $wa_msg );
	} elseif ( 'cart' === $action && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() ) {
		$book_url = add_query_arg( 'add-to-cart', $id, wc_get_cart_url() );
	} else {
		$book_url = $permalink;
	}

	$image_id = $product->get_image_id();

	return array(
		'id'           => $id,
		'name'         => $product->get_name(),
		'url'          => $permalink,
		'bookUrl'      => $book_url,
		'bookIsWa'     => 'whatsapp' === $action,
		'waUrl'        => curamba_cc_wa_url( curamba_cc_get( $settings, 'wa_number' ), $wa_msg ),
		'image'        => $image_id ? wp_get_attachment_image_url( $image_id, $size ) : wc_placeholder_img_src( $size ),
		'imageId'      => $image_id,
		'category'     => $cat,
		'excerpt'      => $excerpt,
		'priceHtml'    => $product->get_price_html(),
		'duration'     => $dlabel,
		'difficulty'   => isset( $diffs[ $diff ] ) ? $diffs[ $diff ] : '',
		'availability' => $availability,
		'inStock'      => $product->is_in_stock(),
	);
}
