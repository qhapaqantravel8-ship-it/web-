<?php
/**
 * Widget de Elementor "Curamba Cinematic".
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Widget_Base;

/**
 * Widget principal.
 */
class Curamba_CC_Elementor_Widget extends Widget_Base {

	public function get_name() {
		return 'curamba_cinematic';
	}

	public function get_title() {
		return __( 'Curamba Cinematic', 'curamba-cinematic' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'curamba', 'parallax', 'scroll', 'cinematic', 'woocommerce', 'turismo', 'carrusel' );
	}

	public function get_style_depends() {
		return array( 'curamba-cinematic' );
	}

	public function get_script_depends() {
		return array( 'curamba-cinematic' );
	}

	/**
	 * Agrega un control con su valor por defecto tomado de curamba_cc_default_settings().
	 *
	 * @param string $id   ID.
	 * @param array  $args Argumentos.
	 */
	private function ctrl( $id, $args ) {
		$defaults = curamba_cc_default_settings();
		if ( ! isset( $args['default'] ) && isset( $defaults[ $id ] ) ) {
			$args['default'] = $defaults[ $id ];
		}
		$this->add_control( $id, $args );
	}

	private function media( $id, $label, $help ) {
		$this->ctrl(
			$id,
			array(
				'label'       => $label,
				'type'        => Controls_Manager::MEDIA,
				'description' => $help,
				'default'     => array( 'url' => '' ),
			)
		);
	}

	protected function register_controls() {
		$defaults   = curamba_cc_default_settings();
		$categories = curamba_cc_category_options();

		/* ---------- Capas visuales ---------- */
		$this->start_controls_section( 'sec_layers', array( 'label' => __( 'Capas visuales (fotos)', 'curamba-cinematic' ) ) );
		$this->add_control(
			'layers_note',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Sube fotos propias desde la Biblioteca de Medios. Mientras una capa esté vacía se muestra una ilustración de ejemplo. Para el primer plano y el atractivo usa PNG/WebP con fondo transparente para lograr profundidad.', 'curamba-cinematic' ),
				'content_classes' => 'elementor-descriptor',
			)
		);
		$this->ctrl(
			'hero_mode',
			array(
				'label'       => __( 'Tipo de portada', 'curamba-cinematic' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'photo'  => __( 'Foto 3D (foto + primer plano)', 'curamba-cinematic' ),
					'layers' => __( 'Capas (cielo, montañas, atractivo, primer plano)', 'curamba-cinematic' ),
				),
				'description' => __( 'En "Foto 3D" solo se usan la foto de fondo, el primer plano y las capas a las que subas imagen.', 'curamba-cinematic' ),
			)
		);
		$this->media( 'img_sky', __( '1. Foto de portada / cielo', 'curamba-cinematic' ), __( 'Foto panorámica de Curamba (JPG/WebP, ~2400 px de ancho).', 'curamba-cinematic' ) );
		$this->media( 'img_fg_photo', __( 'Primer plano de la foto (PNG/WebP transparente)', 'curamba-cinematic' ), __( 'Mismo tamaño que la foto de portada, con solo el suelo visible. Crea el efecto 3D al hacer scroll.', 'curamba-cinematic' ) );
		$this->media( 'img_far', __( '2. Paisaje lejano', 'curamba-cinematic' ), __( 'Montañas o horizonte, con transparencia arriba.', 'curamba-cinematic' ) );
		$this->media( 'img_mid', __( '3. Elementos intermedios', 'curamba-cinematic' ), __( 'Colinas, campos o vegetación intermedia.', 'curamba-cinematic' ) );
		$this->media( 'img_main', __( '4. Atractivo principal', 'curamba-cinematic' ), __( 'El paisaje o atractivo verificado de Curamba (recorte transparente).', 'curamba-cinematic' ) );
		$this->media( 'img_fg_left', __( '6. Primer plano izquierdo', 'curamba-cinematic' ), __( 'Se separa hacia la izquierda al hacer scroll.', 'curamba-cinematic' ) );
		$this->media( 'img_fg_right', __( '6. Primer plano derecho', 'curamba-cinematic' ), __( 'Se separa hacia la derecha al hacer scroll.', 'curamba-cinematic' ) );
		$this->media( 'img_close', __( 'Foto enmarcada de la escena 2', 'curamba-cinematic' ), __( 'Vacío = grabado histórico de Curamba (dominio público). Recomendado: tu mejor foto de Curamba.', 'curamba-cinematic' ) );
		$this->media( 'img_bg2', __( 'Fondo de la escena 2', 'curamba-cinematic' ), __( 'Paisaje detrás de la foto enmarcada.', 'curamba-cinematic' ) );
		$this->media( 'img_bg3', __( 'Fondo de la escena 3', 'curamba-cinematic' ), __( 'Paisaje de Curamba (horizontal, ~2400 px).', 'curamba-cinematic' ) );
		$this->media( 'img_bg4', __( 'Fondo de la escena 4 (carrusel)', 'curamba-cinematic' ), __( 'Atardecer o vista amplia de Curamba (horizontal, ~2400 px).', 'curamba-cinematic' ) );
		$this->end_controls_section();

		/* ---------- Escena 1 ---------- */
		$this->start_controls_section( 'sec_s1', array( 'label' => __( 'Escena 1 · Presentación', 'curamba-cinematic' ) ) );
		$this->ctrl( 'hero_title', array( 'label' => __( 'Título', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'label_block' => true ) );
		$this->ctrl( 'hero_text', array( 'label' => __( 'Texto introductorio', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 3 ) );
		$tags = new Repeater();
		$tags->add_control( 'tag', array( 'label' => __( 'Etiqueta', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Etiqueta', 'curamba-cinematic' ) ) );
		$this->ctrl(
			'hero_tags',
			array(
				'label'       => __( 'Etiquetas', 'curamba-cinematic' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $tags->get_controls(),
				'title_field' => '{{{ tag }}}',
			)
		);
		$this->ctrl( 'hero_btn_text', array( 'label' => __( 'Botón principal', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT ) );
		$this->ctrl( 'hero_btn_link', array( 'label' => __( 'Enlace del botón', 'curamba-cinematic' ), 'type' => Controls_Manager::URL, 'description' => __( '#curamba-experiencias lleva al carrusel con animación.', 'curamba-cinematic' ) ) );
		$this->ctrl( 'hero_wa_text', array( 'label' => __( 'Botón de WhatsApp', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT ) );
		$this->end_controls_section();

		/* ---------- Escena 2 ---------- */
		$this->start_controls_section( 'sec_s2', array( 'label' => __( 'Escena 2 · Historia y territorio', 'curamba-cinematic' ) ) );
		$this->add_control(
			's2_note',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Usa solo datos históricos y cifras verificados por la agencia. Los textos entre corchetes son marcadores para reemplazar.', 'curamba-cinematic' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);
		$this->ctrl( 's2_title', array( 'label' => __( 'Título', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'label_block' => true ) );
		$this->ctrl( 's2_text', array( 'label' => __( 'Descripción', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 5 ) );
		$this->ctrl( 's2_caption', array( 'label' => __( 'Pie de la foto (créditos)', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'description' => __( 'Si cambias la foto, cambia también el crédito.', 'curamba-cinematic' ) ) );
		$facts = new Repeater();
		$facts->add_control( 'value', array( 'label' => __( 'Dato', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'default' => '[DATO]' ) );
		$facts->add_control( 'label', array( 'label' => __( 'Descripción del dato', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'default' => '' ) );
		$this->ctrl(
			's2_facts',
			array(
				'label'       => __( 'Datos destacados', 'curamba-cinematic' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $facts->get_controls(),
				'title_field' => '{{{ value }}}',
			)
		);
		$this->ctrl( 's2_btn_text', array( 'label' => __( 'Texto del botón', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT ) );
		$this->ctrl( 's2_btn_link', array( 'label' => __( 'Enlace del botón', 'curamba-cinematic' ), 'type' => Controls_Manager::URL ) );
		$this->end_controls_section();

		/* ---------- Escena 3 ---------- */
		$this->start_controls_section( 'sec_s3', array( 'label' => __( 'Escena 3 · Naturaleza y experiencias', 'curamba-cinematic' ) ) );
		$this->ctrl( 's3_title', array( 'label' => __( 'Texto', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2 ) );
		$links = new Repeater();
		$links->add_control( 'label', array( 'label' => __( 'Nombre', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Acceso', 'curamba-cinematic' ) ) );
		$links->add_control(
			'category',
			array(
				'label'   => __( 'Categoría de WooCommerce', 'curamba-cinematic' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array_merge( array( '' => __( '— Elegir —', 'curamba-cinematic' ) ), $categories ),
				'default' => '',
			)
		);
		$links->add_control(
			'icon',
			array(
				'label'   => __( 'Icono', 'curamba-cinematic' ),
				'type'    => Controls_Manager::SELECT,
				'options' => curamba_cc_icon_options(),
				'default' => 'estrella',
			)
		);
		$links->add_control( 'image', array( 'label' => __( 'Foto (opcional)', 'curamba-cinematic' ), 'type' => Controls_Manager::MEDIA, 'default' => array( 'url' => '' ) ) );
		$links->add_control( 'link', array( 'label' => __( 'Enlace personalizado (opcional)', 'curamba-cinematic' ), 'type' => Controls_Manager::URL, 'description' => __( 'Si se completa, reemplaza al enlace de la categoría.', 'curamba-cinematic' ) ) );
		$this->ctrl(
			's3_links',
			array(
				'label'       => __( 'Accesos', 'curamba-cinematic' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $links->get_controls(),
				'title_field' => '{{{ label }}}',
			)
		);
		$this->end_controls_section();

		/* ---------- Escena 4 ---------- */
		$this->start_controls_section( 'sec_s4', array( 'label' => __( 'Escena 4 · Carrusel de experiencias', 'curamba-cinematic' ) ) );
		$this->add_control(
			's4_note',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Las tarjetas se crean solas con los productos de WooCommerce: foto destacada, categoría, nombre, descripción corta y precio. Duración, dificultad, disponibilidad y fechas se editan en cada producto (pestaña General → "Datos de la experiencia").', 'curamba-cinematic' ),
				'content_classes' => 'elementor-descriptor',
			)
		);
		$this->ctrl( 's4_kicker', array( 'label' => __( 'Título pequeño', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT ) );
		$this->ctrl(
			's4_categories',
			array(
				'label'       => __( 'Categorías a mostrar', 'curamba-cinematic' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => $categories,
				'label_block' => true,
				'description' => __( 'Vacío = todas las experiencias.', 'curamba-cinematic' ),
			)
		);
		$this->ctrl( 's4_count', array( 'label' => __( 'Cantidad máxima', 'curamba-cinematic' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 20 ) );
		$this->ctrl(
			's4_orderby',
			array(
				'label'   => __( 'Orden', 'curamba-cinematic' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'menu_order' => __( 'Orden manual (WooCommerce)', 'curamba-cinematic' ),
					'date'       => __( 'Más recientes', 'curamba-cinematic' ),
					'popularity' => __( 'Más vendidas', 'curamba-cinematic' ),
					'price'      => __( 'Precio (menor a mayor)', 'curamba-cinematic' ),
					'title'      => __( 'Nombre', 'curamba-cinematic' ),
					'rand'       => __( 'Aleatorio', 'curamba-cinematic' ),
				),
			)
		);
		$this->ctrl( 's4_details_text', array( 'label' => __( 'Botón "Ver detalles"', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT ) );
		$this->ctrl( 's4_book_text', array( 'label' => __( 'Botón "Reservar"', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT ) );
		$this->ctrl(
			's4_book_action',
			array(
				'label'       => __( 'El botón Reservar lleva a', 'curamba-cinematic' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'product'  => __( 'Página del producto (calendario y cupos)', 'curamba-cinematic' ),
					'cart'     => __( 'Añadir al carrito directo (productos simples)', 'curamba-cinematic' ),
					'whatsapp' => __( 'WhatsApp con el nombre de la experiencia', 'curamba-cinematic' ),
				),
				'description' => __( 'Si usas un plugin de reservas por fecha y cupo, elige "Página del producto".', 'curamba-cinematic' ),
			)
		);
		$this->end_controls_section();

		/* ---------- Escena 5 ---------- */
		$this->start_controls_section( 'sec_s5', array( 'label' => __( 'Escena 5 · Panel de reserva y buscador', 'curamba-cinematic' ) ) );
		$this->ctrl( 's5_title', array( 'label' => __( 'Título', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'label_block' => true ) );
		$this->ctrl( 's5_text', array( 'label' => __( 'Texto', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2 ) );
		$this->ctrl( 's5_search_ph', array( 'label' => __( 'Texto del buscador', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT ) );
		foreach (
			array(
				's5_show_date'       => __( 'Filtro por fecha', 'curamba-cinematic' ),
				's5_show_category'   => __( 'Filtro por categoría', 'curamba-cinematic' ),
				's5_show_price'      => __( 'Filtro por precio', 'curamba-cinematic' ),
				's5_show_duration'   => __( 'Filtro por duración', 'curamba-cinematic' ),
				's5_show_difficulty' => __( 'Filtro por dificultad', 'curamba-cinematic' ),
			) as $id => $label
		) {
			$this->ctrl( $id, array( 'label' => $label, 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ) );
		}
		$this->ctrl( 's5_initial', array( 'label' => __( 'Resultados iniciales', 'curamba-cinematic' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 24, 'description' => __( 'Experiencias visibles antes de buscar (0 = ninguna).', 'curamba-cinematic' ) ) );
		$this->ctrl( 's5_all_text', array( 'label' => __( 'Botón "Ver todas"', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT ) );
		$this->ctrl( 's5_all_link', array( 'label' => __( 'Enlace "Ver todas"', 'curamba-cinematic' ), 'type' => Controls_Manager::URL, 'description' => __( 'Vacío = página de la tienda.', 'curamba-cinematic' ) ) );
		$this->ctrl( 's5_wa_text', array( 'label' => __( 'Botón de WhatsApp', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT ) );
		$this->end_controls_section();

		/* ---------- WhatsApp ---------- */
		$this->start_controls_section( 'sec_wa', array( 'label' => __( 'WhatsApp', 'curamba-cinematic' ) ) );
		$this->ctrl( 'wa_number', array( 'label' => __( 'Número con código de país', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'placeholder' => '51 9XX XXX XXX', 'description' => __( 'Solo números. Perú = 51.', 'curamba-cinematic' ) ) );
		$this->ctrl( 'wa_message', array( 'label' => __( 'Mensaje general', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2 ) );
		$this->ctrl( 'wa_product_msg', array( 'label' => __( 'Mensaje por experiencia', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2, 'description' => __( '{experiencia} se reemplaza por el nombre del producto.', 'curamba-cinematic' ) ) );
		$this->ctrl( 'wa_float', array( 'label' => __( 'Botón flotante', 'curamba-cinematic' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ) );
		$this->ctrl( 'wa_float_text', array( 'label' => __( 'Texto del botón flotante', 'curamba-cinematic' ), 'type' => Controls_Manager::TEXT, 'condition' => array( 'wa_float' => 'yes' ) ) );
		$this->end_controls_section();

		/* ---------- Movimiento ---------- */
		$this->start_controls_section( 'sec_motion', array( 'label' => __( 'Movimiento', 'curamba-cinematic' ) ) );
		$this->ctrl(
			'motion_length',
			array(
				'label'       => __( 'Recorrido de scroll (px)', 'curamba-cinematic' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => array( 'px' => array( 'min' => 2400, 'max' => 9000, 'step' => 100 ) ),
				'description' => __( 'Más alto = animación más lenta.', 'curamba-cinematic' ),
				'default'     => array( 'size' => $defaults['motion_length']['size'], 'unit' => 'px' ),
			)
		);
		$this->ctrl(
			'motion_intensity',
			array(
				'label'   => __( 'Intensidad del movimiento (%)', 'curamba-cinematic' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array( 'px' => array( 'min' => 0, 'max' => 150, 'step' => 5 ) ),
				'default' => array( 'size' => $defaults['motion_intensity']['size'], 'unit' => 'px' ),
			)
		);
		$this->ctrl( 'motion_step', array( 'label' => __( 'Vuelo automático entre escenas', 'curamba-cinematic' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'description' => __( 'Un giro de la rueda del mouse lleva suavemente a la escena siguiente.', 'curamba-cinematic' ) ) );
		$this->ctrl(
			'motion_flight',
			array(
				'label'     => __( 'Duración del vuelo (ms)', 'curamba-cinematic' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 600, 'max' => 4000, 'step' => 100 ) ),
				'default'   => array( 'size' => $defaults['motion_flight']['size'], 'unit' => 'px' ),
				'condition' => array( 'motion_step' => 'yes' ),
			)
		);
		$this->ctrl( 'motion_pointer', array( 'label' => __( 'Seguir el mouse (escritorio)', 'curamba-cinematic' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ) );
		$this->ctrl(
			'motion_mobile',
			array(
				'label'       => __( 'En móvil', 'curamba-cinematic' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'static'    => __( 'Secciones simples (recomendado)', 'curamba-cinematic' ),
					'cinematic' => __( 'Cinemático reducido', 'curamba-cinematic' ),
				),
				'description' => __( 'Con "reducir movimiento" activado en el dispositivo siempre se usan secciones simples.', 'curamba-cinematic' ),
			)
		);
		$this->end_controls_section();

		/* ---------- Estilo ---------- */
		$this->start_controls_section( 'sty_colors', array( 'label' => __( 'Colores', 'curamba-cinematic' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$colors = array(
			'c_paper'   => array( __( 'Crema (textos y tarjetas)', 'curamba-cinematic' ), '#fff8ec', '--cc-paper' ),
			'c_ink'     => array( __( 'Tinta (texto oscuro)', 'curamba-cinematic' ), '#11201a', '--cc-ink' ),
			'c_gold'    => array( __( 'Dorado (botones de compra)', 'curamba-cinematic' ), '#ffb21a', '--cc-gold' ),
			'c_coral'   => array( __( 'Coral (degradado de botones)', 'curamba-cinematic' ), '#ff6a3d', '--cc-coral' ),
			'c_accent'  => array( __( 'Acento (categorías y precios)', 'curamba-cinematic' ), '#d6286b', '--cc-accent' ),
			'c_teal'    => array( __( 'Turquesa', 'curamba-cinematic' ), '#00b3a7', '--cc-teal' ),
			'c_emerald' => array( __( 'Verde esmeralda', 'curamba-cinematic' ), '#0b8a52', '--cc-emerald' ),
			'c_deep'    => array( __( 'Fondo profundo', 'curamba-cinematic' ), '#0c2a2a', '--cc-deep' ),
			'c_wa'      => array( __( 'WhatsApp', 'curamba-cinematic' ), '#128c4a', '--cc-wa' ),
		);
		foreach ( $colors as $id => $c ) {
			$this->add_control(
				$id,
				array(
					'label'     => $c[0],
					'type'      => Controls_Manager::COLOR,
					'default'   => $c[1],
					'selectors' => array( '{{WRAPPER}} .cc' => $c[2] . ': {{VALUE}};' ),
				)
			);
		}
		$this->end_controls_section();

		$this->start_controls_section( 'sty_type', array( 'label' => __( 'Tipografía', 'curamba-cinematic' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => 'ty_title',
				'label'          => __( 'Título CURAMBA', 'curamba-cinematic' ),
				'selector'       => '{{WRAPPER}} .cc-hero-title',
				'fields_options' => array(
					'typography'  => array( 'default' => 'yes' ),
					'font_family' => array( 'default' => 'Cinzel' ),
					'font_weight' => array( 'default' => '700' ),
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => 'ty_headings',
				'label'          => __( 'Títulos de escenas', 'curamba-cinematic' ),
				'selector'       => '{{WRAPPER}} .cc-panel__title, {{WRAPPER}} .cc-booking__title, {{WRAPPER}} .cc-facts dt',
				'fields_options' => array(
					'typography'  => array( 'default' => 'yes' ),
					'font_family' => array( 'default' => 'Montserrat' ),
					'font_weight' => array( 'default' => '800' ),
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'ty_body',
				'label'    => __( 'Textos y botones', 'curamba-cinematic' ),
				'selector' => '{{WRAPPER}} .cc',
			)
		);
		$this->add_responsive_control(
			'title_size',
			array(
				'label'      => __( 'Tamaño del título CURAMBA', 'curamba-cinematic' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'vw', 'px', 'rem' ),
				'range'      => array(
					'vw'  => array( 'min' => 8, 'max' => 30 ),
					'px'  => array( 'min' => 48, 'max' => 320 ),
					'rem' => array( 'min' => 3, 'max' => 20 ),
				),
				'selectors'  => array( '{{WRAPPER}} .cc-hero-title' => 'font-size: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		echo curamba_cc_render( $settings ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado dentro de la función.
	}
}
