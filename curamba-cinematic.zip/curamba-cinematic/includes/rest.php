<?php
/**
 * Endpoint público del buscador instantáneo: GET /wp-json/curamba/v1/experiencias
 *
 * Parámetros: q, cat (slug), fecha (AAAA-MM-DD), min, max, duracion (corta|medio|multidia),
 * dificultad (facil|moderada|exigente), cats (slugs separados por coma para limitar), per_page, page.
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'curamba/v1',
			'/experiencias',
			array(
				'methods'             => 'GET',
				'callback'            => 'curamba_cc_rest_search',
				'permission_callback' => '__return_true',
				'args'                => array(
					'q'          => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ),
					// Se envuelve: WordPress pasa ($valor, $request, $param) y sanitize_title() usaría $request como texto alternativo.
					'cat'        => array(
						'type'              => 'string',
						'sanitize_callback' => function ( $v ) {
							return sanitize_title( (string) $v );
						},
						'default'           => '',
					),
					'cats'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ),
					'fecha'      => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ),
					'min'        => array( 'type' => 'number', 'default' => 0 ),
					'max'        => array( 'type' => 'number', 'default' => 0 ),
					'duracion'   => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_key', 'default' => '' ),
					'dificultad' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_key', 'default' => '' ),
					'per_page'   => array( 'type' => 'integer', 'default' => 12 ),
					'page'       => array( 'type' => 'integer', 'default' => 1 ),
				),
			)
		);
	}
);

/**
 * Busca experiencias reales en WooCommerce.
 *
 * @param WP_REST_Request $request Petición.
 * @return WP_REST_Response
 */
function curamba_cc_rest_search( WP_REST_Request $request ) {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return new WP_REST_Response( array( 'total' => 0, 'items' => array() ), 200 );
	}

	$per_page = min( 24, max( 1, (int) $request['per_page'] ) );
	$args     = array(
		'post_type'           => 'product',
		'post_status'         => 'publish',
		'posts_per_page'      => $per_page,
		'paged'               => max( 1, (int) $request['page'] ),
		'ignore_sticky_posts' => true,
		'orderby'             => array(
			'menu_order' => 'ASC',
			'title'      => 'ASC',
		),
		'tax_query'           => array( 'relation' => 'AND' ), // phpcs:ignore WordPress.DB.SlowDBQuery
		'meta_query'          => array( 'relation' => 'AND' ), // phpcs:ignore WordPress.DB.SlowDBQuery
	);

	$q = trim( (string) $request['q'] );
	if ( '' !== $q ) {
		$args['s']       = $q;
		$args['orderby'] = 'relevance';
	}

	// Ocultar productos marcados como "oculto en búsqueda" en WooCommerce.
	$hidden = array( 'exclude-from-search' );
	if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
		$hidden[] = 'outofstock';
	}
	$args['tax_query'][] = array(
		'taxonomy' => 'product_visibility',
		'field'    => 'name',
		'terms'    => $hidden,
		'operator' => 'NOT IN',
	);

	$limit = array_filter( array_map( 'sanitize_title', explode( ',', (string) $request['cats'] ) ) );
	if ( $limit ) {
		$args['tax_query'][] = array(
			'taxonomy' => 'product_cat',
			'field'    => 'slug',
			'terms'    => $limit,
		);
	}
	if ( '' !== $request['cat'] ) {
		$args['tax_query'][] = array(
			'taxonomy' => 'product_cat',
			'field'    => 'slug',
			'terms'    => array( $request['cat'] ),
		);
	}

	$min = (float) $request['min'];
	$max = (float) $request['max'];
	if ( $min > 0 || $max > 0 ) {
		$args['meta_query'][] = array(
			'key'     => '_price',
			'value'   => array( $min, $max > 0 ? $max : PHP_INT_MAX ),
			'compare' => 'BETWEEN',
			'type'    => 'DECIMAL(10,2)',
		);
	}

	$ranges = curamba_cc_duration_ranges();
	if ( isset( $ranges[ $request['duracion'] ] ) ) {
		$range                = $ranges[ $request['duracion'] ];
		$args['meta_query'][] = array(
			'key'     => '_cc_duracion_horas',
			'value'   => array( $range[1], $range[2] ),
			'compare' => 'BETWEEN',
			'type'    => 'DECIMAL(10,2)',
		);
	}

	if ( array_key_exists( $request['dificultad'], curamba_cc_difficulties() ) ) {
		$args['meta_query'][] = array(
			'key'   => '_cc_dificultad',
			'value' => $request['dificultad'],
		);
	}

	$fecha = (string) $request['fecha'];
	if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $fecha ) ) {
		// Coincide con la fecha exacta o con experiencias de fecha flexible (sin fechas cargadas).
		$args['meta_query'][] = array(
			'relation' => 'OR',
			array(
				'key'     => '_cc_fechas',
				'value'   => $fecha,
				'compare' => 'LIKE',
			),
			array(
				'key'     => '_cc_fechas',
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'   => '_cc_fechas',
				'value' => '',
			),
		);
	}

	$query = new WP_Query( $args );
	$items = array();
	foreach ( $query->posts as $post ) {
		$product = wc_get_product( $post );
		if ( ! $product ) {
			continue;
		}
		$data            = curamba_cc_product_data( $product, array( 's4_book_action' => 'product' ) );
		$data['cartUrl'] = ( $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() )
			? add_query_arg( 'add-to-cart', $product->get_id(), wc_get_cart_url() )
			: '';
		unset( $data['waUrl'], $data['bookUrl'], $data['bookIsWa'] );
		$items[] = $data;
	}

	$response = new WP_REST_Response(
		array(
			'total' => (int) $query->found_posts,
			'items' => $items,
		),
		200
	);
	$response->header( 'Cache-Control', 'public, max-age=60' );
	return $response;
}
