<?php
/**
 * Campos de experiencia en el producto de WooCommerce (Producto → Datos del producto → General).
 * Alimentan las tarjetas del carrusel y los filtros del buscador.
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'woocommerce_product_options_general_product_data',
	function () {
		echo '<div class="options_group curamba-cc-fields">';
		echo '<p class="form-field"><strong>' . esc_html__( 'Datos de la experiencia (Curamba)', 'curamba-cinematic' ) . '</strong></p>';

		woocommerce_wp_text_input(
			array(
				'id'                => '_cc_duracion_horas',
				'label'             => __( 'Duración (horas)', 'curamba-cinematic' ),
				'description'       => __( 'Número usado por el filtro de duración. Ej.: 3, 8, 48.', 'curamba-cinematic' ),
				'desc_tip'          => true,
				'type'              => 'number',
				'custom_attributes' => array(
					'step' => '0.5',
					'min'  => '0',
				),
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_cc_duracion_texto',
				'label'       => __( 'Duración (texto visible)', 'curamba-cinematic' ),
				'description' => __( 'Opcional. Ej.: "Día completo" o "2 días / 1 noche".', 'curamba-cinematic' ),
				'desc_tip'    => true,
			)
		);
		woocommerce_wp_select(
			array(
				'id'      => '_cc_dificultad',
				'label'   => __( 'Dificultad', 'curamba-cinematic' ),
				'options' => array_merge( array( '' => __( '— Sin indicar —', 'curamba-cinematic' ) ), curamba_cc_difficulties() ),
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_cc_disponibilidad',
				'label'       => __( 'Disponibilidad (texto)', 'curamba-cinematic' ),
				'description' => __( 'Opcional. Ej.: "Salidas diarias". Si se deja vacío se muestra el stock/cupos de WooCommerce.', 'curamba-cinematic' ),
				'desc_tip'    => true,
			)
		);
		woocommerce_wp_textarea_input(
			array(
				'id'          => '_cc_fechas',
				'label'       => __( 'Fechas de salida', 'curamba-cinematic' ),
				'description' => __( 'Una por línea: AAAA-MM-DD o AAAA-MM-DD|cupos (ej. 2026-12-05|12). Vacío = fecha flexible: el cliente indica la fecha deseada.', 'curamba-cinematic' ),
				'desc_tip'    => true,
				'placeholder' => "2026-12-05|12\n2026-12-12",
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'                => '_cc_cupo',
				'label'             => __( 'Cupos por fecha', 'curamba-cinematic' ),
				'description'       => __( 'Personas por salida cuando la fecha no indica cupos. 0 = sin límite.', 'curamba-cinematic' ),
				'desc_tip'          => true,
				'type'              => 'number',
				'custom_attributes' => array(
					'step' => '1',
					'min'  => '0',
				),
			)
		);
		echo '</div>';
	}
);

add_action(
	'woocommerce_admin_process_product_object',
	function ( $product ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- WooCommerce ya verifica el nonce del formulario de producto.
		if ( isset( $_POST['_cc_duracion_horas'] ) ) {
			$hours = wc_format_decimal( wp_unslash( $_POST['_cc_duracion_horas'] ) );
			$product->update_meta_data( '_cc_duracion_horas', '' === $hours ? '' : (string) max( 0, (float) $hours ) );
		}
		if ( isset( $_POST['_cc_duracion_texto'] ) ) {
			$product->update_meta_data( '_cc_duracion_texto', sanitize_text_field( wp_unslash( $_POST['_cc_duracion_texto'] ) ) );
		}
		if ( isset( $_POST['_cc_dificultad'] ) ) {
			$diff = sanitize_key( wp_unslash( $_POST['_cc_dificultad'] ) );
			$product->update_meta_data( '_cc_dificultad', array_key_exists( $diff, curamba_cc_difficulties() ) ? $diff : '' );
		}
		if ( isset( $_POST['_cc_disponibilidad'] ) ) {
			$product->update_meta_data( '_cc_disponibilidad', sanitize_text_field( wp_unslash( $_POST['_cc_disponibilidad'] ) ) );
		}
		if ( isset( $_POST['_cc_cupo'] ) ) {
			$product->update_meta_data( '_cc_cupo', (string) max( 0, absint( wp_unslash( $_POST['_cc_cupo'] ) ) ) );
		}
		if ( isset( $_POST['_cc_fechas'] ) ) {
			$raw   = preg_split( '/[\r\n,;]+/', (string) wp_unslash( $_POST['_cc_fechas'] ) );
			$dates = array();
			foreach ( (array) $raw as $d ) {
				$d = preg_replace( '/\s+/', '', $d );
				if ( preg_match( '/^(\d{4}-\d{2}-\d{2})(\|\d+)?$/', $d, $m ) ) {
					$dates[ $m[1] ] = $d; // Una línea por fecha (la última gana).
				}
			}
			ksort( $dates );
			$dates = array_values( $dates );
			// Se guarda separado por saltos de línea para mostrarlo igual en el formulario y buscarlo con LIKE.
			$product->update_meta_data( '_cc_fechas', implode( "\n", $dates ) );
		}
		// phpcs:enable
	}
);
