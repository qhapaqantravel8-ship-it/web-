<?php
/**
 * Acceso exclusivo del administrador.
 *
 * Cuando existe el usuario administrador indicado (por defecto "CURAMBA2026-2"), SOLO ese usuario puede
 * entrar al panel de WordPress, editar con Elementor, cambiar productos, precios, fotos, plugins o ajustes.
 * Cualquier otra cuenta (clientes de WooCommerce, otros administradores, editores…) pierde esos permisos.
 * Los visitantes siguen viendo la web, reservando y escribiendo por WhatsApp con normalidad.
 *
 * La contraseña NO se guarda en el plugin: se define al crear el usuario en WordPress.
 * Emergencia: añade  define( 'CURAMBA_CC_DISABLE_LOCK', true );  en wp-config.php para desactivar el bloqueo.
 *
 * @package curamba-cinematic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true ); // Sin editor de código en el panel.
}

/**
 * Usuario (login) del administrador único.
 *
 * @return string
 */
function curamba_cc_owner_login() {
	return (string) apply_filters( 'curamba_cc_owner_login', get_option( 'curamba_cc_owner_login', 'CURAMBA2026-2' ) );
}

/**
 * Objeto del administrador único, o null si aún no existe.
 *
 * @return WP_User|null
 */
function curamba_cc_owner() {
	static $cache = false;
	if ( false !== $cache ) {
		return $cache;
	}
	$user  = get_user_by( 'login', curamba_cc_owner_login() );
	$cache = ( $user && in_array( 'administrator', (array) $user->roles, true ) ) ? $user : null;
	return $cache;
}

/**
 * ¿Está activo el acceso exclusivo? Solo si el administrador único ya existe (así nunca se bloquea el sitio por error).
 *
 * @return bool
 */
function curamba_cc_lock_active() {
	if ( defined( 'CURAMBA_CC_DISABLE_LOCK' ) && CURAMBA_CC_DISABLE_LOCK ) {
		return false;
	}
	if ( 'no' === get_option( 'curamba_cc_lock', 'yes' ) ) {
		return false;
	}
	return null !== curamba_cc_owner();
}

/**
 * ¿Es este usuario el administrador único?
 *
 * @param int $user_id ID.
 * @return bool
 */
function curamba_cc_is_owner( $user_id ) {
	$owner = curamba_cc_owner();
	return $owner && (int) $owner->ID === (int) $user_id;
}

/**
 * Quita todos los permisos de edición/administración a cualquier cuenta que no sea la del administrador único.
 */
add_filter(
	'user_has_cap',
	function ( $allcaps, $caps, $args, $user ) {
		if ( ! $user || empty( $user->ID ) || ! curamba_cc_lock_active() || curamba_cc_is_owner( $user->ID ) ) {
			return $allcaps;
		}
		$keep = array( 'read' => true, 'exist' => true, 'level_0' => true );
		foreach ( (array) $user->roles as $role ) {
			$keep[ $role ] = true; // Conserva el nombre del rol (p. ej. "customer") para WooCommerce.
		}
		return array_intersect_key( $allcaps, $keep );
	},
	999,
	4
);

/**
 * Nadie más que el administrador único entra a /wp-admin (las peticiones AJAX del sitio siguen funcionando).
 */
add_action(
	'admin_init',
	function () {
		if ( ! curamba_cc_lock_active() || ! is_user_logged_in() || curamba_cc_is_owner( get_current_user_id() ) ) {
			return;
		}
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( sanitize_text_field( wp_unslash( $_SERVER['SCRIPT_NAME'] ) ) ) : '';
		if ( 'admin-post.php' === $script ) {
			return;
		}
		$to = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/' );
		wp_safe_redirect( $to );
		exit;
	},
	1
);

/** Barra de administración solo para el administrador único. */
add_filter(
	'show_admin_bar',
	function ( $show ) {
		if ( curamba_cc_lock_active() && ! curamba_cc_is_owner( get_current_user_id() ) ) {
			return false;
		}
		return $show;
	}
);

/* ---------- Protección del inicio de sesión ---------- */

/**
 * Clave del contador de intentos fallidos por IP.
 *
 * @return string
 */
function curamba_cc_login_key() {
	return 'cc_lf_' . md5( curamba_cc_client_ip() );
}

/**
 * IP real del visitante.
 *
 * Por defecto se usa REMOTE_ADDR (no se puede falsificar). Si el hosting está detrás de Cloudflare
 * u otro proxy, todos los visitantes llegarían con la IP del proxy y 5 intentos de cualquiera
 * bloquearían a todos (también al administrador). En ese caso añade en wp-config.php:
 *   define( 'CURAMBA_CC_PROXY_HEADER', 'HTTP_CF_CONNECTING_IP' );   // Cloudflare
 *   define( 'CURAMBA_CC_PROXY_HEADER', 'HTTP_X_FORWARDED_FOR' );    // otros proxys
 * Solo actívalo si de verdad hay un proxy delante: si no, un atacante podría inventar esa cabecera.
 *
 * @return string
 */
function curamba_cc_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	if ( defined( 'CURAMBA_CC_PROXY_HEADER' ) && is_string( CURAMBA_CC_PROXY_HEADER ) && ! empty( $_SERVER[ CURAMBA_CC_PROXY_HEADER ] ) ) {
		// X-Forwarded-For puede traer una lista: la primera es la del visitante.
		$list      = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ CURAMBA_CC_PROXY_HEADER ] ) ) );
		$candidate = trim( $list[0] );
		if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
			$ip = $candidate;
		}
	}
	return '' !== $ip ? $ip : 'x';
}

add_action(
	'wp_login_failed',
	function () {
		$k = curamba_cc_login_key();
		set_transient( $k, (int) get_transient( $k ) + 1, 15 * MINUTE_IN_SECONDS );
	}
);

add_filter(
	'authenticate',
	function ( $user ) {
		if ( (int) get_transient( curamba_cc_login_key() ) >= 5 ) {
			return new WP_Error( 'cc_bloqueado', __( 'Demasiados intentos fallidos. Espera 15 minutos e inténtalo de nuevo.', 'curamba-cinematic' ) );
		}
		return $user;
	},
	99
);

add_action(
	'wp_login',
	function () {
		delete_transient( curamba_cc_login_key() );
	}
);

/** Mensaje de error genérico: no revela si el usuario existe. */
add_filter(
	'login_errors',
	function ( $error ) {
		if ( false !== strpos( (string) $error, 'Demasiados intentos' ) ) {
			return $error;
		}
		return __( 'Usuario o contraseña incorrectos.', 'curamba-cinematic' );
	}
);

/** Sin XML-RPC ni contraseñas de aplicación (vías comunes de ataque). */
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'wp_is_application_passwords_available', '__return_false' );
// 'xmlrpc_enabled' solo apaga los métodos con contraseña: pingback y system.multicall seguían activos
// (se usan para ataques de fuerza bruta y para usar el sitio en ataques a terceros). Se cierran todos.
add_filter( 'xmlrpc_methods', '__return_empty_array', 999 );
add_filter(
	'wp_headers',
	function ( $headers ) {
		unset( $headers['X-Pingback'] );
		return $headers;
	}
);
add_filter( 'pings_open', '__return_false', 999 );
if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST && ! ( defined( 'CURAMBA_CC_ALLOW_XMLRPC' ) && CURAMBA_CC_ALLOW_XMLRPC ) ) {
	status_header( 403 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	exit( 'XML-RPC desactivado.' );
}

/** El mapa del sitio no publica autores (revelaría el nombre de usuario del administrador). */
add_filter(
	'wp_sitemaps_add_provider',
	function ( $provider, $name ) {
		return 'users' === $name ? false : $provider;
	},
	10,
	2
);
/** Los datos de oEmbed no muestran el autor. */
add_filter(
	'oembed_response_data',
	function ( $data ) {
		unset( $data['author_name'], $data['author_url'] );
		return $data;
	}
);

/** Evita que se pueda descubrir el nombre de usuario del administrador. */
add_filter(
	'rest_endpoints',
	function ( $endpoints ) {
		if ( ! is_user_logged_in() ) {
			foreach ( array_keys( $endpoints ) as $route ) {
				if ( 0 === strpos( $route, '/wp/v2/users' ) ) {
					unset( $endpoints[ $route ] );
				}
			}
		}
		return $endpoints;
	}
);
add_action(
	'template_redirect',
	function () {
		// Tanto ?author=1 como /author/usuario/ (con enlaces bonitos) revelan el nombre de usuario.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ( isset( $_GET['author'] ) || is_author() ) && ! is_user_logged_in() ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}
);

/** Aviso para crear el usuario si todavía no existe. */
add_action(
	'admin_notices',
	function () {
		if ( curamba_cc_owner() || ! current_user_can( 'manage_options' ) || 'no' === get_option( 'curamba_cc_lock', 'yes' ) ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p><strong>Curamba:</strong> %s</p></div>',
			esc_html(
				sprintf(
					/* translators: %s: usuario */
					__( 'Para activar el acceso exclusivo, crea el usuario "%s" con el rol Administrador (Usuarios → Añadir nuevo) y entra con él. Desde ese momento solo esa cuenta podrá editar el sitio.', 'curamba-cinematic' ),
					curamba_cc_owner_login()
				)
			)
		);
	}
);
