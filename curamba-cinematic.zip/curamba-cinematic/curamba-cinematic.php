<?php
/**
 * Plugin Name:       Curamba Cinematic
 * Description:       Portada cinematográfica por capas para Curamba: widget de Elementor editable, carrusel y buscador conectados a WooCommerce y contacto por WhatsApp.
 * Version:           2.8.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Curamba
 * Text Domain:       curamba-cinematic
 * License:           GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CURAMBA_CC_VERSION', '2.8.0' );
define( 'CURAMBA_CC_FILE', __FILE__ );
define( 'CURAMBA_CC_DIR', plugin_dir_path( __FILE__ ) );
define( 'CURAMBA_CC_URL', plugin_dir_url( __FILE__ ) );

require_once CURAMBA_CC_DIR . 'includes/helpers.php';
require_once CURAMBA_CC_DIR . 'includes/product-fields.php';
require_once CURAMBA_CC_DIR . 'includes/rest.php';
require_once CURAMBA_CC_DIR . 'includes/render.php';
require_once CURAMBA_CC_DIR . 'includes/security.php';
require_once CURAMBA_CC_DIR . 'includes/settings.php';
require_once CURAMBA_CC_DIR . 'includes/chatbot.php';
require_once CURAMBA_CC_DIR . 'includes/legal.php';
require_once CURAMBA_CC_DIR . 'includes/feedback.php';
add_action(
	'plugins_loaded',
	function () {
		if ( class_exists( 'WooCommerce' ) ) {
			require_once CURAMBA_CC_DIR . 'includes/booking.php';
		}
	}
);

register_deactivation_hook(
	__FILE__,
	function () {
		wp_clear_scheduled_hook( 'curamba_cc_release_unpaid' );
	}
);

/**
 * Registra (sin encolar) los recursos. Solo se cargan en páginas que usan el widget o el shortcode.
 */
function curamba_cc_register_assets() {
	$deps = array();
	// Tipografías: Cinzel (nombre CURAMBA) + Montserrat (titulares y textos). Se puede desactivar con el filtro.
	if ( apply_filters( 'curamba_cc_google_fonts', true ) ) {
		// Rangos variables completos: así cubre también lo que pida Elementor y se pueden quitar sus copias duplicadas.
		wp_register_style( 'curamba-cc-fonts', 'https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&family=Montserrat:ital,wght@0,300..900;1,300..900&display=swap', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
		$deps[] = 'curamba-cc-fonts';
	}
	wp_register_style( 'curamba-cinematic', CURAMBA_CC_URL . 'assets/css/curamba-cinematic.css', $deps, CURAMBA_CC_VERSION );
	wp_register_script( 'curamba-cinematic', CURAMBA_CC_URL . 'assets/js/curamba-cinematic.js', array(), CURAMBA_CC_VERSION, true );
	if ( function_exists( 'wp_script_add_data' ) ) {
		wp_script_add_data( 'curamba-cinematic', 'strategy', 'defer' );
	}
	wp_localize_script(
		'curamba-cinematic',
		'curambaCinematicGlobals',
		array(
			'restUrl' => esc_url_raw( rest_url( 'curamba/v1/experiencias' ) ),
			'i18n'    => array(
				'results'   => __( '%d experiencias encontradas', 'curamba-cinematic' ),
				'oneResult' => __( '1 experiencia encontrada', 'curamba-cinematic' ),
				'none'      => __( 'No encontramos experiencias con esos filtros. Prueba otra fecha o escríbenos por WhatsApp.', 'curamba-cinematic' ),
				'error'     => __( 'No se pudo cargar la búsqueda. Inténtalo de nuevo.', 'curamba-cinematic' ),
				'loading'   => __( 'Buscando…', 'curamba-cinematic' ),
				'slideOf'   => __( 'Experiencia %1$d de %2$d', 'curamba-cinematic' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'curamba_cc_register_assets', 5 );
add_action( 'elementor/frontend/after_register_scripts', 'curamba_cc_register_assets' );
add_action( 'elementor/frontend/after_register_styles', 'curamba_cc_register_assets' );

/**
 * Widget de Elementor.
 */
add_action(
	'elementor/widgets/register',
	function ( $widgets_manager ) {
		require_once CURAMBA_CC_DIR . 'includes/class-elementor-widget.php';
		$widgets_manager->register( new \Curamba_CC_Elementor_Widget() );
	}
);

/**
 * Shortcode de respaldo: [curamba_cinematic]. Usa los textos por defecto (útil sin Elementor).
 */
add_shortcode(
	'curamba_cinematic',
	function () {
		wp_enqueue_style( 'curamba-cinematic' );
		wp_enqueue_script( 'curamba-cinematic' );
		return curamba_cc_render( curamba_cc_default_settings() );
	}
);

/**
 * Tipografías duplicadas: si la página ya carga Cinzel y Montserrat desde el plugin,
 * no se vuelven a pedir las copias que agrega Elementor (menos peticiones que bloquean la carga).
 */
add_filter(
	'style_loader_tag',
	function ( $tag, $handle ) {
		if ( ! in_array( $handle, array( 'elementor-gf-cinzel', 'elementor-gf-montserrat' ), true ) ) {
			return $tag;
		}
		// Se carga como dependencia del estilo del widget: puede estar en cola, pendiente o ya impreso.
		if ( wp_style_is( 'curamba-cc-fonts', 'done' ) || wp_style_is( 'curamba-cc-fonts', 'to_do' ) || wp_style_is( 'curamba-cc-fonts', 'enqueued' ) ) {
			return '';
		}
		return $tag;
	},
	10,
	2
);

/**
 * Las optimizaciones de LiteSpeed (retrasar/combinar JS) no deben romper la animación.
 */
add_filter(
	'litespeed_optimize_js_excludes',
	function ( $excludes ) {
		$excludes   = (array) $excludes;
		$excludes[] = 'curamba-cinematic.js';
		return $excludes;
	}
);
add_filter(
	'litespeed_optm_js_defer_exc',
	function ( $excludes ) {
		$excludes   = (array) $excludes;
		$excludes[] = 'curamba-cinematic.js';
		$excludes[] = 'curambaCinematicGlobals';
		return $excludes;
	}
);
