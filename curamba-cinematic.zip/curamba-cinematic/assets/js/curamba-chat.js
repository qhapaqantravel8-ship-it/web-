/* Asistente de chat de Curamba: preguntas frecuentes editables, precios en vivo de WooCommerce y paso a WhatsApp. */
(function () {
	'use strict';

	var C = window.curambaChat;
	var root = document.querySelector('[data-cca]');
	if (!C || !root) return;

	var launch = root.querySelector('[data-cca-launch]');
	var panel = root.querySelector('[data-cca-panel]');
	var log = root.querySelector('[data-cca-log]');
	var form = root.querySelector('[data-cca-form]');
	var input = root.querySelector('[data-cca-input]');
	var hint = root.querySelector('[data-cca-hint]');
	var closeBtn = root.querySelector('[data-cca-close]');
	var faqs = (C.faqs || []).filter(function (f) { return f && f.q && f.a; });
	var started = false, catalog = null, busy = false;

	root.hidden = false;

	/* ---------- utilidades ---------- */
	function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text) n.textContent = text; return n; }
	function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9ñ\s]/g, ' ').replace(/\s+/g, ' ').trim(); }
	function waUrl(msg) { return 'https://wa.me/' + (C.wa || '') + (msg ? '?text=' + encodeURIComponent(msg) : ''); }
	function track(name, label) {
		try {
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({ event: 'curamba_' + name, curamba_label: label || '' });
			if (typeof window.gtag === 'function') window.gtag('event', name, { event_category: 'curamba', event_label: label || '' });
			if (name === 'whatsapp_click' && typeof window.fbq === 'function') window.fbq('track', 'Contact');
		} catch (e) { /* sin bloqueo */ }
	}
	function scrollEnd() { log.scrollTop = log.scrollHeight; }

	// Texto con saltos de línea y enlaces seguros (nunca HTML del usuario).
	function richText(node, text) {
		String(text || '').split('\n').forEach(function (line, i) {
			if (i) node.appendChild(document.createElement('br'));
			line.split(/(https?:\/\/[^\s]+)/g).forEach(function (part) {
				if (/^https?:\/\//.test(part)) {
					var a = el('a', '', part.replace(/^https?:\/\//, ''));
					a.href = part; a.target = '_blank'; a.rel = 'noopener';
					node.appendChild(a);
				} else if (part) node.appendChild(document.createTextNode(part));
			});
		});
		return node;
	}

	/* ---------- mensajes ---------- */
	function add(who, content) {
		var row = el('div', 'cca-msg cca-msg--' + who);
		var b = el('div', 'cca-bubble');
		if (typeof content === 'string') richText(b, content); else b.appendChild(content);
		row.appendChild(b);
		log.appendChild(row);
		scrollEnd();
		return row;
	}
	// El asistente "escribe" un momento antes de responder (se siente más natural).
	function bot(content, then) {
		busy = true;
		var t = el('div', 'cca-msg cca-msg--bot cca-typing');
		t.appendChild(el('div', 'cca-bubble')).innerHTML = '<i></i><i></i><i></i>';
		log.appendChild(t); scrollEnd();
		setTimeout(function () {
			t.remove();
			if (content) add('bot', content);
			busy = false;
			if (then) then();
		}, 420);
	}
	function chips(list) {
		var wrap = el('div', 'cca-chips');
		list.forEach(function (c) {
			var b = el('button', 'cca-chip' + (c.wa ? ' cca-chip--wa' : ''), c.label);
			b.type = 'button';
			b.addEventListener('click', function () {
				if (busy) return;
				wrap.querySelectorAll('button').forEach(function (x) { x.disabled = true; });
				c.fn();
			});
			wrap.appendChild(b);
		});
		log.appendChild(wrap); scrollEnd();
	}
	function waButton(msg, label) {
		var a = el('a', 'cca-wa', label || 'Escribir por WhatsApp');
		a.href = waUrl(msg); a.target = '_blank'; a.rel = 'noopener';
		a.addEventListener('click', function () { track('whatsapp_click', 'asistente'); });
		return a;
	}

	/* ---------- menú principal ---------- */
	function menu(short) {
		var list = [{ label: '💰 Experiencias y precios', fn: function () { ask('Experiencias y precios', prices); } }];
		faqs.forEach(function (f) { list.push({ label: f.q, fn: function () { ask(f.q, function () { answerFaq(f); }); } }); });
		list.push({ label: '💬 Hablar con una persona', wa: true, fn: function () { ask('Hablar con una persona', human); } });
		if (short) list = [list[0], { label: 'Ver más preguntas', fn: function () { ask('Ver más preguntas', function () { bot('Claro, elige una opción:', function () { menu(); }); }); } }, list[list.length - 1]];
		chips(list);
	}
	function ask(label, fn) { add('user', label); fn(); }
	function answerFaq(f) { bot(f.a, function () { menu(true); }); }
	function human() {
		var box = el('div');
		richText(box, 'Te atiende nuestro equipo por WhatsApp. Toca el botón y envía el mensaje:');
		box.appendChild(waButton('Hola, quiero información para visitar Curamba.'));
		bot(box, function () { menu(true); });
	}

	/* ---------- experiencias y precios (en vivo desde WooCommerce) ---------- */
	function loadCatalog() {
		if (catalog) return Promise.resolve(catalog);
		var url = C.restUrl + (C.restUrl.indexOf('?') > -1 ? '&' : '?') + 'per_page=24';
		return fetch(url, { headers: { Accept: 'application/json' } })
			.then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
			.then(function (d) { catalog = (d && d.items) || []; return catalog; });
	}
	function cards(items) {
		var box = el('div', 'cca-cards');
		items.forEach(function (it) {
			var c = el('article', 'cca-card');
			if (it.image) { var img = el('img'); img.src = it.image; img.alt = ''; img.loading = 'lazy'; img.width = 64; img.height = 64; c.appendChild(img); }
			var body = el('div', 'cca-card__body');
			body.appendChild(el('strong', 'cca-card__title', it.name));
			var meta = [it.duration, it.difficulty, it.availability].filter(Boolean).join(' · ');
			if (meta) body.appendChild(el('span', 'cca-card__meta', meta));
			var foot = el('div', 'cca-card__foot');
			var price = el('span', 'cca-card__price');
			price.innerHTML = it.priceHtml || ''; // HTML de precio generado por WooCommerce en el propio sitio
			foot.appendChild(price);
			var go = el('a', 'cca-card__btn', 'Reservar');
			go.href = it.url;
			go.addEventListener('click', function () { track('reservar_click', 'asistente: ' + it.name); });
			foot.appendChild(go);
			body.appendChild(foot);
			c.appendChild(body);
			box.appendChild(c);
		});
		return box;
	}
	function showItems(items, intro) {
		bot(intro, function () {
			var row = add('bot', cards(items));
			var tip = el('div');
			richText(tip, '¿Tienes dudas sobre alguna? Escríbenos y te ayudamos a elegir.');
			tip.appendChild(waButton('Hola, quiero ayuda para elegir una experiencia en Curamba.'));
			add('bot', tip);
			menu(true);
			// Se muestra el inicio de la lista (no el final) para leerla de arriba abajo.
			log.scrollTop = Math.max(0, row.offsetTop - 70);
		});
	}
	function prices() {
		busy = true;
		loadCatalog().then(function (items) {
			busy = false;
			if (!items.length) { bot('Todavía no hay experiencias publicadas. Escríbenos y te contamos las opciones.', human); return; }
			showItems(items, 'Estas son nuestras experiencias y sus precios por persona:');
		}).catch(function () {
			busy = false;
			bot('No pude cargar los precios en este momento. Te los enviamos por WhatsApp:', human);
		});
	}

	/* ---------- texto libre ---------- */
	var STOP = 'de la el los las en y a un una por para con del al que me mi se es son hay cual cuales como donde cuando quiero quisiera saber info informacion curamba experiencia experiencias tour tours andahuaylas'.split(' ');
	var PRICE = /\b(precio|precios|costo|costos|cuesta|cuestan|cuanto|tarifa|tarifas|valor|vale|soles|paquete|paquetes|experiencias|tours|catalogo|opciones)\b/;
	function tokens(s) { return norm(s).split(' ').filter(function (w) { return w.length > 2 && STOP.indexOf(w) < 0; }); }
	function faqScore(f, text) {
		var t = ' ' + text + ' ', score = 0;
		String(f.k || '').split(',').concat([f.q]).forEach(function (k) {
			k = norm(k);
			if (k && k.length > 2 && t.indexOf(' ' + k) > -1) score += k.split(' ').length;
		});
		return score;
	}
	function reply(raw) {
		var text = norm(raw);
		if (!text) return;
		if (/^(hola|buenas|buenos dias|buenas tardes|buenas noches|hey|alo)\b/.test(text) && text.split(' ').length <= 2) {
			bot('¡Hola! 😊 ¿En qué te ayudo?', function () { menu(); });
			return;
		}
		if (/\b(gracias|muchas gracias|genial|perfecto|ok|listo)\b/.test(text) && text.split(' ').length <= 4) {
			bot('¡Con gusto! Si necesitas algo más, aquí estoy. 🏔️', function () { menu(true); });
			return;
		}
		busy = true;
		loadCatalog().catch(function () { return []; }).then(function (items) {
			busy = false;
			var words = tokens(text);
			// 1) ¿Menciona una experiencia concreta?
			var best = 0, found = [];
			items.forEach(function (it) {
				var name = tokens(it.name), s = 0;
				name.forEach(function (w) { if (words.indexOf(w) > -1) s++; });
				if (s > best) { best = s; found = [it]; } else if (s && s === best) found.push(it);
			});
			// 2) ¿Coincide con una pregunta frecuente?
			var fBest = 0, faq = null;
			faqs.forEach(function (f) { var s = faqScore(f, text); if (s > fBest) { fBest = s; faq = f; } });

			if (best > 0 && best >= fBest) {
				showItems(found.slice(0, 4), found.length > 1 ? 'Encontré estas experiencias:' : 'Esta es la experiencia que buscas:');
				return;
			}
			if (faq) { answerFaq(faq); return; }
			if (PRICE.test(text) && items.length) { showItems(items, 'Estas son nuestras experiencias y sus precios por persona:'); return; }
			// 3) No sé la respuesta → WhatsApp con la pregunta ya escrita.
			var box = el('div');
			richText(box, 'Esa pregunta prefiero que te la responda nuestro equipo. Toca el botón y tu pregunta llegará escrita a nuestro WhatsApp:');
			box.appendChild(waButton('Hola, tengo una consulta sobre Curamba: ' + String(raw).trim()));
			bot(box, function () { menu(true); });
		});
	}

	/* ---------- abrir / cerrar ---------- */
	function open() {
		panel.hidden = false;
		root.classList.add('is-open');
		launch.setAttribute('aria-expanded', 'true');
		hideHint();
		if (!started) { started = true; track('chat_open', ''); bot(C.greeting, function () { menu(); }); }
		if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) setTimeout(function () { input.focus(); }, 60);
	}
	function close() {
		panel.hidden = true;
		root.classList.remove('is-open');
		launch.setAttribute('aria-expanded', 'false');
		launch.focus();
	}
	launch.addEventListener('click', function () { if (panel.hidden) open(); else close(); });
	closeBtn.addEventListener('click', close);
	root.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !panel.hidden) close(); });
	form.addEventListener('submit', function (e) {
		e.preventDefault();
		var v = input.value.trim();
		if (!v || busy) return;
		input.value = '';
		add('user', v);
		reply(v);
	});

	// Burbuja de invitación: una vez por visita, a los 5 segundos.
	function hideHint() { if (hint) hint.classList.remove('is-on'); }
	var seen = false;
	try { seen = sessionStorage.getItem('ccaHint') === '1'; } catch (e) { seen = false; }
	if (hint && !seen) {
		setTimeout(function () {
			if (!panel.hidden) return;
			hint.classList.add('is-on');
			try { sessionStorage.setItem('ccaHint', '1'); } catch (e) { /* sin almacenamiento */ }
			setTimeout(hideHint, 9000);
		}, 5000);
		hint.addEventListener('click', open);
	}
})();
