/* Curamba Cinematic — animación por scroll, carrusel infinito, buscador WooCommerce y medición de conversiones. */
(function () {
	'use strict';

	var G = window.curambaCinematicGlobals || { restUrl: '', i18n: {} };
	var T = G.i18n || {};
	var instances = [];

	/* ---------- utilidades ---------- */
	function clamp(v, a, b) { return Math.min(b === undefined ? 1 : b, Math.max(a || 0, v)); }
	function smooth(e0, e1, v) { var x = clamp((v - e0) / (e1 - e0)); return x * x * (3 - 2 * x); }
	function lerp(a, b, t) { return a + (b - a) * t; }
	function seg(p, a, b, c, d) { var en = smooth(a, b, p), ex = smooth(c, d, p); return { en: en, ex: ex, on: en * (1 - ex) }; }
	function fmt(str, a, b) { return String(str || '').replace('%1$d', a).replace('%2$d', b).replace('%d', a); }
	function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text) n.textContent = text; return n; }
	function waUrl(number, msg) { return 'https://wa.me/' + (number || '') + (msg ? '?text=' + encodeURIComponent(msg) : ''); }

	/* ---------- medición de conversiones ---------- */
	function track(name, label) {
		try {
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({ event: 'curamba_' + name, curamba_label: label || '' });
			if (typeof window.gtag === 'function') window.gtag('event', name, { event_category: 'curamba', event_label: label || '' });
			if (typeof window.fbq === 'function') {
				if (name === 'whatsapp_click') window.fbq('track', 'Contact');
				else if (name === 'reservar_click') window.fbq('track', 'InitiateCheckout');
				else if (name === 'search') window.fbq('track', 'Search', { search_string: label || '' });
			}
		} catch (e) { /* sin bloqueo */ }
	}
	document.addEventListener('click', function (e) {
		var a = e.target.closest && e.target.closest('.cc [data-cc-track]');
		if (a) track(a.getAttribute('data-cc-track'), a.getAttribute('data-cc-label'));
	});

	/* =========================================================
	   Instancia
	   ========================================================= */
	function Cinematic(root) {
		var cfg = {};
		try { cfg = JSON.parse(root.getAttribute('data-cc-config') || '{}'); } catch (e) { cfg = {}; }
		cfg.length = cfg.length || 4200;
		cfg.intensity = typeof cfg.intensity === 'number' ? cfg.intensity : 1;

		var P = 1000;          // perspectiva (igual que en CSS y PHP)
		var GAP = 2600;        // distancia entre capítulos
		var scroll = root.querySelector('.cc-scroll');
		var stage = root.querySelector('.cc-stage');
		var world = root.querySelector('[data-cc-world]');
		var chapters = Array.prototype.slice.call(root.querySelectorAll('.cc-ch'));
		var clouds = Array.prototype.slice.call(root.querySelectorAll('[data-cc-cloud]')).map(function (n) {
			return { el: n, z: Number(n.getAttribute('data-z')) || 0 };
		});
		var intro = root.querySelector('.cc-intro');
		// Textos y tarjetas: en modo cine pasan a una capa 2D encima del vuelo (ver liftContent).
		var CONTENT = '.cc-hero-title, .cc-intro, .cc-ch2-grid, .cc-ch3-inner, .cc-ch4-inner';
		// Capas 3D de cada capítulo (fotos y paisaje): la opacidad se aplica a cada capa, no a una variable heredada,
		// así el navegador no recalcula todos los elementos del capítulo en cada cuadro.
		var leaves = chapters.map(function (c) {
			return Array.prototype.slice.call(c.querySelectorAll('.cc-leaf')).filter(function (n) {
				return !n.matches(CONTENT);
			}).map(function (n) {
				return { el: n, f: n.classList.contains('cc-ch2-bg') ? 0.6 : 1 };
			});
		});
		var hud = null, huds = [];
		function liftContent() {
			if (hud) return;
			hud = el('div', 'cc-hud');
			stage.appendChild(hud);
			chapters.forEach(function (c, i) {
				Array.prototype.slice.call(c.querySelectorAll(CONTENT)).forEach(function (n) {
					var ph = document.createComment('cc');
					n.parentNode.replaceChild(ph, n);
					if (c.hasAttribute('data-cc-scene')) n.setAttribute('data-cc-scene', c.getAttribute('data-cc-scene'));
					hud.appendChild(n);
					huds.push({ el: n, i: i, ph: ph, intro: n === intro });
				});
			});
		}
		function dropContent() {
			huds.forEach(function (h) {
				h.el.style.removeProperty('opacity');
				h.el.style.removeProperty('transform');
				h.el.classList.remove('is-off', 'is-live');
				if (h.ph.parentNode) h.ph.parentNode.replaceChild(h.el, h.ph);
			});
			huds = [];
			if (hud && hud.parentNode) hud.parentNode.removeChild(hud);
			hud = null;
		}

		var mqReduce = window.matchMedia('(prefers-reduced-motion: reduce)');
		var mqMobile = window.matchMedia('(max-width: 767px)');
		var mqPointer = window.matchMedia('(hover: hover) and (pointer: fine)');

		var state = { cine: false, target: 0, cur: 0, mx: 0, my: 0, tmx: 0, tmy: 0, raf: 0, init: false, last: 0, tw: null, lock: 0 };
		cfg.flight = Math.max(600, Math.min(4000, Number(cfg.flight) || 1500));
		cfg.step = cfg.step !== false;
		var off = [];
		function on(t, ev, fn, opt) { t.addEventListener(ev, fn, opt); off.push(function () { t.removeEventListener(ev, fn, opt); }); }

		root.classList.add('cc--js');

		/* Recorrido de la cámara: se detiene en cada capítulo y vuela entre ellos. */
		var TRAVEL = [[0.07, 0.29], [0.37, 0.59], [0.67, 0.89]];
		var ANCHOR = { 1: 0, 2: 0.33, 3: 0.63, 4: 0.96 };
		function easeIO(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
		function camAt(p) {
			var z = 0;
			TRAVEL.forEach(function (r) { z += GAP * easeIO(clamp((p - r[0]) / (r[1] - r[0]))); });
			return z;
		}

		/* Cielo: 4 capas de color fijas que se funden solo con opacidad */
		var skyLayers = Array.prototype.slice.call(root.querySelectorAll('.cc-skyl span'));
		var heroParallax = Array.prototype.slice.call(root.querySelectorAll('.cc-ch1 .cc-sky, .cc-ch1 .cc-photo-fg, .cc-ch1 .cc-far, .cc-ch1 .cc-mid, .cc-ch1 .cc-fg'));
		var last = {}; // evita escribir estilos que no cambiaron
		function put(el, key, prop, val) {
			if (last[key] === val) return;
			last[key] = val;
			el.style.setProperty(prop, val);
		}

		// Las imágenes se decodifican por adelantado para que nada se cargue durante el vuelo.
		root.querySelectorAll('.cc-stage img').forEach(function (img) {
			img.loading = 'eager';
			if (img.decode) img.decode().catch(function () {});
		});

		function wantsCine() {
			if (mqReduce.matches) return false;
			if (mqMobile.matches && cfg.mobile !== 'cinematic') return false;
			return true;
		}

		function resetStyles() {
			world.style.transform = '';
			scroll.style.height = '';
			chapters.forEach(function (c) { c.classList.remove('is-off', 'is-live'); });
			leaves.forEach(function (list) { list.forEach(function (l) { l.el.style.removeProperty('opacity'); }); });
			clouds.forEach(function (c) { c.el.style.removeProperty('opacity'); c.el.classList.remove('is-off'); });
			state.tw = null;
			dropContent();
			skyLayers.forEach(function (s) { s.style.opacity = ''; });
			heroParallax.forEach(function (n) { n.style.removeProperty('--lx'); n.style.removeProperty('--ly'); });
			['--sun-o', '--glow-o'].forEach(function (k) { stage.style.removeProperty(k); });
			last = {};
		}

		function applyMode() {
			var want = wantsCine();
			if (want === state.cine && state.init) { if (want) layout(); return; }
			state.cine = want;
			root.classList.toggle('cc--cine', want);
			resetStyles();
			state.init = false;
			if (want) { liftContent(); layout(); tick(); } else { reveal(); }
		}

		function len() { return Math.round(cfg.length * (mqMobile.matches ? 0.75 : 1)); }
		function layout() { scroll.style.height = 'calc(100vh + ' + len() + 'px)'; }
		function distance() {
			var r = scroll.getBoundingClientRect();
			return clamp(-r.top, 0, Math.max(1, scroll.offsetHeight - window.innerHeight));
		}
		function tick() { if (!state.raf && state.cine) state.raf = requestAnimationFrame(frame); }

		function frame(now) {
			state.raf = 0;
			if (!state.cine) return;
			var dt = state.last ? Math.min(250, now - state.last) : 16.7;
			state.last = now;
			// Suavizado ágil: sigue al scroll casi al instante pero sin saltos.
			var aS = 1 - Math.pow(0.8, dt / 16.7), aM = 1 - Math.pow(0.9, dt / 16.7);

			// Vuelo automático entre escenas: tiempo fijo y curva suave, sin depender de los saltos de la rueda.
			if (state.tw) {
				var tw = state.tw, k = clamp((now - tw.t0) / tw.d);
				var pp = k >= 1 ? tw.end : lerp(tw.p0, tw.p1, k);
				// El escenario está fijo en pantalla: la página solo se desplaza al terminar el vuelo
				// (moverla en cada cuadro obligaba al navegador a recalcular la página, sobre todo en móviles).
				if (k >= 1) { state.tw = null; state.lock = now + 260; window.scrollTo({ top: tw.base + pp * len(), behavior: 'instant' }); }
				state.target = state.cur = pp * len();
				state.mx = lerp(state.mx, cfg.pointer && mqPointer.matches ? state.tmx : 0, aM);
				state.my = lerp(state.my, cfg.pointer && mqPointer.matches ? state.tmy : 0, aM);
				render(pp);
				tick();
				return;
			}

			state.target = distance();
			if (!state.init) { state.cur = state.target; state.init = true; }
			else state.cur = lerp(state.cur, state.target, aS);
			if (Math.abs(state.cur - state.target) < 0.1) state.cur = state.target;

			var usePointer = cfg.pointer && mqPointer.matches;
			var tx = usePointer ? state.tmx : 0, ty = usePointer ? state.tmy : 0;
			state.mx = lerp(state.mx, tx, aM);
			state.my = lerp(state.my, ty, aM);

			render(clamp(state.cur / len()));

			if (Math.abs(state.cur - state.target) > 0.1 || Math.abs(state.mx - tx) > 0.001 || Math.abs(state.my - ty) > 0.001) tick();
			else state.last = 0;
		}

		function render(p) {
			var k = cfg.intensity * (mqMobile.matches ? 0.5 : 1);
			// Posición exacta de la cámara: en reposo coincide justo con el capítulo (sin escala → texto nítido).
			var cam = Math.round(camAt(p) * 10) / 10;
			var f = cam / GAP;
			var dn = Math.abs(f - Math.round(f)) * GAP;       // distancia al capítulo más cercano
			var fly = smooth(4, 420, dn);                      // 0 = en reposo, 1 = volando
			var introO = 1 - smooth(6, 260, cam);              // el texto de bienvenida se va al despegar

			// La inclinación 3D solo actúa durante el vuelo; en reposo todo queda plano y nítido.
			var rx = (state.my * -3 * k * fly).toFixed(3), ry = (state.mx * 5 * k * fly).toFixed(3);
			put(world, 'world', 'transform', (fly > 0.001 ? 'rotateX(' + rx + 'deg) rotateY(' + ry + 'deg) ' : '') + 'translateZ(' + cam + 'px)');

			chapters.forEach(function (c, i) {
				var d = cam - i * GAP; // 0 = capítulo frente a la pantalla
				// Fundido limpio: el capítulo que se va desaparece antes de que llegue el siguiente.
				// El fondo que llega solo aparece cuando ya cubre toda la pantalla (sin bordes visibles de la foto).
				var o = d > 0 ? 1 - smooth(40, 520, d) : smooth(-640, -110, d);
				var offNow = o < 0.005;
				leaves[i].forEach(function (l, j) {
					put(l.el, 'l' + i + '-' + j, 'opacity', (o * l.f).toFixed(3));
				});
				var liveNow = Math.abs(d) < 120;
				if (last['off' + i] !== offNow) { last['off' + i] = offNow; c.classList.toggle('is-off', offNow); }
				if (last['live' + i] !== liveNow) { last['live' + i] = liveNow; c.classList.toggle('is-live', liveNow); }
			});

			// Textos: se van subiendo al despegar y llegan desde abajo al final del vuelo (solo desplazamiento y fundido,
			// nunca escala → la GPU no los redibuja y quedan en píxeles exactos en reposo).
			huds.forEach(function (h, j) {
				var d = cam - h.i * GAP, a, y;
				if (d >= 0) { var e = smooth(4, 300, d); a = 1 - e; y = -e * 40; }
				else { var g = smooth(-640, -16, d); a = g; y = (1 - g) * 40; }
				if (h.intro) a *= introO;
				put(h.el, 'ho' + j, 'opacity', a.toFixed(3));
				put(h.el, 'ht' + j, 'transform', 'translate3d(0,' + (Math.abs(y) < 0.05 ? 0 : y.toFixed(1)) + 'px,0)');
				var offNow = a < 0.005, liveNow = Math.abs(d) < 120;
				if (last['hoff' + j] !== offNow) {
					last['hoff' + j] = offNow;
					h.el.classList.toggle('is-off', offNow);
					if (!offNow) root.dispatchEvent(new CustomEvent('cc:show')); // el carrusel recalcula su posición
				}
				if (last['hlive' + j] !== liveNow) { last['hlive' + j] = liveNow; h.el.classList.toggle('is-live', liveNow); }
			});

			clouds.forEach(function (c, i) {
				var dc = c.z + cam;
				// Invisibles en reposo: aparecen al acercarse la cámara y se disipan al atravesarlas.
				var o = smooth(-1000, -380, dc) * (1 - smooth(30, 360, dc)) * 0.9;
				var offNow = o < 0.005;
				put(c.el, 'c' + i, 'opacity', o.toFixed(3));
				if (last['coff' + i] !== offNow) { last['coff' + i] = offNow; c.el.classList.toggle('is-off', offNow); }
			});


			// Parallax del mouse en reposo: solo mueve fotos y paisaje de la portada (2D), nunca el texto.
			var hero = 1 - smooth(0, 600, cam);
			heroParallax.forEach(function (n, i) {
				var front = n.classList.contains('cc-photo-fg') || n.classList.contains('cc-fg');
				var amt = (front ? 22 : -14) * k * hero * (1 - fly);
				put(n, 'hx' + i, '--lx', (state.mx * amt).toFixed(1) + 'px');
				put(n, 'hy' + i, '--ly', (state.my * amt * 0.4).toFixed(1) + 'px');
			});

			// Cielo: fundido de 4 capas fijas (sin repintar)
			skyLayers.forEach(function (s, i) {
				var w = i === 0 ? 1 : smooth(i - 0.75, i - 0.15, f);
				put(s, 's' + i, 'opacity', w.toFixed(3));
			});
			var end = 1 - smooth(2.4, 3, f) * 0.85; // el carrusel necesita máximo contraste
			put(stage, 'sun', '--sun-o', ((0.85 - clamp(f / 3) * 0.35) * end).toFixed(3));
			put(stage, 'glow', '--glow-o', smooth(2.2, 3, f).toFixed(3));
		}

		/* Ir a una escena (enlaces internos y foco con teclado) */
		function scrollToScene(n, instant) {
			var top = scroll.getBoundingClientRect().top + window.pageYOffset;
			window.scrollTo({ top: top + (ANCHOR[n] || 0) * len(), behavior: instant || mqReduce.matches ? 'auto' : 'smooth' });
		}

		on(root, 'click', function (e) {
			var a = e.target.closest('a[href^="#"]');
			if (!a || !state.cine) return;
			var id = a.getAttribute('href').slice(1);
			if (!id) return;
			var target = document.getElementById(id);
			if (!target || !root.contains(target)) return;
			var sc = target.closest('[data-cc-scene]');
			if (!sc) return;
			e.preventDefault();
			scrollToScene(Number(sc.getAttribute('data-cc-scene')));
		});

		on(root, 'focusin', function (e) {
			if (!state.cine) return;
			var sc = e.target.closest && e.target.closest('[data-cc-scene]');
			if (sc && !sc.classList.contains('is-live')) scrollToScene(Number(sc.getAttribute('data-cc-scene')), true);
		});

		/* Aparición suave en el modo de capítulos apilados */
		var io = null;
		function reveal() {
			if (mqReduce.matches || !('IntersectionObserver' in window)) return;
			if (!io) {
				io = new IntersectionObserver(function (entries) {
					entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); } });
				}, { rootMargin: '0px 0px -8% 0px' });
				off.push(function () { io.disconnect(); });
			}
			root.querySelectorAll('.cc-frame, .cc-ch2 .cc-panel, .cc-ch3-title, .cc-tile-wrap, .cc-s4__head, .cc-booking__inner').forEach(function (n, i) {
				if (n.classList.contains('is-in')) return;
				n.setAttribute('data-cc-reveal', '');
				if (n.classList.contains('cc-tile-wrap')) n.style.transitionDelay = (Number(getComputedStyle(n).getPropertyValue('--i')) || 0) * 70 + 'ms';
				io.observe(n);
			});
		}

		/* Inclinación 3D de los accesos al pasar el mouse */
		root.querySelectorAll('[data-cc-tilt]').forEach(function (tile) {
			on(tile, 'pointermove', function (e) {
				if (mqReduce.matches || e.pointerType !== 'mouse') return;
				var r = tile.getBoundingClientRect();
				var x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
				tile.classList.add('is-tilting');
				tile.style.setProperty('--ty', (x * 14).toFixed(2) + 'deg');
				tile.style.setProperty('--tx', (y * -12).toFixed(2) + 'deg');
			});
			on(tile, 'pointerleave', function () {
				tile.classList.remove('is-tilting');
				tile.style.removeProperty('--tx'); tile.style.removeProperty('--ty');
			});
		});

		/* Un gesto de rueda (o tecla) = un vuelo completo y suave hasta la escena siguiente o anterior.
		   Fuera de las escenas (antes de la portada o después de la última) el scroll vuelve a ser normal. */
		var ANCH = [ANCHOR[1], ANCHOR[2], ANCHOR[3], ANCHOR[4]];
		function stepFrom(dir, dry) {
			var max = scroll.offsetHeight - window.innerHeight;
			var top = scroll.getBoundingClientRect().top;
			var dist = -top;
			if (dist < -2 || dist > max + 2) return false;
			var p = clamp(dist / len()), j = -1, i;
			if (dir > 0) { for (i = 0; i < ANCH.length; i++) { if (ANCH[i] > p + 0.004) { j = i; break; } } }
			else { for (i = ANCH.length - 1; i >= 0; i--) { if (ANCH[i] < p - 0.004) { j = i; break; } } }
			if (j < 0) return false; // primera o última escena: se deja salir con scroll normal
			var r = dir > 0 ? TRAVEL[j - 1] : TRAVEL[j];
			if (!r) return false;
			if (dry) return true;
			var p0 = clamp(p, r[0], r[1]);
			var p1 = dir > 0 ? r[1] : r[0];
			var frac = Math.abs(p1 - p0) / (r[1] - r[0]);
			state.tw = { p0: p0, p1: p1, end: ANCH[j], t0: performance.now(), d: Math.max(260, cfg.flight * frac), base: top + window.pageYOffset };
			tick();
			return true;
		}
		on(window, 'wheel', function (e) {
			if (!state.cine || !cfg.step || e.ctrlKey || Math.abs(e.deltaY) < Math.abs(e.deltaX) || !e.deltaY) return;
			if (e.target && e.target.closest && e.target.closest('.cca')) return; // el chat tiene su propio scroll
			var now = performance.now();
			// Mientras vuela (y la inercia del touchpad sigue llegando) se ignoran los demás giros.
			if (state.tw || now < state.lock) { e.preventDefault(); if (!state.tw) state.lock = now + 160; return; }
			if (stepFrom(e.deltaY > 0 ? 1 : -1)) e.preventDefault();
		}, { passive: false });
		/* Teléfono: un deslizamiento del dedo = un vuelo completo (no sigue al dedo cuadro a cuadro,
		   que en móviles da tirones). Los deslizamientos horizontales quedan para el carrusel. */
		var touch = null;
		on(window, 'touchstart', function (e) {
			var inChat = e.target && e.target.closest && e.target.closest('.cca');
			touch = (state.cine && cfg.step && e.touches.length === 1 && !inChat) ? { x: e.touches[0].clientX, y: e.touches[0].clientY, done: false, block: false } : null;
		}, { passive: true });
		on(window, 'touchmove', function (e) {
			if (!touch || e.touches.length !== 1) return;
			if (state.tw) { if (e.cancelable) e.preventDefault(); return; }
			if (touch.done) { if (touch.block && e.cancelable) e.preventDefault(); return; }
			var dy = touch.y - e.touches[0].clientY, dx = touch.x - e.touches[0].clientX;
			if (Math.abs(dy) < 6 || Math.abs(dx) > Math.abs(dy)) return;
			var dir = dy > 0 ? 1 : -1;
			if (!stepFrom(dir, true)) { touch.done = true; return; } // primera/última escena: scroll normal
			if (e.cancelable) e.preventDefault();
			touch.block = true;
			if (Math.abs(dy) > 22) { touch.done = true; stepFrom(dir); }
		}, { passive: false });
		on(window, 'touchend', function () { touch = null; }, { passive: true });
		on(window, 'touchcancel', function () { touch = null; }, { passive: true });
		on(window, 'keydown', function (e) {
			if (!state.cine || !cfg.step || e.altKey || e.ctrlKey || e.metaKey) return;
			var t = e.target;
			if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT|BUTTON)$/.test(t.tagName))) return;
			var dir = { ArrowDown: 1, PageDown: 1, ' ': e.shiftKey ? -1 : 1, ArrowUp: -1, PageUp: -1 }[e.key];
			if (!dir) return;
			if (state.tw) { e.preventDefault(); return; }
			if (stepFrom(dir)) e.preventDefault();
		});
		on(window, 'scroll', tick, { passive: true });
		// En el teléfono la barra del navegador aparece/desaparece y dispara "resize" sin cambiar el ancho:
		// en ese caso no se recalcula nada (evita tirones al deslizar).
		var lastW = window.innerWidth;
		on(window, 'resize', function () {
			if (window.innerWidth === lastW && state.init) { tick(); return; }
			lastW = window.innerWidth;
			applyMode(); tick();
		});
		on(window, 'pointermove', function (e) {
			state.tmx = e.clientX / window.innerWidth - 0.5;
			state.tmy = e.clientY / window.innerHeight - 0.5;
			tick();
		}, { passive: true });
		[mqReduce, mqMobile].forEach(function (mq) {
			var fn = function () { applyMode(); };
			if (mq.addEventListener) { mq.addEventListener('change', fn); off.push(function () { mq.removeEventListener('change', fn); }); }
		});

		var slider = Slider(root, cfg);
		var search = Search(root, cfg);
		applyMode();

		return {
			root: root,
			destroy: function () {
				off.forEach(function (f) { f(); });
				if (state.raf) cancelAnimationFrame(state.raf);
				if (slider) slider.destroy();
				if (search) search.destroy();
			}
		};
	}

	/* =========================================================
	   Carrusel infinito (clona el conjunto a ambos lados)
	   ========================================================= */
	function Slider(root, cfg) {
		var wrap = root.querySelector('[data-cc-slider]');
		var track = root.querySelector('[data-cc-rail]');
		if (!wrap || !track) return null;
		var originals = Array.prototype.slice.call(track.querySelectorAll('[data-cc-card]'));
		var n = originals.length;
		if (!n) return null;
		var loop = n >= 3;
		var status = root.querySelector('[data-cc-status]');
		var dotsBox = root.querySelector('[data-cc-dots]');
		var prev = root.querySelector('[data-cc-prev]');
		var next = root.querySelector('[data-cc-next]');
		var cards, active, off = [];
		function on(t, ev, fn, opt) { t.addEventListener(ev, fn, opt); off.push(function () { t.removeEventListener(ev, fn, opt); }); }

		function makeClone(card) {
			var c = card.cloneNode(true);
			c.setAttribute('aria-hidden', 'true');
			c.setAttribute('inert', '');
			c.querySelectorAll('a,button').forEach(function (x) { x.setAttribute('tabindex', '-1'); });
			return c;
		}

		if (loop) {
			var before = document.createDocumentFragment(), after = document.createDocumentFragment();
			originals.forEach(function (c) { before.appendChild(makeClone(c)); after.appendChild(makeClone(c)); });
			track.insertBefore(before, track.firstChild);
			track.appendChild(after);
		}
		cards = Array.prototype.slice.call(track.querySelectorAll('[data-cc-card]'));
		active = loop ? n : 0;

		originals.forEach(function (c, i) {
			c.setAttribute('role', 'group');
			c.setAttribute('aria-roledescription', 'diapositiva');
			c.setAttribute('aria-label', fmt(T.slideOf || '%1$d / %2$d', i + 1, n));
		});

		var dots = [];
		if (dotsBox) {
			originals.forEach(function (c, i) {
				var b = el('button');
				b.type = 'button';
				var t = c.querySelector('.cc-card__title');
				b.setAttribute('aria-label', (i + 1) + ' — ' + (t ? t.textContent.trim() : ''));
				on(b, 'click', function () { go((loop ? n : 0) + i); });
				dotsBox.appendChild(b);
				dots.push(b);
			});
		}

		function real(i) { return ((i % n) + n) % n; }

		function metrics() {
			var w = cards[0].offsetWidth;
			var gap = parseFloat(getComputedStyle(track).columnGap || getComputedStyle(track).gap || '0') || 0;
			return { w: w, gap: gap };
		}
		// Posición que deja la tarjeta activa centrada.
		function offsetFor(i) {
			var m = metrics();
			return (wrap.clientWidth - m.w) / 2 - (m.w + m.gap) * i;
		}
		function update() {
			track.style.transform = 'translate3d(' + offsetFor(active) + 'px,0,0)';
			cards.forEach(function (c, i) {
				var d = i - active, a = Math.min(Math.abs(d), 3);
				c.classList.toggle('is-active', i === active);
				c.classList.toggle('is-far', Math.abs(d) > (wrap.clientWidth < 768 ? 1 : 2));
				// Coverflow 3D: las tarjetas laterales giran hacia el centro y se alejan.
				c.style.setProperty('--ry', (d === 0 ? 0 : (d > 0 ? -1 : 1) * Math.min(14 + a * 8, 38)) + 'deg');
				c.style.setProperty('--tz', (-a * 90) + 'px');
				c.style.setProperty('--sc', (1 - a * 0.04).toFixed(3));
			});
			var r = real(active);
			dots.forEach(function (d, i) { d.setAttribute('aria-current', i === r ? 'true' : 'false'); });
			if (status) status.textContent = (r + 1) + ' / ' + n;
			if (!loop) {
				if (prev) prev.disabled = active <= 0;
				if (next) next.disabled = active >= n - 1;
			}
		}
		function go(i) {
			active = loop ? i : clamp(i, 0, n - 1);
			update();
		}
		function jump(i) {
			track.classList.add('is-jumping');
			active = i;
			update();
			requestAnimationFrame(function () { requestAnimationFrame(function () { track.classList.remove('is-jumping'); }); });
		}
		function normalize() {
			if (!loop) return;
			if (active >= n * 2) jump(active - n);
			else if (active < n) jump(active + n);
		}

		if (prev) on(prev, 'click', function () { go(active - 1); });
		if (next) on(next, 'click', function () { go(active + 1); });
		on(track, 'transitionend', function (e) { if (e.target === track) normalize(); });
		on(wrap, 'keydown', function (e) {
			if (e.key === 'ArrowLeft') { e.preventDefault(); go(active - 1); }
			else if (e.key === 'ArrowRight') { e.preventDefault(); go(active + 1); }
		});
		// Si una tarjeta recibe el foco con Tab, se coloca en primer lugar.
		on(track, 'focusin', function (e) {
			var c = e.target.closest('[data-cc-card]');
			var i = cards.indexOf(c);
			if (i > -1 && i !== active) { wrap.scrollLeft = 0; go(i); }
		});

		// Deslizamiento táctil / arrastre
		var drag = null, moved = false;
		on(wrap, 'pointerdown', function (e) {
			if (e.pointerType === 'mouse' && e.button !== 0) return;
			drag = { x: e.clientX, y: e.clientY, base: offsetFor(active), dx: 0, lock: null };
			moved = false;
		});
		on(window, 'pointermove', function (e) {
			if (!drag) return;
			var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
			if (drag.lock === null && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) drag.lock = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y';
			if (drag.lock !== 'x') return;
			moved = true;
			drag.dx = dx;
			track.classList.add('is-dragging');
			track.style.transform = 'translate3d(' + (drag.base + dx) + 'px,0,0)';
		}, { passive: true });
		function end() {
			if (!drag) return;
			var dx = drag.dx;
			drag = null;
			track.classList.remove('is-dragging');
			if (Math.abs(dx) > 50) go(active + (dx < 0 ? 1 : -1) * Math.max(1, Math.round(Math.abs(dx) / (cards[0].offsetWidth || 300))));
			else update();
		}
		on(window, 'pointerup', end);
		on(window, 'pointercancel', end);
		on(wrap, 'click', function (e) { if (moved) { e.preventDefault(); e.stopPropagation(); moved = false; } }, true);
		on(wrap, 'dragstart', function (e) { e.preventDefault(); });
		on(root, 'cc:show', function () { if (wrap.offsetWidth) jump(active); });
		var sliderW = window.innerWidth;
		on(window, 'resize', function () { if (window.innerWidth !== sliderW) { sliderW = window.innerWidth; jump(active); } });

		update();
		return { destroy: function () { off.forEach(function (f) { f(); }); } };
	}

	/* =========================================================
	   Buscador instantáneo (REST WooCommerce)
	   ========================================================= */
	function Search(root, cfg) {
		var form = root.querySelector('[data-cc-search]');
		var list = root.querySelector('[data-cc-results]');
		var status = root.querySelector('[data-cc-results-status]');
		if (!form || !list) return null;
		var timer = 0, ctrl = null, loaded = false, lastTracked = '', off = [];
		function on(t, ev, fn, opt) { t.addEventListener(ev, fn, opt); off.push(function () { t.removeEventListener(ev, fn, opt); }); }

		function params() {
			var fd = new FormData(form), p = new URLSearchParams();
			['q', 'fecha', 'cat', 'min', 'max', 'duracion', 'dificultad'].forEach(function (k) {
				var v = fd.get(k);
				if (v !== null && String(v).trim() !== '') p.set(k, String(v).trim());
			});
			return p;
		}

		function bookUrl(item) {
			if (cfg.bookAction === 'whatsapp') return waUrl(cfg.wa, String(cfg.waProduct || '').replace('{experiencia}', item.name));
			if (cfg.bookAction === 'cart' && item.cartUrl) return item.cartUrl;
			return item.url;
		}

		function renderItems(data) {
			list.textContent = '';
			var items = (data && data.items) || [];
			items.forEach(function (it) {
				var li = el('li', 'cc-result');
				var img = el('img');
				img.src = it.image || ''; img.alt = ''; img.loading = 'lazy'; img.width = 88; img.height = 88;
				li.appendChild(img);
				var body = el('div', 'cc-result__body');
				if (it.category) body.appendChild(el('span', 'cc-result__cat', it.category));
				var h = el('h3', 'cc-result__title'), a = el('a', '', it.name);
				a.href = it.url; h.appendChild(a); body.appendChild(h);
				var meta = [it.duration, it.difficulty, it.availability].filter(Boolean).join(' · ');
				if (meta) body.appendChild(el('span', 'cc-result__meta', meta));
				var foot = el('div', 'cc-result__foot');
				var price = el('span', 'cc-result__price');
				price.innerHTML = it.priceHtml || ''; // HTML generado por WooCommerce en el propio sitio
				foot.appendChild(price);
				var b = el('a', 'cc-btn', (cfg.texts && cfg.texts.book) || 'Reservar');
				b.href = bookUrl(it);
				b.setAttribute('data-cc-track', cfg.bookAction === 'whatsapp' ? 'whatsapp_click' : 'reservar_click');
				b.setAttribute('data-cc-label', it.name);
				if (cfg.bookAction === 'whatsapp') { b.target = '_blank'; b.rel = 'noopener'; }
				var sr = el('span', 'cc-sr', ' — ' + it.name); b.appendChild(sr);
				foot.appendChild(b);
				body.appendChild(foot);
				li.appendChild(body);
				list.appendChild(li);
			});
			var total = (data && data.total) || 0;
			status.textContent = total === 0 ? (T.none || '') : total === 1 ? (T.oneResult || '1') : fmt(T.results || '%d', total);
		}

		function run() {
			var p = params();
			var empty = !Array.from(p.keys()).length;
			if (empty && !cfg.initial) { list.textContent = ''; status.textContent = ''; return; }
			p.set('per_page', String(empty ? cfg.initial : 12));
			if (cfg.cats) p.set('cats', cfg.cats);
			if (ctrl) ctrl.abort();
			ctrl = typeof AbortController === 'function' ? new AbortController() : null;
			list.classList.add('is-loading');
			status.textContent = T.loading || '';

			var promise;
			if (typeof window.curambaCinematicMock === 'function') promise = Promise.resolve(window.curambaCinematicMock(p));
			else {
				var url = G.restUrl + (G.restUrl.indexOf('?') > -1 ? '&' : '?') + p.toString();
				promise = fetch(url, { signal: ctrl ? ctrl.signal : undefined, headers: { Accept: 'application/json' } })
					.then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); });
			}
			promise.then(function (data) {
				list.classList.remove('is-loading');
				renderItems(data);
				var term = p.get('q') || '';
				if (term && term !== lastTracked) { lastTracked = term; track('search', term); }
			}).catch(function (err) {
				if (err && err.name === 'AbortError') return;
				list.classList.remove('is-loading');
				status.textContent = T.error || '';
			});
		}

		function schedule() { clearTimeout(timer); timer = setTimeout(run, 280); }
		on(form, 'input', schedule);
		on(form, 'change', schedule);
		on(form, 'submit', function (e) { e.preventDefault(); clearTimeout(timer); run(); });

		// Carga inicial perezosa al acercarse a la sección
		var section = root.querySelector('.cc-booking');
		if ('IntersectionObserver' in window && section) {
			var io = new IntersectionObserver(function (entries) {
				if (entries[0].isIntersecting && !loaded) { loaded = true; run(); io.disconnect(); }
			}, { rootMargin: '600px 0px' });
			io.observe(section);
			off.push(function () { io.disconnect(); });
			// Respaldo: si el navegador no avisa (pestaña en segundo plano, ahorro de energía), se carga igual.
			var backup = setTimeout(function () { if (!loaded) { loaded = true; run(); } }, 3500);
			off.push(function () { clearTimeout(backup); });
		} else { run(); }

		return { destroy: function () { clearTimeout(timer); if (ctrl) ctrl.abort(); off.forEach(function (f) { f(); }); } };
	}

	/* =========================================================
	   Arranque (página normal y editor de Elementor)
	   ========================================================= */
	function boot(scope) {
		// Limpia instancias cuyo HTML ya no está en la página (Elementor re-renderiza al editar).
		instances = instances.filter(function (inst) {
			if (!document.documentElement.contains(inst.root)) { inst.destroy(); return false; }
			return true;
		});
		(scope || document).querySelectorAll('.cc[data-cc-config]').forEach(function (root) {
			if (root.__ccReady) return;
			root.__ccReady = true;
			instances.push(Cinematic(root));
		});
	}

	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { boot(); });
	else boot();

	// Editor de Elementor: volver a iniciar cuando el widget se re-renderiza.
	var hooked = false;
	function hookElementor() {
		if (hooked || !window.elementorFrontend || !window.elementorFrontend.hooks) return;
		hooked = true;
		window.elementorFrontend.hooks.addAction('frontend/element_ready/curamba_cinematic.default', function ($scope) {
			boot($scope && $scope[0] ? $scope[0] : document);
		});
	}
	hookElementor();
	if (window.jQuery) window.jQuery(window).on('elementor/frontend/init', hookElementor);
})();
