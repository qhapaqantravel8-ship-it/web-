# Curamba Cinematic 3D — guía rápida

Plugin de WordPress que añade a Elementor el widget **"Curamba Cinematic"**: un recorrido **3D real** (la cámara vuela entre nubes de un capítulo a otro), colores vivos, accesos con efecto 3D, carrusel "coverflow" y buscador conectados a WooCommerce, y botones de WhatsApp con medición de conversiones.

## 0. Acceso exclusivo del administrador (hazlo primero)
1. En WordPress ve a **Usuarios → Añadir nuevo**.
2. Nombre de usuario: **CURAMBA2026-2** · Rol: **Administrador** · escribe la contraseña que definiste.
   (La contraseña **no** está guardada en el plugin; solo existe en tu WordPress.)
3. Cierra sesión y entra con ese usuario en `tu-dominio.com/wp-admin`.
4. Desde ese momento **solo esa cuenta** puede entrar al panel, editar con Elementor, cambiar productos, precios, fotos, fechas, cupos, plugins o ajustes. Cualquier otra cuenta (incluidos otros administradores y los clientes) queda sin permisos de edición.
5. Los **clientes siguen viendo la web, reservando, pagando y escribiendo por WhatsApp** con normalidad.

Protecciones incluidas: bloqueo de 15 minutos tras 5 intentos fallidos de inicio de sesión, mensaje de error genérico, XML-RPC cerrado por completo (incluido pingback), sin contraseñas de aplicación, sin editor de código en el panel, sin listado público de usuarios, sin páginas de autor y sin autores en el mapa del sitio.
**Si el hosting usa Cloudflare u otro proxy**, agrega en `wp-config.php` `define( 'CURAMBA_CC_PROXY_HEADER', 'HTTP_CF_CONNECTING_IP' );` (Cloudflare) o `'HTTP_X_FORWARDED_FOR'` (otros). Así el bloqueo por intentos fallidos usa la IP real de cada visitante y no bloquea a todos. No lo agregues si no hay proxy.
Estado y ajustes: **Ajustes → Curamba**.
**Emergencia** (si alguna vez pierdes el acceso): agrega `define( 'CURAMBA_CC_DISABLE_LOCK', true );` en `wp-config.php` desde el hosting, entra y vuelve a quitarlo.
Recomendación: como la contraseña se compartió por chat, cámbiala por una nueva en **Usuarios → Perfil** cuando termines de configurar.

## Fotos
- Incluye **5 fotos de prueba de Curamba** mejoradas (alta resolución, más color y nitidez; a la de la escalera se le quitaron las personas) en `assets/photos/prueba/`. Se usan por defecto en la portada 3D, la escena 2, los fondos de las escenas 3 y 4 y en 4 accesos.
- **Son solo de prueba**: cámbialas por tus fotos definitivas desde *Widget → Capas visuales* y *Escena 3 → Accesos* (Biblioteca de Medios). Si no son tuyas, consigue el permiso del autor antes de publicar.
- Portada **"Foto 3D"**: sube una foto panorámica (*Foto de portada*) y, si quieres más profundidad, la misma foto en PNG/WebP con solo el suelo visible (*Primer plano de la foto*).
- También queda disponible un grabado histórico de Curamba de dominio público (`assets/photos/historia-curamba.jpg`).

## Reservas por fecha y cupos (incluido)
En cada producto → *Datos del producto → General → Datos de la experiencia*:
- **Fechas de salida**: una por línea, `2026-12-05` o `2026-12-05|12` (12 cupos esa fecha).
- **Cupos por fecha**: cupos para las fechas sin número (0 = sin límite).
- El cliente elige la fecha en la página de la experiencia; la **cantidad = número de personas**. Se ven los cupos restantes y las fechas agotadas.
- Los cupos se descuentan al confirmarse el pedido (En espera / Procesando / Completado) y se devuelven si se cancela o reembolsa. El resumen "Reservas por fecha" aparece en el mismo producto.
- **Pagos por transferencia/depósito**: el pedido aparta los cupos al instante. Si sigue "En espera" pasado el plazo de **Ajustes → Curamba → Plazo para pagar una transferencia** (48 h por defecto), se cancela solo y los cupos se liberan. El cliente ve ese plazo en la página de "Pedido recibido". 0 = no cancelar nunca.
- Sin fechas cargadas, el cliente puede indicar una **fecha deseada** opcional.
- Cada experiencia muestra además el botón **"Consultar por WhatsApp"** con su nombre.

## Legal: Libro de Reclamaciones, privacidad, términos y pie de página
1. **Ajustes → Curamba → Datos de la empresa**: razón social, RUC, domicilio fiscal, correo, registro de agencia y redes. Mientras falten, el panel muestra un aviso y las páginas muestran "[… pendiente]".
2. Botón **"Crear las páginas legales que falten"** (misma pantalla): crea *Libro de Reclamaciones*, *Política de privacidad* y *Términos y condiciones*, y las enlaza con WordPress y con el checkout de WooCommerce. Los textos son un **borrador**: completa lo que está entre corchetes (cancelaciones, pagos, IGV…) y haz que lo revise un abogado.
3. Los datos de la empresa se insertan solos en cualquier texto con `[curamba_dato campo="ruc"]` (también `razon_social`, `direccion`, `email`, `telefono`, `mincetur`, `libro`, `privacidad`).
4. **Libro de Reclamaciones**: cada hoja recibe un número correlativo por año (00001-2026), se envía una copia al correo del cliente y otra a la agencia, y queda guardada en el menú **Reclamaciones** del panel (no se puede borrar; consérvalas al menos 2 años). Desde ahí escribes la respuesta y la envías por correo. La columna "Responder hasta" calcula 15 días hábiles (sin contar feriados) y se pone en rojo si se vence.
5. **Correos**: para que lleguen, configura el envío de correo del hosting (por ejemplo, con el plugin *WP Mail SMTP*) y haz una prueba.
6. **Pie de página**: contacto, enlaces legales y el botón del Libro de Reclamaciones en toda la web. Reemplaza el pie de ejemplo del tema (se puede desactivar en Ajustes → Curamba). También existe el shortcode `[curamba_footer]`.

## Google Analytics y opiniones
- **Google Analytics 4**: pega tu ID de medición (`G-XXXXXXXXXX`) en **Ajustes → Curamba → Medición y opiniones**. Se carga en toda la web, no cuenta tus visitas como administrador y recibe los eventos de WhatsApp, Reservar, búsquedas y opiniones. Para pruebas usa una propiedad aparte y cámbiala al lanzar. Compruébalo en GA → Informes → *Tiempo real*, abriendo la web desde otro navegador o el celular (si entras con tu sesión de administrador no se cuenta).
- **Opiniones**: botón "★ ¿Qué te pareció la web?" abajo a la izquierda (estrellas, qué le gustó, qué mejoraría, nombre opcional). Se guardan solo en la base de datos del sitio; se ven en el menú **Opiniones** del panel con el promedio de estrellas, la página y el dispositivo. Se apaga en la misma pantalla de ajustes.

## WhatsApp
Número por defecto: **+51 933 920 638** (Ajustes → Curamba). Botón flotante en toda la web y en cada experiencia.

## 1. Instalar
1. WordPress → **Plugins → Añadir nuevo → Subir plugin** → `curamba-cinematic.zip` → Activar.
2. Requiere WordPress 6+, PHP 7.4+, **Elementor** (Free o Pro) y **WooCommerce**.

## 2. Crear la página
1. Crea una página → **Editar con Elementor**.
2. En los ajustes de la página usa la plantilla **"Elementor a ancho completo"** (o Canvas).
3. Arrastra un contenedor a **ancho completo, sin relleno (padding 0)** y dentro el widget **Curamba Cinematic**.
4. La cabecera y el menú se hacen con **Theme Builder → Cabecera** (fondo transparente y "sticky" si lo deseas).

> Usa el widget una sola vez por página.

## 3. Qué se edita y dónde
| Qué | Dónde |
|---|---|
| Fotos de las capas (cielo, paisaje lejano, intermedio, atractivo, primer plano izq./der., foto enmarcada de escena 2, fondos de escenas 3 y 4) | Widget → *Capas visuales* (Biblioteca de Medios) |
| Pie/crédito de la foto de la escena 2 | Widget → *Escena 2 → Pie de la foto* |
| Icono y foto de cada acceso (escena 3) | Widget → *Escena 3 → Accesos* |
| Título, texto, etiquetas y botones de cada escena | Widget → *Escena 1…5* |
| Datos destacados (escena 2) | Widget → *Escena 2 → Datos destacados*. **Solo datos verificados**; los textos entre corchetes son marcadores |
| Accesos de la escena 3 → categoría WooCommerce | Widget → *Escena 3 → Accesos* |
| Qué experiencias salen en el carrusel y su orden | Widget → *Escena 4* |
| Foto, nombre, descripción corta, precio, categoría | Cada **producto** de WooCommerce (se actualiza solo) |
| Duración, dificultad, disponibilidad, fechas de salida | Producto → *Datos del producto → General → "Datos de la experiencia (Curamba)"* |
| Cupos | Producto → *Inventario → Gestionar inventario* (si no escribes "Disponibilidad", se muestra "Quedan X cupos") |
| Número y mensajes de WhatsApp, botón flotante | Widget → *WhatsApp* |
| Velocidad, intensidad del movimiento, comportamiento en móvil | Widget → *Movimiento* |
| Colores, tipografías, tamaño del título por dispositivo | Widget → pestaña *Estilo* |

Mientras una capa no tenga foto se ve una ilustración de ejemplo. Para el atractivo y el primer plano usa **PNG o WebP con fondo transparente** (así se logra la profundidad). Peso recomendado: < 400 KB por capa en WebP.

## 4. Las 5 experiencias iniciales
Crea 5 productos en WooCommerce (Experiencia principal en Curamba, Ruta cultural, Ruta de naturaleza, Experiencia gastronómica, Tour por los alrededores de Andahuaylas), con imagen destacada, descripción corta, precio, categoría y los "Datos de la experiencia". Aparecerán solos en el carrusel y en el buscador.

## 5. Reservas por fecha y cupo
El botón **Reservar** puede llevar a: la página del producto (recomendado si usas un plugin de reservas con calendario y cupos, p. ej. WooCommerce Bookings u otro compatible), directo al carrito (productos simples) o a WhatsApp con el nombre de la experiencia.
El filtro de **fecha** usa el campo "Fechas de salida" (una por línea, AAAA-MM-DD). Las experiencias sin fechas se consideran de fecha flexible y siempre aparecen.

## 6. Buscador
Lee productos reales mediante `/wp-json/curamba/v1/experiencias` (búsqueda por texto, categoría, fecha, precio, duración y dificultad). Respeta la visibilidad de catálogo de WooCommerce.

## 7. Medición de conversiones
Cada clic en WhatsApp, Reservar y cada búsqueda envía:
- `dataLayer.push({ event: 'curamba_whatsapp_click' | 'curamba_reservar_click' | 'curamba_search', curamba_label })` → úsalo como activador en Google Tag Manager.
- `gtag('event', ...)` si tienes GA4 directo, y `fbq` (Contact / InitiateCheckout / Search) si tienes Meta Pixel.

## 8. Móvil, accesibilidad y "reducir movimiento"
- Móvil: por defecto se muestra en secciones simples (rápido y fácil de usar); carrusel táctil; WhatsApp flotante siempre visible. Puedes cambiarlo a "Cinemático reducido".
- Si el visitante tiene activado *reducir movimiento*, la animación se desactiva automáticamente.
- Carrusel con flechas, puntos, teclado (← →), indicador "2 / 5" y bucle infinito.

## 9. LiteSpeed Cache
El plugin ya pide a LiteSpeed no retrasar su script. Si activas "Cargar JS diferido / Retrasar JS", verifica en **LiteSpeed → Optimización de página → Ajustes JS → Exclusiones** que estén `curamba-cinematic.js` y `curambaCinematicGlobals`. Después de cambiar productos, purga la caché si el carrusel no se actualiza.

## Shortcode de respaldo
`[curamba_cinematic]` muestra el componente con los textos por defecto (útil sin Elementor).
